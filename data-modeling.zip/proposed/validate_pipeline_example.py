#!/usr/bin/env python3
"""Reference validator for the BDD-to-code behaviour evidence pipeline (P1-P12).

Run this against any candidate implementation's sample output to prove two
independent things before wiring the steps into a real orchestrator:

1. Schema validity: every artifact matches its $defs entry in
   bdd-pipeline-artifacts.schema.json.
2. Referential consistency: every id one step invents (businessElementId,
   codeSymbolId, questionId, testDefinitionId) is either defined upstream or
   consumed downstream with no dangling or invented reference, and criterionId
   / runId are identical across all thirteen artifacts.

Usage:
    pip install jsonschema
    python3 validate_pipeline_example.py bdd-pipeline-artifacts.schema.json bdd-pipeline-worked-example.json
"""
import json
import sys
from jsonschema import Draft202012Validator, RefResolver

STEP_TO_DEF = {
    "P1_AcceptanceCriterionRecord": "AcceptanceCriterionRecord",
    "P2_BehaviourDecomposition": "BehaviourDecomposition",
    "P3_BusinessConcepts": "BusinessConcepts",
    "P4_CandidateSymbols": "CandidateSymbols",
    "P5_SymbolMappings": "SymbolMappings",
    "P6_TechnicalBehaviourModel": "TechnicalBehaviourModel",
    "P7_ProgramAnalysisQuestions": "ProgramAnalysisQuestions",
    "P8_ProgramEvidenceRaw": "ProgramEvidenceRaw",
    "P9_ProgramEvidence": "ProgramEvidence",
    "P10_BehaviourVerification": "BehaviourVerification",
    "P11a_TestCandidates": "TestCandidates",
    "P11b_TestCoverage": "TestCoverage",
    "P12_GapClassification": "GapClassification",
}


def expected_outcome(status, overall):
    """The deterministic P12 gap-classification rule table."""
    if status == "contradicted":
        return ("gap_candidate", "implementation_gap")
    if status in ("supported", "partially_supported"):
        if overall == "not_covered":
            return ("gap_candidate", "regression_test_gap")
        if overall == "partial":
            return ("gap_candidate", "partial_test_gap")
        if overall == "covered":
            return ("not_applicable", None)
    return ("insufficient_evidence", None)


def validate_schema(schema, examples):
    resolver = RefResolver.from_schema(schema)
    ok = True
    for key, defname in STEP_TO_DEF.items():
        validator = Draft202012Validator({"$ref": f"#/$defs/{defname}"}, resolver=resolver)
        errors = list(validator.iter_errors(examples[key]))
        print(f"{key:35s} -> {defname:25s} {'OK' if not errors else 'FAIL'}")
        for e in errors:
            ok = False
            print("   ", e.message, list(e.path))
    return ok


def validate_consistency(ex):
    errors = []
    crit_ids = {k: v.get("criterionId") for k, v in ex.items()}
    run_ids = {k: v.get("runId") for k, v in ex.items()}
    if len(set(crit_ids.values())) != 1:
        errors.append(f"criterionId mismatch: {crit_ids}")
    if len(set(run_ids.values())) != 1:
        errors.append(f"runId mismatch: {run_ids}")

    p2 = ex["P2_BehaviourDecomposition"]
    defined_ids = set()
    for p in p2["preconditions"]:
        defined_ids.add(p["preconditionId"])
    defined_ids.add(p2["trigger"]["triggerId"])
    for e in p2["expectedEffects"]:
        defined_ids.add(e["effectId"])
    for e in p2["forbiddenEffects"]:
        defined_ids.add(e["effectId"])

    p5_refs = {m["businessElementId"] for m in ex["P5_SymbolMappings"]["mappings"]}
    p6 = ex["P6_TechnicalBehaviourModel"]
    p6_refs = (
        {c["businessElementId"] for c in p6["conditions"]}
        | {s["businessElementId"] for s in p6["expectedSinks"]}
        | {s["businessElementId"] for s in p6["forbiddenSinks"]}
    )
    p10_refs = {t["effectId"] for t in ex["P10_BehaviourVerification"]["then"]}
    for label, refs in [("P5", p5_refs), ("P6", p6_refs), ("P10", p10_refs)]:
        dangling = refs - defined_ids
        if dangling:
            errors.append(f"{label} references undefined businessElementId/effectId: {dangling}")

    p4_symbols = {c["codeSymbolId"] for c in ex["P4_CandidateSymbols"]["candidates"]}
    p5_symbols = {m["codeSymbolId"] for m in ex["P5_SymbolMappings"]["mappings"]}
    if not p5_symbols.issubset(p4_symbols):
        errors.append(f"P5 uses codeSymbolId not proposed in P4: {p5_symbols - p4_symbols}")

    p6_symbols = (
        {p6["entryPoint"]["codeSymbolId"]}
        | {c["codeSymbolId"] for c in p6["conditions"]}
        | {s["codeSymbolId"] for s in p6["expectedSinks"]}
        | {s["codeSymbolId"] for s in p6["forbiddenSinks"]}
    )
    if not p6_symbols.issubset(p5_symbols):
        errors.append(f"P6 uses codeSymbolId not grounded in P5: {p6_symbols - p5_symbols}")

    p7_qids = {q["questionId"] for q in ex["P7_ProgramAnalysisQuestions"]["questions"]}
    p8_qids = {r["questionId"] for r in ex["P8_ProgramEvidenceRaw"]["results"]}
    p9_qids = {i["questionId"] for i in ex["P9_ProgramEvidence"]["items"]}
    if p8_qids != p7_qids:
        errors.append(f"P8 questionId set != P7: extra={p8_qids - p7_qids} missing={p7_qids - p8_qids}")
    if p9_qids != p7_qids:
        errors.append(f"P9 questionId set != P7: extra={p9_qids - p7_qids} missing={p7_qids - p9_qids}")

    p9_support_syms = {s for i in ex["P9_ProgramEvidence"]["items"] for s in i["support"] if "::" in s}
    if not p9_support_syms.issubset(p5_symbols):
        errors.append(f"P9 support references ungrounded codeSymbolId: {p9_support_syms - p5_symbols}")

    p11a_tids = {c["testDefinitionId"] for c in ex["P11a_TestCandidates"]["candidates"]}
    p11b = ex["P11b_TestCoverage"]
    if p11b["testDefinitionId"] not in p11a_tids:
        errors.append(f"P11b testDefinitionId {p11b['testDefinitionId']} not among P11a candidates {p11a_tids}")

    cov_refs = set(p11b["preconditionsCovered"]) | set(p11b["positiveEffectsCovered"]) | set(p11b["negativeEffectsCovered"])
    dangling = cov_refs - defined_ids
    if dangling:
        errors.append(f"P11b references undefined ids: {dangling}")

    p10_status = ex["P10_BehaviourVerification"]["status"]
    p12 = ex["P12_GapClassification"]
    exp = expected_outcome(p10_status, p11b["overall"])
    got = (p12["outcome"], p12["gapType"])
    if exp != got:
        errors.append(
            f"P12 outcome/gapType {got} does not match rule-table expectation {exp} "
            f"for status={p10_status} overall={p11b['overall']}"
        )
    return errors


def main():
    schema_path = sys.argv[1] if len(sys.argv) > 1 else "bdd-pipeline-artifacts.schema.json"
    example_path = sys.argv[2] if len(sys.argv) > 2 else "bdd-pipeline-worked-example.json"
    schema = json.load(open(schema_path))
    examples = json.load(open(example_path))

    schema_ok = validate_schema(schema, examples)
    print()
    errors = validate_consistency(examples)
    if errors:
        print("CONSISTENCY ERRORS:")
        for e in errors:
            print(" -", e)
    else:
        print("ALL CROSS-STEP REFERENTIAL CHECKS PASSED.")

    sys.exit(0 if (schema_ok and not errors) else 1)


if __name__ == "__main__":
    main()
