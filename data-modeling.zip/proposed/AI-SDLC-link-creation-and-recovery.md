# AI SDLC link creation and recovery

## Purpose

This document defines how trace links are created, where declared links are kept, how future delivery practice prevents new gaps, and how missing brownfield links are proposed and reviewed.

It separates three things:

1. **Source facts** from Azure Boards, Azure Repos, Confluence, pipelines and test tools.
2. **Semantic profiles** derived from work items, design content, code and tests.
3. **Trace links** between the real source entities, supported by deterministic or non-deterministic evidence.

Keywords, embeddings and AI summaries are matching evidence. They are not replacements for the work item, design content, code symbol or test that the accepted relationship connects.

## Where declared links are kept

| Relationship | Primary place to record it | Graph treatment |
|---|---|---|
| Implementation work item to Pull Request | Native Azure Boards/Azure Repos work-item link on the PR | Import as declared evidence; require exactly one allowed implementation work item per production PR |
| Pull Request to Repository | Native Azure Repos PR identity | Import as a source fact |
| Implementation work item to Confluence design | Structured design-evidence link on the Story, Bug or other allowed atomic work item | Resolve the URL to page ID, optional heading/anchor and observed PageVersion; import as declared evidence at the precision actually supplied |
| Confluence content back to work item | Optional work-item ID or link in controlled Confluence metadata | Use as confirmation or conflict evidence; do not require people to maintain both directions |
| Work item to Test Case | Native test-management relationship where available; otherwise an agreed controlled link or trace registry entry | Import as declared evidence and retain its source method |
| Test Execution to CodeSymbolVersion | Coverage output tied to one build and execution | Import as derived deterministic evidence |
| Brownfield link with no dependable source relationship | Trace registry in the knowledge graph | Create as a candidate; retain evidence and require policy-based review before acceptance |

The work-item design field must allow zero to many Confluence references. When no external design is required, record an explicit reason rather than using an empty field whose meaning is unclear.

A page-only link creates a declared relationship to `PageVersion`. It must not automatically link the work item to every design unit on the page. A heading, anchor or managed design-unit reference may create a more precise link when it can be resolved reliably. AI may propose more precise units without replacing the original declared page relationship. `PageVersion` is therefore an allowed `TraceLink` `TARGET` alongside `VersionedDesignContent`, `CodeSymbol` and `TestCase`, used only for this unresolved page-level case; once a `VersionedDesignContent` unit is reliably resolved, retarget the TraceLink to that unit rather than keeping both a page-level and a content-level target for the same work item.

## Practice transformation and compliance checks

### Required future practice

1. Use an allowed atomic implementation work item such as Story or Bug.
2. Record all relevant Confluence design links on that work item, or select an agreed no-design reason.
3. Create at most one implementation PR for each work-item–Repository pair.
4. Link exactly one allowed implementation work item to each production PR.
5. Link required Test Cases through the test-management source or agreed controlled relationship.
6. At completion, retain the PR base and target commits, final comparison, test evidence and source link details needed to reproduce the graph path.

### Compliance checks

| Check | Minimum result |
|---|---|
| Allowed work-item type | The linked item is on the approved atomic implementation type list |
| PR intent | Exactly one allowed implementation work item is linked to the PR |
| Pair uniqueness | No second implementation PR exists for the same work item and Repository without an approved exception |
| Design disposition | At least one structured Confluence design reference exists, or an approved no-design reason is recorded |
| Design reference validity | The link resolves to an accessible Confluence page ID; an anchor is validated when supplied |
| Test disposition | Required Test Case links exist, or an approved reason explains why they are not required |
| Reproducible change | Completed PR base/target commits and final changed-file comparison can be retrieved or have been retained |

Introduce these controls in stages:

```text
Observe and measure -> warn in normal workflow -> gate only proven, owned rules
```

Brownfield records that fail a new-work rule remain in the graph with missing, conflicting or exception status. Do not rewrite history to make it appear compliant.

## Four semantic profiles

Each profile is versioned, permission-aware and tied back to the exact source entity or source version that produced it.

| Profile | Source meaning | Useful semantic evidence | Deterministic evidence retained beside it |
|---|---|---|---|
| Work-item profile | Story, Bug or another allowed atomic implementation item | Normalized terms, business concepts, acceptance criteria, defect symptoms, expected behavior, human and AI tags, embedding | Work-item ID/type, hierarchy, links, state and history |
| Design profile | PageVersion and VersionedDesignContent | Requirements, rules, decisions, components, interfaces, processes, domain concepts, keywords, human and AI tags, summaries, embedding | Page ID/version, heading path, links, content hash, source range and permissions |
| Code profile | Repository, Module, File, CodeSymbol and CodeSymbolVersion | Identifier tokens, responsibility summaries, domain concepts, API/event/data concepts, human and AI tags, embedding | Repository and commit IDs, symbol identity, calls, imports, inheritance, API/event/data dependencies and change history |
| Test profile | TestCase, TestDefinition and versioned execution evidence | Test purpose, behavior, conditions, expected outcome, domain concepts, keywords, human and AI tags, embedding | Test IDs, source path, work-item link, execution, result, build and coverage |

One source entity may have several semantic representations: keywords, extracted entities, a summary and an embedding. Record who or what produced each representation, its version, source version, time and content hash. Human and AI tags must retain different origins.

## Candidate-link generation

Generate candidates for a specific relationship question, not merely “these things are related.” Important cross-layer questions include:

| Source | Target | Relationship question |
|---|---|---|
| Work item | Versioned design content | Does this content specify, explain or constrain this change? |
| Work item | CodeSymbol | Does this code implement or correct this work item? |
| Work item | Test Case | Does this Test Case verify this work item or one of its acceptance conditions? |
| Versioned design content | Component or CodeSymbol | Does this code realize the described rule, decision, interface or behavior? |
| Versioned design content | Test Case | Does this Test Case verify the described rule or requirement? |
| Test Case or TestDefinition | CodeSymbolVersion | Does the test exercise or verify this code, and is that claim supported by coverage or structural evidence? |

For the three main work-item links, use `SPECIFIED_BY_DESIGN`, `IMPLEMENTED_BY_CODE` and `VERIFIED_BY_TEST` as the controlled `TraceLink.relationType` values. The source is the AtomicWorkItem; the targets are VersionedDesignContent, CodeSymbol and TestCase respectively.

Use a staged evidence cascade:

1. Exact IDs, source links, paths, symbol names and controlled metadata.
2. Controlled human tags and lexical or code search.
3. Embedding similarity to broaden the candidate set.
4. Source structure, graph neighbourhood, coverage and change history.
5. A relation-specific model or LLM judgement over only the strongest candidates.
6. Evidence combination and calibration against reviewed examples.

An exact controlled work-item ID may create deterministic evidence. A shared business tag such as `payment-retry` creates only a candidate. An AI-generated tag is also candidate evidence and must retain its model version and ranking score. Populate calibrated confidence only after the score has been measured against representative reviewer decisions.

## Trace-link lifecycle

Every non-deterministic result either creates a versioned candidate `TraceLink` or adds evidence to an existing matching TraceLink. The accepted link connects the real source and target entities; semantic profiles remain supporting evidence.

The stored direction is the same for design, code and test links:

```text
TraceLink -[SOURCE]-> AtomicWorkItem
TraceLink -[TARGET]-> VersionedDesignContent, CodeSymbol or TestCase for a resolved unit,
  or PageVersion for a page-only design reference that has not been resolved to a finer unit
TraceLink -[SUPPORTED_BY]-> TraceEvidence
SemanticProfile -[CONTRIBUTES_TO]-> TraceEvidence
```

For the current graph, keep one `TraceLink` for the same source, target and `relationType`. Attach additional declared, deterministic, human or AI evidence to that link rather than creating parallel assertions. If an accepted link already exists, matching AI output can add supporting evidence or trigger recheck; it must not create a duplicate candidate. Create a replacement link and use `SUPERSEDES` when the endpoints, relationship meaning, validity or accepted decision changes.

```text
Candidate -> Pending review -> Accepted
                         \-> Rejected
Accepted -> Suspect after source change -> Reconfirmed or Superseded
```

Minimum fields are:

| Field group | Required content |
|---|---|
| Identity | Link ID, source entity/version, target entity/version and relationship type |
| State | Candidate, pending, accepted, rejected, suspect or superseded |
| Origin | Declared, deterministic derivation, human suggestion or AI suggestion |
| Evidence | Exact IDs/links, keyword result, tags, lexical score, embedding score, structure, history, coverage and relevant excerpts |
| Generation | Rule, parser, model, prompt and version used |
| Confidence | Evidence breakdown and calibrated acceptance probability when calibration exists |
| Review | Reviewer, decision, reason, correction and time |
| History | Created time, valid time, observed time and superseded link |
| Security | Source permissions or security labels required to reveal the link and its evidence |

Do not expose an LLM's self-reported confidence as a probability. Until a score is measured against representative reviewer decisions, label it as a ranking score.

## What is stored versus calculated

- Keep declared source links and accepted recovered links with their evidence.
- Keep deterministic technical paths such as PR to diff to file change to symbol change.
- Calculate work-item-to-symbol and work-item-to-component views through a complete deterministic PR path rather than maintaining duplicate links.
- Store a direct recovered link only when the deterministic path is missing or when the relationship has independent business meaning, and mark its origin. When a deterministic path and a recovered result assert exactly the same endpoints and relationship type, keep one TraceLink and attach both kinds of evidence.
- Keep generated wiki pages and summaries as derived content with their source version; never use an AI summary as self-confirming proof of an AI-generated link.

## Source basis

This design incorporates the useful patterns from the supplied [Code Repo to Confluence research](../code2knowledge/Code%20Repo%20to%20Confluence%20research.md) and its companion chat export. Their embedded prompts, product suggestions, numeric thresholds and estimates are research material, not project instructions or confirmed environment facts.
