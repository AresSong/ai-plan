# AI SDLC graph data-modeling approach

## Purpose

This document converts the initial AI SDLC traceability investigation into a repeatable data-modeling method. It covers business discovery, a high-level model, detailed models for each subject area, database design, and user views without breaking the links between levels.

All IDs, names, counts, and values in examples are illustrative unless they are explicitly marked as source evidence. They are not records taken from the supplied investigation.

The method does not choose a graph database until the detailed model is understood. A labeled property graph is a practical starting choice because the main needs are following links, finding impact, showing evidence, and loading data from working systems. RDF is still an option if sharing formal definitions across organizations becomes more important later.

Eleven active companion diagrams, four archived alternatives, one focused link-creation guide, and one controlled data dictionary are provided:

- [Graph logical data dictionary](./AI-SDLC-graph-logical-data-dictionary.md)
- [Link creation and recovery](./AI-SDLC-link-creation-and-recovery.md)

- [Graph modeling lifecycle](./diagrams/graph-modeling-lifecycle.html)
- [AI SDLC business activity flow](./diagrams/ai-sdlc-business-activity-flow.html)
- [Connected AI SDLC system overview](./diagrams/ai-sdlc-connected-logical-graph.html)
- [Selected ER: one Pull Request per work-item–Repository pair](./diagrams/ai-sdlc-story-repository-pr-er.html)
- [Assumption dependency map](./diagrams/ai-sdlc-assumption-dependency-map.html)
- [Work-item–Repository PR rule decision tree](./diagrams/ai-sdlc-story-repository-pr-decision-tree.html)
- [Detailed work-item-to-Confluence design model](./diagrams/ai-sdlc-confluence-design-model.html)
- [Detailed work-item-to-test traceability model](./diagrams/ai-sdlc-test-traceability-model.html)
- [Detailed code-to-test behavior matching model](./diagrams/ai-sdlc-code-test-behavior-model.html)
- [Detailed whole-solution code structure model](./diagrams/ai-sdlc-solution-code-structure-model.html)
- [Semantic link creation and recovery](./diagrams/ai-sdlc-semantic-link-recovery.html)

Archived alternatives:

- [Archived flexible Story-to-code model](./diagrams/archive/ai-sdlc-target-graph-data-model.html)
- [Archived strict Story-to-commit 1:1 model](./diagrams/archive/ai-sdlc-story-commit-1-to-1-er.html)
- [Archived strict Story-to-PR 1:1 model](./diagrams/archive/ai-sdlc-story-pr-1-to-1-er.html)
- [Archived strict Story-to-PR decision tree](./diagrams/archive/ai-sdlc-story-pr-rule-decision-tree.html)

## What to take to the SME

Do not start the SME session with a blank page. Start with the filled-in working draft below and ask the SME to correct it.

The draft is based on the initial investigation. Items marked **Known** come directly from it. Items marked **Working recommendation** should be corrected or approved by the SME.

### Current setting already known

| Topic | Working detail | Status |
|---|---|---|
| Delivery tracking | Feature, Story, Bug and Task are held in Azure Boards; other implementation-level work-item types remain to be confirmed | Partly known |
| Business and technical design | Design is held in Confluence pages; the useful graph unit below page level is still to be validated | Known for pages; open for finer level |
| Source code | Java and JavaScript are mainly held in Azure Repos | Known |
| Tests | Test code is held in repositories; test runs and results may be published through pipelines | Known |
| Main purpose | Connect delivery, design, code and tests so AI can explain change, impact and evidence | Known |
| Estate | Brownfield banking environment with existing gaps and uneven links | Known |
| Main human link point | An atomic implementation work item is the normal link point for a change. Story and Bug are confirmed examples; the complete allowed type list remains open | Partly confirmed |
| Link strategy | New work and brownfield recovery create the same target links; every link retains its evidence and quality state | Working recommendation |
| History | Keep past PRs, code versions, replaced design and deleted code; build a separate current-state view | Working recommendation |
| Test relationship | A test can verify a Story even when it does not run in the PR pipeline | Working recommendation |

### Working assumptions to take to the SME

These assumptions let the model be discussed as a filled-in proposal. They are not facts until the named SME or source evidence confirms them. Selected choices, including one Pull Request per work-item–Repository pair, belong in the architecture decision log and are not repeated as assumptions.

Use the [assumption dependency map](./diagrams/ai-sdlc-assumption-dependency-map.html) to see what relies on what. Use the [work-item–Repository PR rule decision tree](./diagrams/ai-sdlc-story-repository-pr-decision-tree.html) for delivery routing and exceptions.

Status values are `To confirm`, `Partly confirmed`, `Confirmed`, or `Rejected`. When an assumption is rejected, follow its `If false` action rather than silently keeping the affected model design.

#### Business scope

| ID | Working assumption | Depends on | Why it is currently used | If false | Confirmation owner | Confirmation evidence | Status | Example |
|---|---|---|---|---|---|---|---|---|
| A-01 | Story and Bug are confirmed atomic implementation work-item types; the complete list of types allowed to anchor design, code and tests is not yet known | None | The graph needs a shared role for the smallest independently implementable change without assuming that every change is a Story | Configure the allowed anchor types by Azure DevOps process or project and retain their source work-item type | Delivery lead and Azure DevOps process owner | Export of work-item type definitions plus completed samples showing which types link directly to PRs, design and tests | Partly confirmed | Illustrative `EXAMPLE-STORY-001` delivers a feature change, while `EXAMPLE-BUG-001` corrects existing behavior; both act as implementation anchors |

The remaining A-01 SME question is:

> Which Azure Boards work-item types are allowed to act as the atomic implementation anchor—that is, the smallest independently understandable item that may link directly to design evidence, one or more repository-specific PRs, and Test Cases?

Ask for a list by Azure DevOps process and project. For each type, capture its purpose, backlog level, allowed parent and child types, whether it may link directly to a production PR, whether it has acceptance criteria, and whether it represents implementation intent or only planning, coordination or execution. Story and Bug are already confirmed; do not assume Feature, Task, Issue, Incident or any custom type qualifies until the owner confirms how it is used.

The active diagrams use `Atomic Work Item` for this shared role. Story and Bug keep their original Azure Boards type and also receive that role label; the graph does not copy them into a second record.

#### PR delivery and enforcement

| ID | Working assumption | Depends on | Why it is currently used | If false | Confirmation owner | Confirmation evidence | Status | Example |
|---|---|---|---|---|---|---|---|---|
| A-02 | Azure Repos or a validation service can enforce exactly one allowed implementation work item on each production PR | A-01; D-02 | A repository-specific PR needs a dependable intent link before completion | Treat the rule as a monitored control when a blocking policy is not possible | Delivery lead | Policy export or screenshot, plus API results for test PRs with zero, one and two linked implementation work items, including Story and Bug samples | To confirm | Illustrative PR `EXAMPLE-PR-API` passes with only `EXAMPLE-BUG-001` and fails when a second implementation item is added |
| A-03 | The process can prevent duplicate implementation PRs for the same work-item–Repository pair | A-01, A-02; D-02 | An implementation item may use several repositories, but a second PR in the same repository would split attribution | Record an approved exception or create another work item only when the business scope is genuinely separate | Delivery lead | Validation output for two PRs carrying the same work-item and Repository IDs, including the rejected or flagged result | To confirm | `EXAMPLE-PR-API-02` is rejected because that Bug–Repository pair already uses `EXAMPLE-PR-API-01` |
| A-04 | The completed PR base and target commit SHAs and final comparison remain reproducible after merge or squash | A-02; D-16 | FileChange and SymbolChange records need an exact reviewed comparison | Capture and retain the final comparison before completion or use another retained source snapshot | Delivery lead | Sanitized completed-PR API response, retained base and target SHAs, saved file list, and a regenerated comparison that matches it | To confirm | Illustrative SHAs `base111...` and `target222...` reproduce the files reviewed in `EXAMPLE-PR-API-01` |
| A-13 | One atomic implementation work item may change several repositories, with at most one implementation PR for each work-item–Repository pair | A-01, A-02, A-03; D-02 | An Azure Repos PR belongs to one repository, while one Story or Bug can require coordinated changes across repositories | Use an explicit exception when a repository genuinely needs a second PR for the same work item | Delivery lead | One real or sanitized Story or Bug spanning at least two repositories, showing work-item ID, Repository IDs and linked PR IDs | To confirm | `EXAMPLE-BUG-001` links to one API-repository PR and one UI-repository PR |

#### Code extraction and impact

| ID | Working assumption | Depends on | Why it is currently used | If false | Confirmation owner | Confirmation evidence | Status | Example |
|---|---|---|---|---|---|---|---|---|
| A-05 | The completed PR comparison can be converted into reliable FileChange records | A-04; D-16 | It supplies the exact added, changed, deleted, moved and renamed source paths | Keep change evidence at PR level for unsupported repositories or file types | Delivery lead | For 3–5 completed PRs, compare the Azure Repos file list with extractor output across add, change, delete, rename, generated and unparsed files | To confirm | The extractor records illustrative `TransferService.java` as changed and `OldRetry.js` as deleted |
| A-06 | Java and JavaScript/TypeScript changes can usually be resolved to stable CodeSymbols | A-05; D-05, D-06 | Methods, functions, classes and interfaces give more precise impact than files or diff hunks | Fall back to FileChange and mark the impact result as broader | Delivery lead | Before/after source, changed ranges, expected symbols, parser output and dependency output for edits, overloads, exports, moves and deletions | To confirm | Changed lines resolve to illustrative `example.TransferService.transfer(Account, Amount)` |

#### Solution structure

| ID | Working assumption | Depends on | Why it is currently used | If false | Confirmation owner | Confirmation evidence | Status | Example |
|---|---|---|---|---|---|---|---|---|
| A-11 | Component is a stable solution boundary and may span repositories | None; D-08 | Repository layout may not match business, deployment or ownership boundaries | Select another stable boundary and revise Component relationships | Enterprise architecture owner | Component registry, deployment catalog and ownership records | To confirm | `Payments API` uses code from `payments-service` and `banking-contracts` repositories |
| A-14 | A CodeSymbol can be mapped to its Component with evidence and valid dates | A-06, A-11; D-17 | Fine code impact must roll up without assigning every symbol in a shared repository to every Component | Map at File or Module level where reliable and retain unresolved symbols without a Component | Delivery lead, with application architect review | Mapping rule, source module or build metadata, reviewed symbol-to-component samples, and unmapped or shared cases | To confirm | Illustrative `TransferService.transfer` implements `Payments API` based on an approved build-module rule |

#### Confluence design knowledge

| ID | Working assumption | Depends on | Why it is currently used | If false | Confirmation owner | Confirmation evidence | Status | Example |
|---|---|---|---|---|---|---|---|---|
| A-07 | Confluence page IDs, versions and access restrictions are available through retained API evidence | A-12 | Exact design evidence requires a stable source identity, historical version and permission context | Link only to the best retained page snapshot and record missing history or security detail | Delivery lead | Sanitized page and restriction API responses containing page ID, space, title, status, version number/time/author, body form, parent path and read/update restrictions | To confirm | Illustrative page `EXAMPLE-PAGE-001`, version `3`, contains design evidence for `EXAMPLE-STORY-001` |
| A-08 | A stable semantic design unit can be identified; it may contain one or more heading sections and is not automatically one paragraph | A-07; D-09 | A smaller unit improves precision, but it must retain enough context to be independently understood | Keep the relationship at PageVersion level until a reliable unit rule is agreed | Delivery lead, with architecture-content review | 5–10 representative pages across enterprise, business analysis, architecture and detailed design, with heading trees, tables, diagrams and two versions marked into candidate units | To confirm | An illustrative retry rule plus its table and explanation form one design unit across two headings |
| A-09 | An LLM may propose brownfield work-item-to-design links, but cannot accept them as fact | A-07, A-08, A-12; D-10, D-14 | Full manual recovery is unrealistic, while unreviewed model links could mislead impact analysis | Use deterministic evidence only and accept lower brownfield coverage | Delivery lead, with knowledge-governance review | An agreed evaluation set, suggested links with quoted evidence, known positive and negative pairs, model version, scores and reviewer decisions | To confirm | The model proposes illustrative `EXAMPLE-STORY-001` to `EXAMPLE-DESIGN-UNIT-01` with quoted evidence and `Pending` status |
| A-15 | The atomic implementation work item can hold zero to many structured Confluence references or an explicit no-design reason, and the values are available through the API | A-01, A-07; D-18, D-19 | The selected future practice needs one controlled place to declare design evidence without requiring duplicate manual links | Use an agreed trace registry record until Azure Boards can expose a suitable field or link type | Delivery lead | Field or link configuration, API responses for zero, one and several links, a no-design example, and URL-resolution results | To confirm | `EXAMPLE-BUG-001` holds two design URLs; `EXAMPLE-BUG-002` records an approved no-design reason |

#### Semantic link recovery

| ID | Working assumption | Depends on | Why it is currently used | If false | Confirmation owner | Confirmation evidence | Status | Example |
|---|---|---|---|---|---|---|---|---|
| A-16 | Versioned, permission-aware semantic profiles can be generated for work items, design, code and tests | A-01, A-06, A-07, A-08, A-10, A-12; D-20 | Cross-layer matching needs comparable keywords, concepts, tags, summaries or embeddings tied to exact source versions | Use only the profiles that can preserve identity, version and permissions; keep other link recovery deterministic | Delivery lead, with security and engineering review | One extracted profile from each source area showing source identity/version, permissions, generator/version and reproducible content | To confirm | Four illustrative profiles expose the common concepts `payment`, `approval` and `limit` while retaining different source identities |
| A-17 | A reviewed evaluation set can measure candidate retrieval and acceptance separately for each relationship type | A-16; D-21, D-22, D-23 | A model score is not a correctness probability and one combined accuracy number would hide weak link types | Keep all proposals in human review and use scores only for ranking until enough labels exist | Delivery lead, with SME reviewers | Positive, hard-negative and unresolved examples for work-item/design/code/test link types; Recall@K, precision, reviewer reasons and disagreement | To confirm | A design-to-code candidate appears in the top ten, but remains pending until the reviewer confirms `IMPLEMENTS` rather than general similarity |
| A-21 | A BDD/Gherkin acceptance-criterion statement is available as a stable, versioned property that an LLM can decompose into preconditions, trigger, expected effects and forbidden effects without inventing code symbols | A-01, A-07; D-25, D-28 | Grounding a whole Story to code is coarser than the graph needs when one Story carries several independently verifiable Given/When/Then/Never behaviors | Keep grounding at AtomicWorkItem grain until criterion-level statements are reliably retained and versioned | Delivery lead, with business analyst review | One AcceptanceCriterion decomposed into preconditions/trigger/expected and forbidden effects, checked against its statement by a business reviewer | To confirm | The obligation-netting criterion decomposes into two preconditions, one trigger and one forbidden effect without naming `AutoNettingService` |
| A-22 | A deterministic operation adapter (callers, callees, control flow, data flow, references) can front the selected code-analysis engine so an LLM never authors its structural-analysis query directly | A-18; D-29 | Direct model-authored queries against the code-analysis engine are harder to govern, repeat, secure and debug than a small fixed operation set | Allow supervised direct query authoring for a bounded pilot and tighten the adapter once real question patterns are known | Delivery lead, with application engineering review | The four to six operations used across a representative sample of grounding and verification questions, with the adapter's translated engine query and result for each | To confirm | `getDataFlow(SettlementProcessor.process.parameter.obligation, AutoNettingService.add.argument.1)` resolves to one CPGQL data-flow query |

#### Test evidence

| ID | Working assumption | Depends on | Why it is currently used | If false | Confirmation owner | Confirmation evidence | Status | Example |
|---|---|---|---|---|---|---|---|---|
| A-10 | Test Case represents intended verification, while Test Execution is dated run evidence | A-01; D-11, D-12 | Reusable test intent must remain separate from repeated results and runtime coverage | Use the available test object but record the loss of intent/execution separation | Delivery lead | One Test Case with durable ID, its automated definition, two run attempts, build IDs, separate results and coverage payload | To confirm | Illustrative Test Case `EXAMPLE-TEST-001` runs twice; each run keeps its own result, build and covered symbol versions |
| A-18 | Framework-aware analysis can discover representative Java entry points and produce bounded possible program paths across the selected repositories | A-06, A-11; D-25, D-26 | Brownfield behavior discovery needs inspectable call, branch, state and side-effect evidence rather than raw text similarity | Limit the first model to repositories and entry-point types that can be resolved; retain unresolved calls and paths with lower reachability confidence | Delivery lead, with application engineering review | For one bounded flow across 2–4 repositories, provide discovered REST/event/job entry points, the expected call chain, branch outcomes, state effects, unresolved dispatches and cross-repository contract matches | To confirm | An illustrative settlement endpoint reaches a duplicate check and a cash-movement side effect through two repositories |
| A-19 | Reviewers can agree a useful behavior-signature structure inside each semantic profile and judge cross-profile matches | A-10, A-18; D-25, D-27 | Work items, design, code and tests describe the same behavior in different forms | Keep unmatched findings as technical ProgramFacts or candidate evidence until the profile structure and review rule are agreed | Delivery lead, with business, developer and test SME review | A benchmark of 10–30 matched and unmatched work-item, design, code and test profile pairs with Given/When/Then/Never statements, source anchors, reviewer decisions and reason codes | To confirm | Work-item criteria, a design rule, a duplicate-check code path and a test assertion all describe reusing an existing settlement without creating another cash movement |
| A-20 | Static test structure, per-test runtime coverage and selected mutation results can be tied to exact TestDefinitions, TestExecutions and CodeSymbolVersions | A-10, A-18; D-26, D-27 | Coverage alone does not prove that the expected result or forbidden side effect is checked | Use the evidence types that are available and report `insufficient_evidence`; reserve `dynamically_proven` for tests with suitable mutation or known-fault evidence | Delivery lead | For selected tests, provide parsed fixtures/mocks/assertions, per-test branch coverage where available, exact tested build and symbol versions, and targeted mutation or historical-defect results | To confirm | A test executes the duplicate branch, asserts the same settlement and fails when the no-new-cash-movement rule is mutated |

#### History and governance

| ID | Working assumption | Depends on | Why it is currently used | If false | Confirmation owner | Confirmation evidence | Status | Example |
|---|---|---|---|---|---|---|---|---|
| A-12 | Historical evidence can be retained while current state is presented as a view | None | Audit and explanation require old PRs, design versions, deleted code and failed tests | Define retention limits and mark historical answers as incomplete outside them | Data-governance and security owners | Retention policy, access model and deletion requirements for every source | To confirm | A deleted method remains queryable at commit `d92f...`, while the current-state view marks it inactive |

### Validation evidence for the Delivery lead

Provide sanitized real responses where possible. Keep original field names, object shape and relationships even when names, IDs or text must be hidden. A screenshot is useful for a policy or user-interface check, but it does not replace the API response needed to design extraction.

| Validation | Exact evidence to provide |
|---|---|
| Allowed work-item types | Work-item type definitions for every Azure DevOps process/project in scope; for each type, purpose, backlog level, hierarchy rules, PR-link behavior, acceptance-criteria support and completed examples; mark whether it may serve as the atomic implementation anchor |
| One implementation item on a PR | Branch-policy or validation configuration; API responses for test PRs with zero, one and two linked implementation items; include both a Story and a Bug case and the result of each check |
| One PR per work-item–Repository pair | Two PR records with the same work-item and Repository IDs; the validation log showing the second is blocked or flagged; one Story or Bug with valid PRs in two different repositories |
| Reproducible final comparison | Completed PR response with project ID, Repository ID, PR ID, status, source and target branches, base and target commit SHAs, completion SHA and merge strategy; saved API file list; regenerated comparison with matching paths and change types |
| File extraction | For 3–5 completed PRs, source API file lists and extractor output covering add, change, delete and rename; include at least one generated, binary, configuration or unsupported file and show its fallback result |
| Symbol and dependency extraction | Before and after source, changed line ranges, expected and actual symbols, and dependency edges; include Java overloads and JavaScript/TypeScript exports, plus rename, move and delete cases |
| Confluence identity and history | Raw page responses for one page and at least two versions with page ID, space ID/key, title, status, version number, version time/author, body representation, parent or ancestor path and web link |
| Confluence permissions | The separate restrictions response for the same page showing read and update restrictions for users or groups; names may be hidden, but retain field names, counts and structure |
| Confluence design-unit size | 5–10 representative pages across enterprise, business analysis, architecture and detailed design; heading tree, tables, diagrams or macros, and two versions; mark proposed units and explain why each remains understandable on its own |
| LLM link suggestions | Agreed positive and negative work-item-to-design examples, model output with quoted evidence, model version and ranking score, plus reviewer accept/reject decisions; 20 or more pairs is a useful starting sample |
| Work-item design-link field | Azure Boards configuration and API payloads for zero, one and several Confluence references; explicit no-design reason; valid, broken and restricted link results |
| Four semantic profiles | One work item, design unit, code symbol and Test Case profile with source version, permissions, keywords/concepts, human and AI tags kept separate, summary/embedding reference and generator version |
| Candidate-link evaluation | Reviewed positive, hard-negative and unresolved pairs for each relationship type; candidate Recall@K, accepted precision, reviewer reason codes and disagreement rate |
| Test traceability | Durable Test Case ID, linked Story, automated test definition, two executions including a retry, build IDs, separate results and raw coverage payload |
| Brownfield behavior extraction | One bounded Java flow across 2–4 repositories; discovered entry points; expected and extracted calls, branches, material data flow, state effects and unresolved edges; behavior signatures inside code profiles with exact source anchors and reviewer decisions |
| Regression-gap evidence | For 10–30 benchmark behavior signatures, relevant TestDefinitions, parsed fixtures/mocks/assertions, per-test branch coverage when available, mutation or historical-defect results, evidence level, gap outcome and reviewer reason |
| Symbol-to-Component mapping | Component source, mapping rule, build or module evidence, sample matched symbols, shared symbols, unmapped symbols and reviewer decision |

### Architecture decision log

| ID | Decision | Reason | Main consequence or exception |
|---|---|---|---|
| D-01 | Use C4-style progressive detail for this modeling exercise only, not as an assumed team standard | The user finds the move from business scope to connected overview to subject detail useful; no team-wide C4 practice has been confirmed | The documents define their own levels and navigation and do not rely on readers already knowing C4 |
| D-02 | Make `AtomicWorkItem -> PullRequest -> Repository` the primary implementation path, with one PR per work-item–Repository pair | Each PR has one allowed atomic work item and one Repository; one work item may have several PRs across repositories; each PR final comparison supplies one reviewed code-change set | Enforce uniqueness for work-item ID plus Repository ID; commits remain history inside each PR |
| D-03 | Do not make the atomic work item the parent of design, components, code or tests | Those records have independent identities and lifecycles and may serve many work items | Connect them with named relationships carrying evidence and time |
| D-04 | Do not store routine work-item IDs in source-code comments | The full reasoning is listed below | A lasting business rule or design explanation may still belong in a code comment |
| D-05 | Treat a diff hunk as evidence, not the impact unit | Hunk boundaries are created for patch display and can split one method or combine nearby items | Parse affected lines into FileChange and SymbolChange records |
| D-06 | Separate Code Symbol from Code Symbol Version | A stable method/function identity must survive several commits, while historical analysis needs the exact version | Version identity includes Commit SHA or source snapshot |
| D-07 | Store one directed `DEPENDS_ON` relationship | One relationship supports outbound traversal forward and inbound traversal backward | Do not store a duplicate inverse relationship |
| D-08 | Keep solution structure separate from repository structure | Components may span repositories and repositories may contain several components | Model Component-to-Repository as many-to-many where required |
| D-09 | Link an atomic work item to exact versioned Confluence content through a Design TraceLink; keep the design-unit size open until validated | Page-level links may be too broad, but heading sections and paragraphs are not automatically meaningful graph units | Use PageVersion until a semantic design-unit rule is approved; retain evidence, ranking score, status, review and valid time |
| D-10 | Use deterministic evidence before LLM suggestions | Explicit IDs, Git links and source history are more dependable than semantic similarity | Model-generated links remain suggested until accepted |
| D-11 | Separate Test Case, Test Definition, Test Execution and Test Result | Intended behavior, executable code, a run attempt and its outcome change independently | A retry creates another execution/result rather than overwriting the first |
| D-12 | Record runtime coverage from Test Execution to Code Symbol Version | Coverage is observed for one build and run, not permanently true for a Test Case | Test Case-to-code views are calculated summaries |
| D-13 | Put foreign keys and link tables only in a relational loading model | Graph relationships provide the logical links; SQL staging still needs referential checks | The graph and relational loading schema are separate deliverables |
| D-14 | Keep inferred links incomplete when evidence is incomplete | A fully connected but incorrect graph would produce misleading impact results | Missing, suggested, conflicting and accepted states remain visible |
| D-15 | Allow shortcut links only when their detailed evidence path can be rebuilt | Aggregated Feature-to-Component views are useful but must remain explainable | Store derivation rule, source link IDs, time and freshness |
| D-16 | Derive fine code attribution from each completed repository-specific PR final comparison | Individual commits may be rearranged or squashed while the base-to-target comparison still describes the reviewed result | Store both commit SHAs, comparison rule and extraction version for every PR; the work-item result is the union across its repositories |
| D-17 | Connect `CodeSymbol` directly to `Component` with `IMPLEMENTS` | Repository, Module and File describe source location, but none is guaranteed to match the solution component boundary | The mapping needs evidence, valid time and a named method; do not infer it from Repository alone |
| D-18 | Keep declared Confluence design references in a structured field or link on the atomic implementation work item | The work item is already the controlled delivery-intent record and can hold several design references or an explicit no-design reason | Resolve each URL to page ID, optional anchor and observed PageVersion; a page-only link does not assert links to every unit on that page |
| D-19 | Make traceability a delivery-practice change with measurable compliance checks | The graph cannot remain reliable if new work continues to omit source links | Check allowed work-item type, one item per PR, work-item–Repository uniqueness, design disposition, test disposition and reproducible PR evidence; introduce observe, warn and gate stages |
| D-20 | Build versioned semantic profiles for work items, design, code and tests | Keywords, concepts, tags, summaries and embeddings help bridge different vocabularies across the four areas | Profiles remain derived evidence tied to source versions; accepted graph links connect the real source entities, not embeddings or summaries |
| D-21 | Recover missing links through relation-specific, multi-signal candidates | Shared words or vector similarity alone show related subject matter, not that code implements a requirement or a test verifies it | Combine exact evidence, lexical search, embeddings, structure, history, coverage and top-candidate LLM judgement; store the evidence breakdown |
| D-22 | Represent every non-deterministic proposal through a governed TraceLink before acceptance | AI-generated links need an identity, lifecycle, evidence, reviewer decision and version history | Use candidate, pending, accepted, rejected, suspect and superseded states; attach evidence to a matching existing assertion and do not expose a raw model score as correctness probability |
| D-23 | Treat shared keywords and tags as candidate evidence, except for an exact controlled source identifier | A shared business term can describe the same domain without proving implementation or verification | Retain human and AI tag origins separately; an exact governed work-item ID may be deterministic, while ordinary tag matches require other evidence and review |
| D-24 | Store one current TraceLink for the same source, target and relationship type | Declared, deterministic and semantic methods may produce evidence for the same statement; duplicate links would over-count relationships and confuse impact traversal | `TraceLink` points to its endpoints with `SOURCE` and `TARGET`; attach all evidence with `SUPPORTED_BY`, and create a replacement with `SUPERSEDES` only when the assertion changes |
| D-25 | Extend all four semantic profiles with comparable behavior signatures; do not create a standalone Behavior node | Direct text similarity can find a related subject but cannot reliably state that code implements a work item or design, or that a test verifies code | Work-item, design, code and test profiles express behavior with the same structure; accepted TraceLinks still connect the real source entities |
| D-26 | Keep architecture structure, possible program paths and observed runtime execution distinct | Repository dependencies, static reachability and a path executed for one input answer different questions | Use ProgramPath and ProgramFact for bounded static possibilities; retain runtime coverage as dated TestExecution evidence against exact CodeSymbolVersions |
| D-27 | Model a regression gap as dated deficit TraceEvidence tied to exact snapshots | Failure to retrieve a similar test does not prove that no test exists, and line coverage does not prove verification | Record `gap_candidate`, `insufficient_evidence` or `not_applicable`, together with evidence level, code and test snapshots, review state and contradicting evidence |
| D-28 | Ground behavior signatures at AcceptanceCriterion grain, through an iterative behaviour-evidence graph rather than a linear pipeline | A single work item can carry several independently gradeable Given/When/Then/Never behaviors; treating candidate generation, code grounding, program verification and test verification as one strict sequence discards evidence that should feed back into an earlier stage | Add `GROUNDED_BY_CODE` as a `TraceLink.relationType` from AcceptanceCriterion to CodeSymbol; let new program or test evidence revise an existing candidate's ranking score instead of only appending forward |
| D-29 | Call the selected code-analysis engine through a deterministic operation adapter, and classify a sufficiently evidenced gap into a named business-facing subtype | Letting a model author ad hoc structural-analysis queries directly harms governance, repeatability and security; a single generic `gap_candidate` outcome does not tell a reviewer what kind of gap they are looking at | Express program-analysis questions as calls to a small fixed operation set (callers, callees, control flow, data flow, references) that a rule-based adapter turns into engine queries; add a `gapType` of `regression_test_gap`, `implementation_gap` or `partial_test_gap` alongside the existing deficit-evidence outcome, once evidence is sufficient to classify |

### Link creation policy

The detailed policy is in [AI SDLC link creation and recovery](./AI-SDLC-link-creation-and-recovery.md), with the flow shown in [semantic link creation and recovery](./diagrams/ai-sdlc-semantic-link-recovery.html).

For future delivery, keep source-declared links where work happens: the implementation work-item link on the Azure Repos PR, the Confluence design reference on the Story, Bug or other allowed atomic work item, and the Test Case relationship in the test-management source when available. The graph imports these links with their source identity and time. It does not require people to maintain the same link manually in both systems.

For brownfield gaps, build versioned semantic profiles for work items, design, code and tests. Use their keywords, concepts, human and AI tags, summaries and embeddings together with deterministic structure, history and coverage to generate relation-specific candidates. Accepted links connect the real source entities; semantic profiles remain evidence.

Introduce compliance in three stages: observe and measure, warn in the normal delivery workflow, then gate only rules whose ownership and false-block rate have been accepted.

#### Why routine work-item IDs do not belong in code comments

Staleness is only one problem. Routine Story annotations in methods, classes or files are rejected as the main linking practice for these reasons:

1. **The relationship is many over time.** The same method can be created for one Story and later changed for many others. One comment cannot represent the full contribution history without becoming a growing manual list.
2. **Refactoring changes location, not business history.** Code may be renamed, split, merged, moved or copied. A comment follows whichever text was moved, while the Story contribution may apply to only part of the new code or to several new symbols.
3. **Deletion removes the annotation.** When code is deleted, the Story link disappears from the current source even though historical explanation still needs it.
4. **Comments are not a controlled relationship store.** They cannot reliably hold link origin, evidence, ranking score, status, reviewer, valid time, rejection state or access rules.
5. **They create two sources of truth.** Azure Boards and Git already contain work-item and commit history. A second manually maintained ID inside code will eventually disagree with them.
6. **They couple code to one tracking system.** Story IDs may collide across Azure DevOps projects, change during migration, or be meaningless when code is reused in another product or organization.
7. **Coverage would be uneven.** Generated code, configuration, SQL, scripts and third-party code cannot follow the same comment convention, so apparent completeness would be misleading.
8. **They expose business metadata unnecessarily.** Repository readers may gain access to sensitive work-item identifiers or business context that has stricter permissions in Azure Boards or Confluence.
9. **They add review and maintenance noise.** Developers would spend time updating tracing comments during routine refactoring, and reviewers could not easily prove that every annotation remains correct.
10. **Azure Boards and Git already provide the trace path.** The enforced work-item-to-PR link plus the PR base/target commit SHAs, final comparison and parsed SymbolChanges reconstructs the fine code link with time and evidence, without modifying executable source.

Code comments should still explain a lasting business rule, safety constraint or non-obvious design reason that a maintainer needs while reading the code. The comment should explain the rule itself; an external decision or design link may be included when it is stable and useful, but a transient Story ID should not be the only explanation.

### Draft business activities

| Activity | Business outcome | Main records | Minimum human action | Links software can add | SME should confirm |
|---|---|---|---|---|---|
| Shape a change | A business capability or change is agreed | Epic, Feature, owner, affected area | Create the Feature and ownership | Read existing hierarchy and component ownership | Where are Epics and portfolio goals held? |
| State the need | The change is small enough to build and test | Atomic Work Item, Acceptance Criteria, Task | Put the work item under a Feature where required; write testable criteria | Read parent/child links and named components | Which work-item types are allowed to anchor implementation? |
| Prepare design | Business rules and technical choices are recorded | Confluence page/content, decision, business rule | Link the work item or Feature to the design, or record that no design is needed | Read page ID, content anchor, version and replacement history | Which changes need business design, technical design or an exception? |
| Implement change | Reviewed code changes can be traced to intent | Pull Request, Repository, Commit, GitDiff, FileChange, SymbolChange, CodeSymbol | Enforce one AtomicWorkItem on each PR and at most one PR for each work-item–Repository pair | Parse each completed PR final comparison into file and symbol changes | Which cases genuinely require a second PR for the same work item and Repository? |
| Define verification | Expected behavior has a durable test link | Test Case, automated test, suite, purpose | Link important acceptance/system/end-to-end tests to the AtomicWorkItem or Feature | Discover unit/component tests and suite membership | Where should work-item/test links be stored: Test Plans, metadata file or both? |
| Run verification | A dated result proves what ran against which build | Test Run, Test Result, Build, Environment | Normally none beyond existing test work | Test -> Run -> Result -> Build/Commit; coverage -> code | Which pipelines and environments produce usable evidence today? |
| Release or deploy | A release can be explained by included changes and results | Release, deployment, approval, environment | Follow the existing approval process | Release -> Build -> Commit -> work item and test evidence | What is the release record and source of truth? |
| Maintain and assess impact | Teams understand why code exists and what may be affected | Current component/code, dependency, owner, history | Keep component ownership and key design current | Calls, dependencies, code history, covering tests and related work items | Which dependency and ownership sources are trusted? |

### Draft shared business objects

These are the high-level objects for the first business model. Detailed types can be added later without changing the overall shape.

| Object group | Suggested high-level objects | Main source | Why it matters |
|---|---|---|---|
| Change intent | Feature, Story, Acceptance Criterion | Azure Boards | Explains why a change exists |
| Design knowledge | Design Page, Versioned Design Content, Decision, Business Rule | Confluence | Explains intended behavior and choices; content size remains to be validated |
| Product structure | Domain, Solution, Component, Module | Architecture/service records plus code | Provides stable grouping above files and methods |
| Change history | Pull Request, Commit | Azure Repos | Provides reviewed and dated change evidence |
| Code | Repository, File, Class, Function/Method, Code Version | Git plus code parsers | Shows the actual implementation |
| Test intent | Test Case, Automated Test, Test Suite | Test Plans and repositories | States what behavior should be checked |
| Run evidence | Build, Test Run, Test Result, Environment, Release | Pipelines and test tools | Proves what happened at a particular time |
| Responsibility and access | Team, Owner, Source System, Access Rule | Existing identity and ownership sources | Keeps answers owned and permission-safe |

### Graph bus matrix

This adapts the dimensional-model bus matrix. Rows are business activities. Columns are shared graph objects. Each cell says how the activity uses the object.

The matrix is the best workshop tool for checking scope and finding missing links. It should be used together with the activity flow, not instead of it.

| Business activity | Change intent | Design knowledge | Product structure | Change history | Code | Test intent | Run evidence | Owner/access |
|---|---|---|---|---|---|---|---|---|
| Shape a change | **Creates Feature** | Reads domain context | Names affected area | - | - | Defines test approach | - | Assigns owner |
| State the need | **Creates Story and criteria** | Links when needed | Names component | - | - | Sets expected behavior | - | Uses team access |
| Prepare design | Links Feature/Story | **Creates or updates design** | Describes solution/component | - | May name key code area | Defines scenarios | - | Records owner/status |
| Implement change | Links Story/Bug | Reads design | Selects repository/component | **Creates PR and commits** | **Changes files and symbols** | Adds/updates automated tests | Produces build when available | Uses repository access |
| Define verification | Links Story/criteria | Reads rules and design | Names tested component | May refer to PR | Points to tested area | **Creates Test Case/test definition** | - | Uses test access |
| Run verification | Reads linked Story | Reads expected behavior | Identifies component | Binds to commit/build | Adds coverage evidence | Selects tests/suites | **Creates run and result** | Uses environment access |
| Release or deploy | Groups included Stories | Reads approved design | Identifies deployed components | Uses merged commits | Uses built version | Uses required test set | **Creates release evidence** | Records approval/access |
| Maintain/impact | Explains past reasons | Shows current/replaced design | **Finds owner and dependencies** | Reads full change history | **Finds current and past code** | Finds covering tests | Reads latest trusted result | Checks caller access |

Use these questions to review every row with the SME:

1. Is this a real business activity or only a system action?
2. Who is responsible for it?
3. What record proves it happened?
4. Which link must a person or source system create?
5. Which links can software safely work out?
6. What does “complete” mean for this activity?
7. Which users may see the object and its content?

### Recommended visual set

| Visual | Best question | Use in SME session |
|---|---|---|
| Business activity flow | How does change and evidence move through the SDLC? | Correct the sequence, work streams, hand-offs and current gaps |
| Graph bus matrix | Which shared objects does each activity create, link or read? | Check scope, ownership and missing object groups |
| Target graph data model | How do Story, design, fine code changes, tests and solution structure connect? | Agree the target records, relationship meanings, evidence and quality states |
| Detailed model by area | What is the exact level of detail, ID and history rule? | Work with each specialist after the high-level model is agreed |

A normal flowchart alone is not enough because it makes the SDLC look like one strict pipeline. The initial investigation shows that design, implementation and testing can move on partly independent paths. The activity flow therefore uses separate work streams, while the bus matrix checks that the same shared objects are used consistently.

## Executive recommendation

Use the discipline of dimensional modeling, but not its fact/dimension shape.

Retain these habits:

- start with business processes and decisions;
- define the questions the model must answer;
- declare the exact level of detail before fields and relationships;
- use shared IDs and agreed terms;
- separate the high-level, detailed, and stored models;
- validate with representative queries and data-quality rules;
- publish governed aggregate views for consumers.

Replace these dimensional assumptions:

| Dimensional-model habit | Graph-model equivalent |
|---|---|
| Business process selects a fact table | Business activity selects the connected objects and starting points it needs |
| Declare the fact-table level | Declare object identity, relationship meaning, version level, and when each record is valid |
| Dimensions provide context | Context is represented by graph objects and named relationships |
| Conformed dimensions connect stars | Shared IDs and agreed relationship names connect each subject area |
| Rollups are stored aggregates | Rollups are named graph views or derived relationships with a path back to their evidence |
| Slowly changing dimensions preserve history | Unchanged historical versions, dated relationships, and current-state views preserve history |

The main design principles are:

> Define one target graph for new changes and brownfield recovery. The target meanings do not change; only the way links are collected changes.

> Build the graph at the finest useful level of detail, but never claim more precision than the evidence supports. Every uncertain link must remain visibly uncertain.

> An allowed Atomic Work Item is the main business-intent anchor. Story and Bug are confirmed source types. The target connects the work item, design, code, tests and solution structure. Component-level links help discovery and grouping, but they do not replace work-item-to-design or work-item-to-code links.

## Target graph data model

Define the target graph before choosing new-work controls or brownfield recovery techniques. Both approaches must produce the same node types, link types, evidence fields, and quality states.

### Target end-to-end paths

```text
Feature -> AtomicWorkItem -> PullRequest -> GitDiff -> FileChange -> SymbolChange -> CodeSymbol

Design TraceLink -[SOURCE]-> AtomicWorkItem
Design TraceLink -[TARGET]-> VersionedDesignContent
Test TraceLink   -[SOURCE]-> AtomicWorkItem
Test TraceLink   -[TARGET]-> TestCase

TestCase -> TestDefinition -> TestExecution -> TestResult

PullRequest -> Commit
PullRequest -> Repository
CodeSymbol -> File -> Module -> Repository
CodeSymbol -> Component -> Solution
TestExecution -> COVERS -> CodeSymbolVersion
```

Cross-area statements use a governed `TraceLink` node because evidence, review history, versioning and security must be attached and queried consistently. The `TraceLink` points to the real source and target; semantic profiles and TraceEvidence explain how the statement was found.

### Core target objects

| Object | Exact level | Purpose |
|---|---|---|
| AtomicWorkItem | One allowed implementation-level Story, Bug or other approved source type | Main anchor for why design, code and tests exist; this is a shared role label, not a copied record |
| VersionedDesignContent | Working level below or at PageVersion; its final size is still open | Identifies exact design content without assuming one heading section or one paragraph is always correct |
| TraceLink | One governed statement connecting a real source and target for one relationship type | Holds origin, status, scores, evidence, review history and effective time; Design, Code and Test TraceLinks are views of this node type |
| PullRequest | One reviewed change proposal in one repository | Implements exactly one allowed AtomicWorkItem; the work item may have one PR in each affected Repository |
| Commit | One immutable repository revision | Provides build and change history inside a PR; it is not the Story attribution boundary |
| GitDiff | One comparison between a base commit and a target commit | Defines exactly which two Git trees were compared; it can represent a commit diff or the final PR diff |
| FileChange | One file path added, modified, deleted, moved, or renamed in one GitDiff | Stores file status and diff hunks without treating each hunk as a business object |
| SymbolChange | One Java or JavaScript/TypeScript class, function, method, interface, or export affected by one FileChange | Provides the preferred fine code unit for work-item attribution and impact analysis |
| CodeSymbol | One logical class, function, method, interface, or export across versions | Provides the stable code identity used by call and dependency relationships |
| CodeSymbolVersion | One CodeSymbol at one commit or source snapshot | Supports exact historical explanation and before/after comparison |
| Component/Solution | One agreed implementation or solution boundary | Groups code, design, tests, dependencies, and ownership |
| TestCase | One intended behavior check | Connects an AtomicWorkItem or Acceptance Criterion to what must be verified |
| TestDefinition | One executable JUnit, Jest, or similar test | Implements a Test Case and produces build-specific executions |
| TestExecution | One attempt to run one Test Definition against one build and environment | Provides time-bound evidence and runtime coverage |
| TestResult | One outcome for one Test Execution | Records pass, fail, skipped, duration, and evidence without overwriting earlier attempts |

### Work-item-to-code target

The target implementation chain is:

```text
AtomicWorkItem -> PullRequest -> GitDiff -> FileChange -> SymbolChange -> CodeSymbol
PullRequest -> Commit                                      |          |
                                                          |          +-> Component -> Solution
                                                          +-> File -> Module -> Repository
```

A Git diff hunk is a block of added and removed lines created for display and patching. It is not a stable or meaningful code object for impact analysis. One method can contain several hunks, and one hunk can include imports, formatting, or several nearby code items.

For this Java and JavaScript/TypeScript estate:

- `GitDiff` records `repositoryId`, `baseCommitSha`, `targetCommitSha`, and whether it represents a commit comparison or the final PR comparison.
- `FileChange` records one affected path plus add/modify/delete/rename/move status and retains its diff hunks as evidence.
- `SymbolChange` is produced by parsing the file before and after the diff. It records one affected Java class/method/interface or JavaScript/TypeScript class/function/method/export, the change type, changed line ranges, and before/after symbol versions.
- `CodeSymbol` is the longer-lived identity. For Java, use repository plus fully qualified class/method name and signature. For JavaScript/TypeScript, use repository, module path, exported/local scope, symbol name, and signature where available.

The selected deterministic work-item-to-code path is:

```text
AtomicWorkItem -[IMPLEMENTED_BY_PR]-> PullRequest
PullRequest -[IN_REPOSITORY]-> Repository
PullRequest -[HAS_FINAL_DIFF]-> GitDiff
GitDiff -> FileChange -> SymbolChange -> CodeSymbol
```

The declared source relationship stops at PullRequest. Work-item-to-file, work-item-to-symbol and work-item-to-component results are calculated through the final comparison, not maintained as duplicate links. A direct Code TraceLink is stored only for an independently meaningful or recovered fine-code statement. If it asserts the same source, target and relationship type as an existing link, its evidence is attached to that link rather than creating a duplicate.

Every governed work-item-to-code assertion needs these fields:

| Field | Meaning |
|---|---|
| `sourceId` | Atomic work-item ID |
| `targetId` | Pull Request ID for the declared path, or CodeSymbol ID for a direct governed assertion |
| `contributionType` | Business implementation, test code, configuration, data change, documentation, or supporting refactor |
| `evidenceRef` | Enforced PR work-item link, policy result, final comparison, review note, or recovery evidence |
| `linkOrigin` | Declared, derived from an unambiguous rule, or suggested |
| `rankingScore` | Raw ordering score for a candidate; it is not a probability |
| `calibratedConfidence` | Acceptance probability only after validation against representative reviewer decisions |
| `status` | candidate, pending, accepted, rejected, suspect or superseded |
| `validFrom`, `validTo` | Period for which the attribution applies when it is time-bound |

### How the fine code link is built

For a new change:

1. Azure Boards supplies the allowed AtomicWorkItem, currently confirmed as Story or Bug.
2. Identify every Repository the work item will change. Azure Repos supplies one PR for each affected Repository, its commits, and the completed PR base and target commit SHAs.
3. For each PR, compare its base and target trees to create one final GitDiff and its FileChanges. This final GitDiff, not the per-commit GitDiff behind each individual commit, is the one parsed into FileChanges and SymbolChanges; per-commit diffs remain raw history evidence so a file touched by several commits inside the PR is not attributed twice.
4. Parse the before and after Java or JavaScript/TypeScript source to find which classes, functions, or methods intersect the changed lines. Create one SymbolChange per affected symbol, not one per diff hunk.
5. Attribute all parsed SymbolChanges and unparsed FileChanges in each PR final comparison to its one AtomicWorkItem through the evidence path; do not create duplicate maintained work-item links at every level.
6. Reject completion when a PR names several atomic implementation work items or the same work-item–Repository pair has a second implementation PR, unless an approved exception is recorded.

One AtomicWorkItem may have several repository-specific PRs, and each PR may contain many commits. Commit messages may mention the work item for navigation, but fine attribution comes from the enforced work-item-to-PR relationship and each PR final comparison.

Use an Azure Repos PR policy or validation check to require exactly one allowed AtomicWorkItem and to ensure the same work item is not already assigned to another active or completed implementation PR in that Repository. If squash merge is used, retain the completed PR base and target commit SHAs and final comparison so the fine code path remains reproducible.

Do not put routine work-item IDs in code comments. The consolidated reasoning is recorded in architecture decision D-04: the relationship is historical and many-over-time, refactoring and deletion break location-based annotations, comments cannot carry evidence and status, and Git already supplies the immutable join point. Use a code comment only for a lasting business rule or design decision that a maintainer needs to understand in the source.

### How fine code drives impact analysis

Impact analysis starts from `CodeSymbol`, not from the diff hunk:

1. use the work-item link to find its SymbolChanges;
2. resolve added or modified changes to the after-version CodeSymbol, and deleted changes to the before-version CodeSymbol;
3. follow incoming calls, imports, inheritance, interface implementation, build dependencies, API use, events, and data-contract dependencies at the selected point in time;
4. roll affected symbols up to files, modules, components, repositories, and solutions;
5. retrieve tests, owners, design and other work items only after the technical impact set is known.

For brownfield data, if only a FileChange link is available, the impact seed is every relevant symbol in that file, so the result is broader. If only historical Commit evidence is available, parse its FileChanges and SymbolChanges but keep work-item attribution ambiguous unless supporting evidence resolves it.

### Precision rules for work-item-to-code links

- Enforce AtomicWorkItem-to-PR as one-to-many: a work item has zero or more PRs while planning and one or more when code is implemented; every production PR has exactly one allowed work item.
- Enforce PullRequest-to-Repository as many-to-one and allow at most one PR for each work-item–Repository pair.
- A PR may have many commits, but all changes remaining in its completed final comparison belong to its one AtomicWorkItem.
- Do not create separately maintained work-item-to-commit, work-item-to-file-change or work-item-to-symbol-change links for the same PR evidence; calculate them from the PR path.
- Parse FileChange and SymbolChange only from the PR's final GitDiff; treat each commit's own GitDiff as unparsed history so the same edit is never counted at both the commit level and the final-comparison level.
- A PR with several atomic implementation work items fails the rule and must be split before merge or handled as a documented exception.
- A suggested method link may help discovery, but it must not be used as accepted fact in audit or impact answers.
- Keep current code dependencies separate from historical work-item contributions. Technical impact starts with changed/current code and follows current calls and dependencies. Work items are retrieved afterward to explain why affected code exists.

### Work-item-to-design target

The working target relationship is:

```text
Design TraceLink -[SOURCE]-> AtomicWorkItem
Design TraceLink -[TARGET]-> VersionedDesignContent
ConfluencePage -[HAS_VERSION]-> PageVersion -[HAS_DESIGN_CONTENT]-> VersionedDesignContent
```

A page-level link is allowed when the whole page is about one work item. Below that, do not assume a heading section or paragraph is automatically the right unit. The working `VersionedDesignContent` unit may contain one heading section, several connected sections, a table or diagram with its explanation, or a standalone rule or decision. One unit may inform several work items and one work item may use several units.

A heading section is a source-structure unit: the content below one heading until the next heading at the same or higher level. A paragraph is only one text block between breaks and usually depends on surrounding headings, tables or diagrams. A semantic design unit is different: it is the smallest versioned piece that remains understandable and reviewable on its own. The last definition is the recommended graph level, but its extraction and stability must be validated through A-08 before it becomes final.

To traverse different levels and perspectives, retain `parentUnit`, `headingPath`, `unitType`, `scopeLevel` and `viewType`. Suggested `scopeLevel` values are enterprise, domain, solution, component and delivery. Suggested `viewType` values include business analysis, solution architecture, component design, detailed design, business rule and decision.

The Design TraceLink is a `TraceLink` with a design relationship type. It carries origin, ranking score, calibrated confidence when available, status, validity and security, and points to its inspectable evidence. A Component or Solution link can support discovery, but it does not replace the target work-item-to-design statement.

### Same target, two achievement approaches

| Concern | New changes | Brownfield recovery |
|---|---|---|
| Work item to PR | Enforce exactly one allowed AtomicWorkItem per PR and at most one PR per work-item–Repository pair | Import existing work-item links; record compliant, missing, conflicting and exception states honestly |
| Work item to commit | Retain commits as PR history; a separate work-item link is optional navigation, not attribution | Recover commit references as supporting evidence without assuming they satisfy the new pair rule |
| Work item to file or method | Parse the completed PR final comparison and calculate fine links through FileChange and SymbolChange | Rebuild historical PR comparisons where possible; use deterministic evidence first and proposals only for unresolved cases |
| Work item to design | Keep structured Confluence references on the work item or an explicit no-design reason; resolve them to the supplied page or design-content precision | Read existing links and IDs first; when historical links are absent, compare work-item and design profiles and propose reviewed Design TraceLinks |
| Link quality | Prevent new gaps at source and review exceptions in the normal workflow | Preserve accepted, suggested, missing, and conflicting states; prioritize review by business value and risk |
| Human work | Confirm exceptions and ambiguous allocations, rather than annotate every method | Review a selected high-value queue, rather than backfill every page and code item manually |

The selected new-work practice is:

1. require exactly one allowed AtomicWorkItem on every production PR;
2. allow one work item to use several repositories, but prevent a second implementation PR for the same work-item–Repository pair;
3. allow several commits inside each PR;
4. parse the completed PR final comparison into file and symbol changes;
5. calculate work-item-to-file, work-item-to-symbol and work-item-to-component results through that path;
6. use the same work item across repositories when the business intent is the same; create another work item only when the business scope is genuinely separate.

For brownfield recovery, an LLM is one candidate generator, not the source of truth. Its output must identify the proposed work item, versioned design unit or code symbol, the supporting source excerpts or diff, ranking score, model version and status. Deterministic evidence always takes priority. If deterministic and semantic methods assert the same source, target and relationship type, attach both evidence sets to one TraceLink.

## What “aggregate” means in this graph

An aggregate graph is a view of the shared detailed graph for a particular audience or use. It is not a separately maintained summary model.

For example, an aggregate relationship:

```text
Feature F-8420 -[IMPLEMENTED_BY]-> Component cards-api
```

may be derived from this evidence path:

```text
Feature F-8420
  -[HAS_WORK_ITEM]-> Story US-8421 (AtomicWorkItem)
  -[IMPLEMENTED_BY_PR]-> PullRequest PR-617
  -[HAS_FINAL_DIFF]-> GitDiff base456..abc123
  -[CONTAINS_FILE_CHANGE]-> FileChange src/cards/LimitService.java
  -[CONTAINS_SYMBOL_CHANGE]-> SymbolChange SC-617-08
  -[AFFECTS]-> CodeSymbol calculateLimit
  -[IMPLEMENTS]-> Component cards-api
```

The convenience edge is safe only when it records its derivation rule, source path or evidence reference, observation time, and freshness. The detailed path remains authoritative.

## Modeling lifecycle

### Stage 1 - Frame the business process and decisions

Start with the work people perform and the decisions they need to make, not with graph technology or source-system tables.

Inputs:

- business processes and lifecycle stages;
- actors and responsibilities;
- source systems and security boundaries;
- audit, compliance, and AI-assistance needs;
- representative brownfield and new-delivery cases.

Produce a business-question list. Each question must identify the expected answer, how far the graph may be followed, the required point in time, and the permitted evidence level.

Representative questions:

| ID | Business question | Required path | Time view |
|---|---|---|---|
| CQ-01 | What implements Feature F-8420? | Feature -> AtomicWorkItem -> PR final comparison -> SymbolChange -> CodeSymbol -> Component | Current |
| CQ-02 | Why does `calculateLimit()` exist? | CodeSymbol <- SymbolChange <- PR final comparison <- AtomicWorkItem; Design TraceLink -> work item and design/rule | Historical |
| CQ-03 | What could break if this method changes? | Current code item -> current callers/dependencies -> components/tests/owners; retrieve work items afterward for explanation | Current plus latest evidence |
| CQ-04 | Does an AtomicWorkItem have sufficient release evidence? | Work item -> design, PR/build and test execution/result | Release snapshot |
| CQ-05 | Which active components have only a suggested design link? | Component -> design link, filtered by link origin | Current |

Gate: do not continue until the priority questions, authorized users, and required time perspective are explicit.

### Stage 2 - Create the conceptual aggregate graph

Model business concepts and the few relationships needed to answer the priority questions. Avoid source-specific IDs, implementation fields, and exhaustive taxonomies.

Recommended conceptual domains:

| Domain | Business purpose | Stable anchor concepts |
|---|---|---|
| Delivery intent | Explain why change was requested | Epic, Feature, Story, Acceptance Criterion |
| Design knowledge | Explain intended behavior and governing decisions | Design Artifact, Versioned Design Content, Decision, Business Rule |
| Implementation | Explain how and where change was realized | Component, Pull Request, Commit, Code Symbol |
| Verification | Explain what behavior is checked | Test Case, Test Definition, Test Suite |
| Execution evidence | Prove what happened at a point in time | Build, Test Execution, Test Result, Environment, Release |
| Organization and governance | Explain ownership, access, and policy | Team, Person/Agent, System of Record, Access Policy |

The conceptual backbone is:

```text
Feature -> AtomicWorkItem -> PullRequest -> GitDiff -> SymbolChange -> CodeSymbol
Design TraceLink -> AtomicWorkItem + VersionedDesignContent
Test TraceLink   -> AtomicWorkItem + TestCase -> Execution Evidence

Component connects design, code, ownership, dependencies, and tests.
```

AtomicWorkItem is the primary change-intent role. It is not the universal root: components, code, design, tests, builds and releases have lifecycles that span many work items.

Gate: every high-level object and relationship must support at least one business question.

### Stage 3 - Decompose into connected domain and level models

Build one bounded model per domain. Within each model, distinguish containment from classification, change history, semantic linkage, and execution evidence.

Each domain model must declare:

1. scope and questions;
2. node types and their exact level of detail;
3. shared identity and source identity;
4. containment or hierarchy relationships;
5. cross-domain anchor relationships;
6. temporal and version behavior;
7. explicit, derived, and inferred link rules;
8. access-control inheritance;
9. validation constraints;
10. supported high-level views.

Gate: every domain has at least one stable cross-domain anchor. No domain is connected only by free-text similarity.

### Stage 4 - Define the detailed shared logical graph

Expand each subject area to the finest level that creates decision value. Do not equate “available in the source” with “must be a graph object.”

Detailed-object selection rules:

- create a node when the object has independent identity, lifecycle, access rules, or traversal value;
- use a property when the value has no independent lifecycle or relationships;
- use a separate version node when historical identity matters;
- use a TraceLink when its origin, status, score, evidence or approval must be queried;
- retain text chunks in a text/vector index unless they need stable graph identity;
- do not create nodes for every paragraph, source line, or transient parser token.

Gate: every detailed type has a shared ID rule, version rule, lifecycle rule, and roll-up path.

### Stage 5 - Map, implement, validate, and publish views

Map the shared types to source APIs and events, select the graph technology, enforce rules, and publish named views for AI and reporting.

Outputs:

- source-to-shared-model mapping specifications;
- graph constraints and indexes;
- incremental ingestion and reconciliation rules;
- current-state and historical views;
- user views and shortcut-link definitions;
- data-quality and traceability-coverage dashboards;
- query-based acceptance tests.

Gate: business-question queries return explainable answers with source evidence, access filtering, and a declared freshness level.

## Model hierarchy and connection contract

The levels below are deliverables, not separate databases.

| Level | Primary audience | Contains | Connects downward through | Verification |
|---|---|---|---|---|
| L0 Business scope | Business, risk, product | Processes, actors, decisions, business questions | Question-to-object coverage | Every priority question is testable |
| L1 High-level shared model | Business and architecture | Main subject areas, objects and business links | High-level-to-detailed type mapping | No technology or source detail |
| L2 Models by subject area | Subject experts and data modelers | Local hierarchies, levels of detail and internal links | Stable links between subject areas | Every area has stable links |
| L3 Shared logical graph | Data and graph engineers | Node types, relationship types, fields, number rules, time and link evidence | Source mapping and view rules | Rules and sample paths pass |
| L4 Stored graph | Platform engineers | Labels/classes, relationship storage, indexes, partitions and access strategy | Shared IDs and mapping versions | Load, query, security and scale tests |
| L5 User views | AI, reporting, controls | Current, historical, aggregate, evidence and impact views | `derivedFrom` links to detailed paths | Answers can be rebuilt from evidence |

Every type must have a traceability record across these levels:

```yaml
concept: Code Symbol
domain_model: Implementation
logical_type: CodeSymbol
physical_label: CodeSymbol
source_mappings:
  - parser: tree-sitter-java
  - parser: tree-sitter-javascript
shared_id: repository + fullyQualifiedName
version_id: shared_id + commitSha
rolls_up_to: File -> Module -> Component -> Repository
supports_questions: [CQ-01, CQ-02, CQ-03]
```

## Shared record design

### Node envelope

All graph objects should use a common set of basic fields. Area-specific fields are added only where needed.

| Field | Meaning |
|---|---|
| `sharedId` | Stable graph identity independent of mutable title or URL |
| `type` | Agreed graph object type |
| `sourceSystem` | System of record |
| `sourceId` | Native immutable or most stable source identifier |
| `uri` | Navigable source reference |
| `title` | Human-readable current label |
| `status` | Controlled lifecycle state |
| `ownerRef` | Team/person/agent identity |
| `classification` | Information classification |
| `aclRef` | Source ACL or security reference |
| `validFrom`, `validTo` | Business validity where applicable |
| `observedAt` | When the source state was observed |
| `textRef` | Reference to retrievable content, not duplicated graph text |
| `schemaVersion` | Shared model mapping version |

### Common link record

Relationships are evidence-bearing statements, not anonymous arrows.

| Field | Meaning |
|---|---|
| `sourceId`, `targetId` | Shared IDs of the two real linked objects |
| `relationship` | Agreed relationship name |
| `linkOrigin` | `declared`, `derived`, `human-suggested`, or `ai-suggested` |
| `method` | Source link, parser, coverage tool, rule, or model that created it |
| `evidenceRef` | Link to source event, diff, metadata, coverage, or inference evidence |
| `rankingScore` | Raw score used to order candidates; not a probability |
| `calibratedConfidence` | Acceptance probability only after validation against representative reviewer decisions |
| `status` | candidate, pending, accepted, rejected, suspect or superseded |
| `classification`, `aclRef` | Relationship-level information classification and source ACL reference, populated when the link or its evidence is more sensitive than either endpoint alone |
| `validFrom`, `validTo` | When the statement was true |
| `observedAt` | When it was captured or recomputed |
| `createdBy` | Human, service, parser, or model identity |
| `methodVersion` | Rule/parser/model version |
| `approval`, `reviewDecision`, `reviewReason` | Human validation timestamp, decision and reason code |
| `derivedFrom` | IDs of the detailed links used to create a shortcut relationship |

This table is a compact summary; the [graph logical data dictionary](./AI-SDLC-graph-logical-data-dictionary.md)'s common relationship fields section is the controlled list. In a labeled property graph these may be relationship fields. Store a link as its own node when the chosen database cannot properly search, secure, version, or connect evidence attached directly to a relationship.

### Trust tiers

| Tier | Definition | Examples | Allowed use |
|---|---|---|---|
| Declared | Explicit authoritative source relationship | Atomic Work Item linked to PR; work item linked to Test Case | Audit, compliance, AI answers |
| Derived | Deterministic machine relationship | PR changes symbol; test covers method | Audit when evidence is retained; AI answers |
| Inferred | Heuristic or model-generated candidate | Historical work item likely matches design content | Discovery; requires qualification or approval |

An inferred edge must never silently replace a declared or deterministic relationship.

## Fine-grained domain models

### Delivery-intent model

| Node type | Exact level | Internal relationships | Links to other areas |
|---|---|---|---|
| Epic | One strategic initiative | `PARENT_OF` Feature | Design/domain governance |
| Feature | One coherent capability/change | Source-native parent relationship to AtomicWorkItem | Solution design, component, release |
| AtomicWorkItem | Smallest independently understandable implementation intent; Story and Bug confirmed | `PARENT_OF` Task where supported; `HAS_CRITERION`; `IMPLEMENTED_BY_PR` | Design TraceLink, calculated PR-to-file/symbol path, Test TraceLink |
| Task | One implementation activity | Child of an allowed work item where the source process uses that pattern | Cross-links optional |
| AcceptanceCriterion | One testable behavioral condition | Criterion of an allowed work item | Test Case via `VERIFIED_BY`; CodeSymbol via candidate `GROUNDED_BY_CODE` TraceLink |

Rules:

- An allowed AtomicWorkItem is the normal authoritative cross-domain trace unit.
- Task-to-code links are optional because implementation boundaries frequently cross Tasks.
- Delivery hierarchy edges must be acyclic and single-parent where the source process requires a tree.

### Design-knowledge model

| Node type | Exact level | Internal relationships | Links to other areas |
|---|---|---|---|
| DomainArchitecture | One domain-level design scope | `GOVERNS` Solution/Component | Domain, Feature, Component |
| SolutionArchitecture | One end-to-end solution scope | `DECOMPOSES_TO` ComponentDesign | Feature, AtomicWorkItem |
| ComponentDesign | One service/application/module design scope | `CONTAINS` Section/Decision | Component, AtomicWorkItem |
| VersionedDesignContent | One independently understandable design unit at one page version; working level pending A-08 | `PART_OF` PageVersion; `CHILD_OF` another design unit where needed | AtomicWorkItem, Component, Solution, Rule |
| Decision | One architectural or design decision | `RECORDED_IN`; `SUPERSEDES` | Component, AtomicWorkItem, code impact |
| BusinessRule | One independently referenceable rule | `SPECIFIED_IN`; `SUPERSEDES` | Acceptance Criterion, code, test |

Rules:

- Page identity uses stable source IDs; title and location are mutable properties.
- Do not promote every heading section or paragraph. Create a design unit only when it remains understandable and reviewable on its own; keep the unit rule open until A-08 is validated.
- Scope defines design level; team size does not.

### Implementation and change model

| Node type | Exact level | Identity/version rule | Important relationships |
|---|---|---|---|
| Repository | One source repository | Stable source repository ID | Contains Module through the source path; is used by Component where mapped |
| Component | One deployable or bounded implementation unit | Shared component ID | `IMPLEMENTS` from CodeSymbol; `USES_REPOSITORY`; `DEPENDS_ON`; `OWNED_BY` |
| Module/Package | One logical code container | Repository + path/name | `CONTAINS` File/Symbol |
| File | One repository path at current state | Repository + path | `HAS_VERSION`, `CONTAINS` |
| CodeSymbol | One logical class/interface/function/method | Repository + fully qualified name | `HAS_VERSION`, `CALLS`, `DEPENDS_ON` |
| CodeSymbolVersion | One symbol at one commit | CodeSymbol ID + commit SHA | `CHANGED_BY`, `EVOLVED_TO`, `REMOVED_IN` |
| PullRequest | One reviewed change proposal | Repository + PR ID | `HAS_COMMIT`, `HAS_FINAL_DIFF` |
| Commit | One immutable Git commit | Repository + SHA | `HAS_PARENT_DIFF`, `BUILT_IN` |
| GitDiff | One comparison between base and target commits | Repository + base SHA + target SHA + comparison type | `CONTAINS` FileChange |
| FileChange | One changed path in one GitDiff | GitDiff ID + before/after path | `CONTAINS` SymbolChange |
| SymbolChange | One affected parsed class/function/method/export | FileChange ID + CodeSymbol + before/after range | `AFFECTS` CodeSymbol; `BEFORE_VERSION`, `AFTER_VERSION` |

Rules:

- Do not require developers to annotate methods with Story IDs. Use work-item metadata, diffs, structured change attribution, and review evidence outside normal code comments.
- Do not enforce one-to-one work-item/commit relationships. Enforce one AtomicWorkItem per PR and at most one implementation PR per work-item–Repository pair instead.
- Do not spread every work item on a non-compliant historical PR across every changed file or method. Preserve unresolved attribution at the broadest supported level.
- Preserve PR and commit history; do not overwrite older work-item contributions when newer PRs modify the same symbol.
- Deletion is a state transition or tombstone, not erasure.
- Separate the append-only historical graph from the current-state view.

#### Code-level dependency

Model a code dependency as one directed many-to-many relationship:

```text
source CodeSymbol -[DEPENDS_ON]-> target CodeSymbol
```

The direction has two query meanings:

- outbound: follow the relationship forward to find symbols this symbol uses;
- inbound: traverse the same relationship backward to find callers and consumers that use this symbol.

Do not store a second inverse relationship merely to represent inbound use. The graph database can traverse the directed relationship in either direction.

Required dependency fields:

| Field | Meaning |
|---|---|
| `dependencyType` | Calls, imports, extends, implements, uses API, publishes event, subscribes to event, reads data, or writes data |
| `sourceVersionId` | Exact source CodeSymbolVersion used when the dependency was observed |
| `targetVersionId` | Exact target CodeSymbolVersion when it can be resolved |
| `observedAt` | Time the parser or resolver observed the relationship |
| `evidenceRef` | Parser output, source location, build dependency, API definition, or other supporting evidence |
| `method`, `methodVersion` | Parser/resolver name and version |
| `confidence` | Resolution quality, especially for dynamic JavaScript or runtime wiring |
| `validFrom`, `validTo` | Period in which the relationship belongs to the current code view |

`CALLS` is a filtered view of `DEPENDS_ON` where `dependencyType = calls`; do not store both edges for the same observation. Historical impact uses the recorded source and target versions. Current impact uses dependencies whose validity includes the current code snapshot.

### Verification and execution-evidence model

Test level, purpose, implementation, and execution are independent axes.

| Concept | Examples | Modeling choice |
|---|---|---|
| Test level | unit, component, integration, system, end-to-end | Attribute or controlled classification node |
| Test purpose | acceptance, smoke, regression, security, performance | Suite/tag membership, not a containment hierarchy |
| Implementation | manual, automated | Attribute plus optional automation relationship |
| Definition | Test Case, JUnit/Jest test | Stable node |
| Execution | One test in one run/environment/build | Immutable event node |
| Result | pass, fail, skipped, duration, evidence | Execution properties or result node when independently governed |

Recommended relationships:

```text
Test TraceLink -[SOURCE]-> AtomicWorkItem
Test TraceLink -[TARGET]-> TestCase
AcceptanceCriterion -[VERIFIED_BY]-> TestCase
TestCase -[AUTOMATED_BY]-> TestDefinition
TestDefinition -[MEMBER_OF]-> TestSuite
TestDefinition -[EXECUTED_AS]-> TestExecution
TestExecution -[TESTED_BUILD]-> Build
TestExecution -[RAN_IN]-> Environment
TestExecution -[PRODUCED]-> TestResult
TestExecution -[COVERS]-> CodeSymbolVersion
ProgramPath -[STARTS_AT]-> CodeSymbolVersion with EntryPoint role
ProgramPath -[HAS_PROGRAM_FACT]-> ProgramFact
ProgramPath -[CONTRIBUTES_TO]-> TraceEvidence
ProgramFact -[CONTRIBUTES_TO]-> TraceEvidence
VersionedDesignContent -[REALIZED_BY_CODE]-> CodeSymbol
TestDefinition -[VERIFIES_CODE]-> CodeSymbolVersion
AcceptanceCriterion -[GROUNDED_BY_CODE]-> CodeSymbol
```

Rules:

- AtomicWorkItem/TestCase is a lasting governed assertion that states what behavior the test is meant to verify.
- Test Execution/Result is time-bound evidence.
- A test does not need to run inside the implementing PR pipeline to verify the work item.
- Smoke and regression are purposes/suites; they are not test levels.
- A retry creates another Test Execution and Test Result; it does not overwrite the earlier attempt.
- Runtime coverage points to the exact CodeSymbolVersion in the tested build. A direct Test Case-to-code link, if shown in a user view, is a calculated summary rather than a maintained source relationship.
- Brownfield recovery compares behavior signatures inside the four semantic profiles, not just raw text. Program paths, fixtures, assertions, coverage and mutation results remain separate evidence.
- A `gap_candidate` means the evidence is insufficient for an important behavior signature at the assessed snapshots; it does not claim that no test exists anywhere.
- Once evidence is sufficient to classify, a `gap_candidate` may carry a `gapType` of `regression_test_gap` (behavior supported, no test covers it), `implementation_gap` (behavior contradicted), or `partial_test_gap` (a test exists but exercises the wrong branch). `gapType` refines the deficit-evidence outcome; it does not replace it, and it is populated only after `outcome` is decided.
- `AcceptanceCriterion -[GROUNDED_BY_CODE]-> CodeSymbol` extends the same TraceLink pattern to the finer criterion grain, so one Given/When/Then/Never behavior can be graded independently of the rest of its parent work item.

The lifecycle view is in [work-item-to-test traceability model](./diagrams/ai-sdlc-test-traceability-model.html), the shared profile pattern is in [semantic link creation and recovery](./diagrams/ai-sdlc-semantic-link-recovery.html), and the criterion-level grounding and gap-classification flow is in [BDD-to-code behaviour evidence graph](./diagrams/ai-sdlc-bdd-behaviour-evidence-graph.html). AtomicWorkItem-to-TestCase stays many-to-many under the selected work-item-to-PR rule: a work item normally needs several Test Cases, and a reusable Test Case may verify behavior shared by several work items.

The BDD-grounded recovery flow above is specified down to build level in [BDD-to-code pipeline: implementation specification](./AI-SDLC-bdd-pipeline-implementation-spec.md): thirteen steps, each with one tool and one JSON artifact contract, a worked example chained end to end, and a schema plus reference validator that another implementer can run directly.

### Graph model versus relational loading model

The controlled node, relationship, cardinality and relationship-field definitions are maintained in the [Graph logical data dictionary](./AI-SDLC-graph-logical-data-dictionary.md). The diagrams are readable views of that shared definition.

The diagrams describe the target graph. In that model, records do not need foreign-key fields merely to point to another record. A graph relationship is the link. For example:

```text
source CodeSymbol -[DEPENDS_ON { dependencyType, observedAt, evidenceRef }]-> target CodeSymbol
Test TraceLink -[SOURCE]-> AtomicWorkItem
Test TraceLink -[TARGET]-> TestCase
Test TraceLink -[SUPPORTED_BY]-> TraceEvidence
```

If data is first prepared in SQL tables, use foreign keys there. A many-to-many relationship becomes a link table. Examples:

| Relational loading table | Key columns | Relationship fields |
|---|---|---|
| `CodeSymbolDependency` | `sourceCodeSymbolId`, `targetCodeSymbolId`, `sourceVersionId`, `targetVersionId` | `dependencyType`, `observedAt`, `evidenceRef`, `rankingScore` when suggested |
| `TraceLinkStage` | `traceLinkId`, `sourceId`, `targetId`, `relationType` | `linkOrigin`, `status`, `rankingScore`, `calibratedConfidence`, `validFrom`, `validTo` |
| `TraceLinkEvidenceStage` | `traceLinkId`, `evidenceId` | `evidenceRole` |
| `TestExecutionCoverage` | `executionId`, `symbolVersionId` | covered lines/branches, coverage tool, evidence reference |

Those ID columns should be foreign keys in the relational loading database. The graph loader converts each table row into a graph relationship and its fields. Do not also copy the same relationship into inbound and outbound JSON arrays: that duplicates facts and makes updates inconsistent. JSON may carry graph data between systems, but JSON by itself does not remove the need to define one owner and one direction for each relationship.

The tables above are examples, not a completed physical loading schema. Create the full relational loading design only after confirming that relational staging is required, which graph database and loading format will be used, and whether the staging layer is temporary or historized. The decision gate and required loading deliverables are listed in the graph logical data dictionary.

## Controlled relationship vocabulary

Start small and prefer precise inverse traversal over synonyms.

| Relationship | Meaning | Typical link origin |
|---|---|---|
| `PARENT_OF` | Hierarchical decomposition | Declared/source native |
| `SOURCE` / `TARGET` | A TraceLink points to the two real endpoints of its governed assertion | Declared, derived or suggested |
| `SUPPORTED_BY` | A TraceLink points to independently inspectable evidence | Declared, derived or suggested |
| `CONTRIBUTES_TO` | A SemanticProfile contributes a matching signal to TraceEvidence | Derived |
| `SPECIFIED_BY_DESIGN` | `TraceLink.relationType` stating that an AtomicWorkItem is specified or constrained by VersionedDesignContent | Declared or suggested candidate |
| `DESIGNED_BY` | Change/component is intentionally designed by artifact/section | Declared |
| `IMPLEMENTED_BY_CODE` | `TraceLink.relationType` stating that an AtomicWorkItem is implemented or corrected by a CodeSymbol | Deterministic evidence or reviewed suggestion |
| `GROUNDED_BY_CODE` | `TraceLink.relationType` stating that one AcceptanceCriterion's behavior is implemented by a CodeSymbol, at finer grain than `IMPLEMENTED_BY_CODE` | Semantic candidate, strengthened or weakened by program evidence |
| `VERIFIED_BY_TEST` | `TraceLink.relationType` stating that an AtomicWorkItem is intended to be verified by a TestCase | Declared or reviewed suggestion |
| `REALIZED_BY_CODE` | `TraceLink.relationType` stating that VersionedDesignContent is realized by a CodeSymbol | Declared or reviewed suggestion |
| `VERIFIES_CODE` | `TraceLink.relationType` stating that a TestDefinition verifies a CodeSymbolVersion with sufficient evidence | Reviewed evidence-bearing link |
| `STARTS_AT` / `INCLUDES_SYMBOL_VERSION` / `HAS_PROGRAM_FACT` | A bounded ProgramPath identifies its entry point, involved versioned symbols and inspectable conditions or effects | Static analysis |
| `HAS_COMMIT` | PR contains commit | Derived/source native |
| `HAS_PARENT_DIFF` / `HAS_FINAL_DIFF` | Commit or PR has a defined Git comparison | Derived from Git |
| `CONTAINS` | GitDiff contains FileChanges; FileChange contains SymbolChanges | Derived from diff/parser |
| `AFFECTS` | SymbolChange identifies its stable CodeSymbol | Derived from parser |
| `BEFORE_VERSION` / `AFTER_VERSION` | SymbolChange identifies the code version on each side | Derived from diff/parser |
| `CONTAINS` | Structural containment | Derived or authoritative registry |
| `DEPENDS_ON` | Directed code or component dependency; relationship type describes calls/imports/interfaces/APIs/events/data use | Derived or declared |
| `CALLS` | Query/view of `DEPENDS_ON` where dependency type is `calls`, not a duplicate stored edge | Derived view |
| `COVERS` | Test execution exercised code | Derived from coverage |
| `EXECUTED_AS` | Test definition produced an execution | Derived |
| `BUILT_FROM` | Build used a source revision | Derived/source native |
| `SUPERSEDES` | New artifact/decision replaces an older one | Declared; sometimes validated inference |
| `OWNED_BY` | Accountable owner | Declared/registry |
| `GOVERNED_BY` | Policy or architecture governs an object | Declared |

Avoid synonyms such as `coded_by`, `developed_by`, and `realised_by` for the same meaning.

## High-level view rules

### Types of views

| View | Purpose | Example behavior |
|---|---|---|
| Current-state | Answer “what exists now?” | Select nodes/edges valid at the effective time and latest logical versions |
| Historical/evidence | Explain how the system evolved | Retain every PR, commit, symbol version, replacement and removal |
| Delivery aggregate | Summarize implementation/testing by Feature | Traverse Feature -> Stories -> change/test paths |
| Component impact | Show change blast radius | Traverse symbols, callers, dependencies, tests, Stories, and owners |
| Release evidence | Prove readiness at a release snapshot | Bind Story, build, environment, executions, results, and approvals |
| AI retrieval | Supply authorized evidence and text | Use graph traversal to select artifacts, then retrieve permitted content |

### Derived-edge contract

Every stored shortcut link must define:

```yaml
name: FEATURE_IMPLEMENTED_BY_COMPONENT
source_pattern: Feature-PARENT_OF->Story-IMPLEMENTED_BY_SYMBOL_CHANGE->SymbolChange-AFFECTS->CodeSymbol<-CONTAINS-Component
output_relationship: IMPLEMENTED_BY
link_origin: derived
validity_rule: path is valid at the view's effective time
refresh_rule: event-driven plus nightly reconciliation
source_link_ids: retain every detailed link used
security_rule: output visibility is no broader than every required source path
```

Never create a summary relationship that cannot be explained by its detailed path.

### Accumulating versus superseding change

- Accumulating: several Stories contribute to the same current behavior. Retain all contribution paths.
- Superseding: a new component, decision, or symbol explicitly replaces an old one. Add `SUPERSEDES` or `EVOLVED_TO`; do not delete history.
- Removal: close validity and record the removal event/commit. Preserve the removed node version for historical questions.

## Source mapping and ownership

The graph is a stored knowledge and traceability view. Source systems remain authoritative.

| Shared graph information | System of record |
|---|---|
| Feature, Story, Task, status | Azure Boards |
| PR, commit, file change, build | Azure Repos/Pipelines |
| Design content and section anchors | Confluence |
| Code structure and calls | Git plus parsers/language tooling |
| Test definition | Test repository/Test Plans |
| Test execution and result | Pipeline/test platform |
| Ownership | Agreed service/component registry or authoritative team source |
| Relationship origin and evidence | Shared graph link/evidence store |

The ingestion layer should normalize identities and events. The graph should not become a second workflow UI where users maintain duplicate titles, statuses, or test results.

## Validation rules

### Structural constraints

- shared IDs are unique within type;
- a source-system identity maps to at most one active shared identity unless an explicit merge/split record exists;
- delivery parent relationships are acyclic;
- containment relationships do not cross incompatible containers;
- relationship endpoints follow the allowed source-type and target-type rules;
- current logical identity resolves to zero or one current version;
- deleted versions remain queryable historically.

### Evidence and governance constraints

- every derived edge has evidence and method version;
- every inferred link has a ranking score, model or rule identity, evidence and visible candidate status in AI output;
- a declared edge cannot be overwritten by a lower-trust edge;
- high-level links retain `derivedFrom` paths back to the detailed links;
- ACL/classification is enforced before graph context or text is returned to an AI model;
- freshness is visible for every source area and view.

### Query acceptance tests

Use business questions as executable model tests. A model update is complete only when representative queries return:

1. the correct objects;
2. the complete evidence path;
3. the appropriate current or historical state;
4. link origin and freshness;
5. only information the requesting identity may access.

### Coverage metrics

Measure useful coverage rather than total nodes or edges:

- active atomic work items with the expected Feature parent where required by the source process;
- production PRs with a linked work item;
- atomic work items with an accepted or clearly qualified Design TraceLink, or an explicit exemption;
- atomic work items with a complete calculated PR-to-symbol path or an accepted direct Code TraceLink;
- PRs that violate the one-AtomicWorkItem rule, including rejected, unresolved or formally approved exceptions;
- atomic work items or criteria with acceptance or system tests;
- PRs with parsed changed symbols;
- tests with identifiable component and execution evidence;
- active components with owner and governing design;
- orphan design sections and active modules;
- declared versus derived versus inferred edge proportions;
- stale links and views;
- AI answers with authoritative citations and complete evidence paths.

## Component-model specification template

Use this template for every component and level model.

```yaml
model_name: <domain/component/level>
business_purpose: <decisions enabled>
business_questions: [<CQ IDs>]

nodes:
  - type: <shared type>
    exact_level: <exactly one ...>
    shared_id: <rule>
    lifecycle: <created/changed/closed/deleted>
    versioning: <logical and immutable identity>
    source_of_record: <system>
    required_properties: []

relationships:
  - relationship: <agreed verb>
    source_type: <type>
    target_type: <type>
    cardinality: <0..1, 1..N, N..M>
    link_origins_allowed: [declared, derived, suggested]
    temporal_rule: <validity behavior>
    evidence_rule: <required evidence>

cross_domain_anchors:
  - <stable identity and relationship>

rollups:
  - view: <name>
    source_path: <detailed graph path>
    path_back_required: true

security:
  acl_source: <system/rule>
  inheritance: <rule>

quality_rules:
  - <constraint>

sample_instances:
  - <positive, historical, deletion, and ambiguous examples>
```

## Worked vertical slice

Use one thin end-to-end slice before expanding the model:

```text
Feature F-8420
  -> Story US-8421 (AtomicWorkItem)
     <- SOURCE <- Design TraceLink TL-DESIGN-208
        -> TARGET -> VersionedDesignContent EXAMPLE-PAGE-001#eligibility-rules@v3
     -> IMPLEMENTED_BY_PR -> PullRequest PR-617
        -> HAS_FINAL_DIFF -> GitDiff base456..abc123
           -> CONTAINS_FILE_CHANGE -> FileChange src/cards/LimitService.java
              -> CONTAINS_SYMBOL_CHANGE -> SymbolChange calculateLimit modified
                 -> AFFECTS -> CodeSymbol calculateLimit
        -> HAS_COMMIT -> Commit abc123
     <- SOURCE <- Test TraceLink TL-TEST-9017
        -> TARGET -> TestCase SYS-9017
        -> TestExecution run-2831
           -> TestResult PASS
        -> COVERS calculateLimit@abc123
```

Acceptance tests for the slice:

- traverse forward from Feature to the attributed code change, current component, and code;
- traverse backward from code to the work items and design that explain it;
- show the exact evidence and status for work-item-to-design and work-item-to-code relationships;
- keep a brownfield PR linked to several atomic work items at PR level with an exception or ambiguity state until stronger evidence supports finer attribution;
- show that the Test Case verifies the work item independently of the PR pipeline;
- distinguish test intent from a particular PASS result;
- add a later PR and symbol version without losing the earlier contribution;
- remove or supersede a symbol and still answer historical questions;
- build a Feature-to-Component summary link that can be rebuilt from its evidence path;
- deny access to design text when the caller lacks the source permission.

## Implementation sequence

| Wave | Scope | Exit condition |
|---|---|---|
| 1. Meaning | Business questions, shared IDs, exact levels, relationship names and link evidence | Approved high-level and detailed slice |
| 2. Target link contract | Atomic work-item-to-design and work-item–Repository PR relationships, calculated file/symbol paths, evidence, quality states, and exception rules | One approved target for new and brownfield work |
| 3. New-work controls | Allowed work-item types, structured design links or no-design reason, one-item-per-PR and one-PR-per-work-item–Repository validation, test metadata | New delivery stops creating unqualified gaps |
| 4. Deterministic backbone | Work items, PRs, commits, builds, Test Cases/results | Core evidence paths queryable |
| 5. Design graph | Stable page IDs, page versions, selective design content, Design TraceLinks, decisions and rules | Delivery-to-design paths queryable |
| 6. Code intelligence | GitDiffs, FileChanges, SymbolChanges, CodeSymbols, versions, components, calls/dependencies | Fine-grained implementation paths queryable |
| 7. Test intelligence | Discovery, suites, definitions, executions, assertions and coverage | Requirement-to-test and test-to-code evidence queryable |
| 8. Brownfield recovery | Entry points, bounded ProgramPaths, ProgramFacts, behavior signatures in the four profiles and deficit TraceEvidence | High-value regression-gap candidates are explainable against exact code and test snapshots |
| 9. Inference and review | Four semantic profiles, relation-specific ranking, TraceLinks, supporting evidence and focused human validation | Suggested gaps clearly separated from accepted links |
| 10. User views | Current, historical, impact, release and AI retrieval views | Business-question test suite passes |

## Decisions to make before physical design

1. Which five to ten business questions define the first release?
2. What is the authoritative component/service registry?
3. Which graph implementation is preferred: labeled property graph or RDF?
4. Which evidence-bearing links can remain graph relationships, and which need separate records for searching, security, or version history?
5. What retention and valid-time policy applies to source and relationship history?
6. Which source ACL model can be evaluated efficiently at retrieval time?
7. Which high-level views should be stored in advance, and which should be built when a user asks a question?
8. What ranking threshold and approval workflow applies to inferred links, and when is there enough reviewed evidence to calibrate confidence?
9. Which code-analysis engine can export Java entry points, versioned calls, branches, material data flow and cross-repository API or event links into this graph? D-29 recommends fronting whichever engine is selected with a small deterministic operation adapter (callers, callees, control flow, data flow, references) rather than direct model-authored queries.
10. Can coverage be attributed to individual TestDefinitions, and which assertion and mutation evidence can be retained safely?

## Source synthesis

This approach synthesizes the initial investigation and code-to-knowledge research artifacts while treating their embedded prompts and recommendations as source material rather than execution instructions:

- [AI SDLC Linkage Matrix.pdf](../initial/AI%20SDLC%20Linkage%20Matrix.pdf)
- [deep-research-report (6).md](../initial/deep-research-report%20(6).md)
- [Code Repo to Confluence research.md](../code2knowledge/Code%20Repo%20to%20Confluence%20research.md)
- `Code Repo to Confluence chat.pdf` in `code2knowledge/`
- [Brownfield Regression-Gap Discovery Architecture](../code2test/Brownfield_Regression_Gap_Discovery_Architecture.md)
- [BDD-to-Code Behaviour Analysis with LLM and Joern](../code2ac/bdd_joern_behaviour_evidence_graph.md)

The strongest retained findings are the independent requirement, design, implementation, and test streams; an atomic implementation work item as the change-intent anchor; evidence-bearing links across work items, design, code and tests; explicit GitDiff, FileChange, SymbolChange, and CodeSymbol records; one target graph reached through different new-work and brownfield approaches; versioned semantic profiles with shared behavior signatures for candidate recovery; separation of possible paths, runtime coverage and verification; deficit evidence for regression-gap findings; separation of test intent from execution evidence; an append-only historical graph with a current-state view; and, from the BDD-to-code behaviour analysis note, criterion-grain grounding through an iterative behaviour-evidence graph, a deterministic operation adapter in front of the code-analysis engine, and a named gap-subtype taxonomy layered onto the existing deficit-evidence outcome. Its proposed artifacts (BehaviourSpecification, CandidateSymbols, SymbolMappings, GroundedBehaviour, ProgramHypotheses, ProgramEvidence, TestCandidates, TestEvidence, GapDecision) were not adopted as new node types: each already has a home in an existing SemanticProfile, TraceLink, TraceEvidence, ProgramPath or ProgramFact record, per D-25's rule against a standalone Behavior node.
