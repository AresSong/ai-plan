# AI SDLC graph logical data dictionary

## Purpose

This is the shared logical definition of the target knowledge graph. It defines node types, directed relationships, cardinality and relationship fields without choosing a graph database or a relational loading design.

Use it with the detailed diagrams. The diagrams are readable views; this dictionary is the fuller control list used to check that the views remain consistent.

Related views:

- [Modeling approach](./AI-SDLC-graph-data-modeling-approach.md)
- [Link creation and recovery](./AI-SDLC-link-creation-and-recovery.md)
- [Connected system overview](./diagrams/ai-sdlc-connected-logical-graph.html)
- [Semantic link creation and recovery](./diagrams/ai-sdlc-semantic-link-recovery.html)
- [Selected work-item–Repository Pull Request model](./diagrams/ai-sdlc-story-repository-pr-er.html)
- [Archived flexible Story-to-code model](./diagrams/archive/ai-sdlc-target-graph-data-model.html)
- [Archived strict Story 1:1 Commit model](./diagrams/archive/ai-sdlc-story-commit-1-to-1-er.html)
- [Archived strict Story 1:1 Pull Request model](./diagrams/archive/ai-sdlc-story-pr-1-to-1-er.html)
- [Confluence design model](./diagrams/ai-sdlc-confluence-design-model.html)
- [Test traceability model](./diagrams/ai-sdlc-test-traceability-model.html)
- [Code-to-test behavior matching model](./diagrams/ai-sdlc-code-test-behavior-model.html)
- [Whole-solution code structure model](./diagrams/ai-sdlc-solution-code-structure-model.html)
- [BDD-to-code behaviour evidence graph](./diagrams/ai-sdlc-bdd-behaviour-evidence-graph.html)
- [BDD-to-code pipeline: implementation specification](./AI-SDLC-bdd-pipeline-implementation-spec.md)
- [BDD pipeline implementation graph](./diagrams/ai-sdlc-bdd-pipeline-implementation-graph.html)

## Modeling rules

1. A node holds the facts that describe that object.
2. A relationship connects two nodes. Do not add a foreign-key field to a node merely to represent that connection.
3. A source-native value such as a commit SHA, page ID or pipeline run ID may remain a property when it is evidence or part of the object's source identity. It does not replace the graph relationship.
4. Store one direction for each relationship. Queries may traverse it forward or backward.
5. Put origin, evidence, ranking score, review status and time on the relationship when they describe the link rather than either endpoint. Use calibrated confidence only after validation against reviewed examples.
6. Keep historical nodes and relationships. Build current-state views from validity and replacement relationships.
7. A suggested relationship is not silently promoted to a trusted relationship.

## Common node fields

Every node should support the following shared fields where applicable.

| Field | Meaning |
|---|---|
| `id` | Stable graph identity for the node |
| `nodeType` | Agreed node type |
| `sourceSystem` | Azure Boards, Confluence, Azure Repos, pipeline, test platform or registry |
| `sourceKey` | Source-native stable identity, qualified by source system and project where needed |
| `sourceUrl` | Link back to the source record |
| `observedAt` | Time the source state was captured |
| `validFrom`, `validTo` | Business validity when the object changes by replacement rather than event history |
| `schemaVersion` | Mapping version used to create the node |
| `classification` | Information classification when access control requires it |

The detailed diagrams render `id` using each node type's natural key name (for example `workItemId`, `pageId`, `traceLinkId`, `designContentId`) rather than the literal field name `id`; it is the same shared identity described here, spelled for readability.

## Node dictionary

Properties below exclude relationships. Fields marked “working” need SME confirmation.

### Delivery intent

| Node | Meaning and grain | Main properties | Source |
|---|---|---|---|
| `Feature` | One grouped business change or outcome | title, state, priority | Azure Boards |
| `AtomicWorkItem` | Shared graph role for an allowed implementation-level work item; this is an additional label on the source record, not a duplicate node | workItemType, title, state, areaPath | Azure Boards plus approved type rule |
| `Story` | One implementable business need; also labelled `AtomicWorkItem` when allowed | title, state, workItemType, areaPath | Azure Boards |
| `Bug` | One implementable correction to existing behavior; also labelled `AtomicWorkItem` when allowed | title, state, workItemType, severity, areaPath | Azure Boards |
| `AcceptanceCriterion` | One testable condition belonging to a Story | statement, priority, state | Azure Boards |

Story and Bug are confirmed to play the `AtomicWorkItem` role. The complete list of eligible Azure Boards types is still open under A-01. A source record keeps its original type and identity while also receiving the shared role label, so the graph does not create separate copies of the same work item.

### Design knowledge

| Node | Meaning and grain | Main properties | Source |
|---|---|---|---|
| `ConfluencePage` | Stable identity of one page | spaceKey, title, url | Confluence |
| `PageVersion` | One saved version of a page | versionNumber, createdAt, contentHash | Confluence |
| `VersionedDesignContent` | Working unit of independently understandable design content in one page version; may span one or more heading sections | headingPath, unitType, scopeLevel, viewType, contentHash, sourceRange, capturedAt | Confluence plus extraction |
| `Decision` | One stated design choice | decisionText, status, decidedAt | Confluence plus extraction |
| `BusinessRule` | One lasting business rule | ruleText, status, effective dates | Confluence plus extraction |

### Solution and source structure

| Node | Meaning and grain | Main properties | Source |
|---|---|---|---|
| `Domain` | One business or technology domain | name, lifecycleState | Architecture registry, working |
| `Solution` | One business solution boundary | name, solutionType, lifecycleState | Architecture registry, working |
| `Component` | One stable deployable or logical implementation unit | name, componentType, lifecycleState | Architecture registry, working |
| `Repository` | One Azure Repos repository | name, provider, defaultBranch | Azure Repos |
| `Module` | One Java module/package or JavaScript/TypeScript package boundary | name, path, language | Repository scan and parser |
| `File` | One stable source path identity inside a repository | path, language, fileKind | Git and parser |
| `CodeSymbol` | One stable class, interface, method, function or export identity | language, qualifiedName, signature, symbolKind | Parser |
| `CodeSymbolVersion` | One CodeSymbol at one commit or source snapshot | contentHash, sourceRange, createdAt | Git and parser |

### Program semantics used by the code profile

| Node | Meaning and grain | Main properties | Source |
|---|---|---|---|
| `EntryPoint` | An additional role on a CodeSymbolVersion that is externally invokable, such as a REST endpoint, event consumer, scheduled job or command handler; it is not a duplicate code node | entryPointType, routeOrTopic, framework, discoveryMethod | Framework-aware parser and configuration scan |
| `ProgramPath` | One bounded, statically possible path from one EntryPoint through versioned program elements at one source snapshot | pathHash, sourceSnapshot, extractionMethod, extractionVersion, traversalBudget, reachabilityConfidence | Static analysis |
| `ProgramFact` | One inspectable fact on a ProgramPath, such as a branch outcome, material data flow, state read/write, remote call, event, exception or other observable side effect | factType, statement, sourceRange, pathOrder, observedOutcome | Static analysis; runtime evidence may strengthen it |

`ProgramPath` and `ProgramFact` are inspectable technical inputs to the code semantic profile. They help populate behavior signatures but do not become a separate business node and do not by themselves prove that another source describes, implements or tests the same behavior.

### Change evidence

| Node | Meaning and grain | Main properties | Source |
|---|---|---|---|
| `PullRequest` | One review and merge context | pullRequestKey, provider, mergeStrategy, completionSha | Azure Repos |
| `Commit` | One immutable source commit | commitSha, parentSha, authorDate, message | Git |
| `GitDiff` | One defined comparison between source revisions | diffKey, comparisonType, createdAt | Git extraction |
| `FileChange` | One file delta in one GitDiff | beforePath, afterPath, changeType | Git extraction |
| `SymbolChange` | One parsed CodeSymbol change caused by changed source ranges | changeType, beforeRange, afterRange, parserVersion | Parser |

### Test and execution evidence

| Node | Meaning and grain | Main properties | Source |
|---|---|---|---|
| `TestCase` | One lasting intended behavior check | title, testLevel, automationState | Test management source |
| `TestDefinition` | One executable JUnit, Jest or similar test identity | framework, stableName, sourcePath, testKind | Repository and parser |
| `TestSuite` | One reusable test grouping or purpose | name, purpose | Test platform or metadata |
| `TestExecution` | One attempt to run one TestDefinition against one build and environment | startedAt, attemptNumber, runner, executionMode | Pipeline or test platform |
| `TestResult` | One outcome from one TestExecution | outcome, durationMs, evidenceUrl | Test platform |
| `Build` | One immutable build output or pipeline snapshot | buildKey, buildNumber, completedAt, status | Pipeline |
| `Environment` | One named execution or deployment environment | name, environmentType, classification | Pipeline or environment registry |

### Ownership and release

| Node | Meaning and grain | Main properties | Source |
|---|---|---|---|
| `Team` | One accountable team | name, status | Organization registry |
| `Person` | One human identity when individual responsibility is required | displayName, status | Identity source |
| `Release` | One releasable or released version | version, state, releasedAt | Release platform, working |

### Semantic matching and recovered links

| Node | Meaning and grain | Main properties | Source |
|---|---|---|---|
| `SemanticProfile` | One versioned derived representation of one traceable entity or entity version | profileType, keywords, concepts, humanTags, aiTags, summary, embeddingRef, behaviorSignatures, behaviorSchemaVersion, generator, generatorVersion, contentHash, createdAt | Rules, search preparation or model generation |
| `TraceLink` | One versioned assertion that a named relationship exists between two real graph entities | relationType, status, linkOrigin, rankingScore, calibratedConfidence, generator, generatorVersion, createdAt, validFrom, validTo | Declared source, deterministic rule, human proposal or AI proposal |
| `TraceEvidence` | One independently inspectable contribution supporting, conflicting with or showing a deficit in a TraceLink or a gap finding | evidenceType, evidenceDirection, strengthLevel, score, sourceAnchor, targetAnchor, explanation, extractionMethod, methodVersion, sourceRevision, observedAt, gapType (populated only on a sufficiently evidenced deficit finding) | Source link, search, parser, history, coverage, assertion analysis, mutation test, graph rule or model |

`SemanticProfile` is supporting evidence, not the endpoint of the accepted business relationship. The accepted `TraceLink` connects the real work item, design content, code, component or test. `Design TraceLink`, `Code TraceLink` and `Test TraceLink` are relationship-specific views of the same `TraceLink` node type, not additional node types.

## Directed relationship dictionary

Cardinality is written from source to target. `1:N` means one source may connect to many targets. Optionality should be confirmed with the SME and enforced only when the source process can supply the link.

### Delivery and design

| Source | Relationship | Target | Cardinality | Relationship-specific fields | Creation method |
|---|---|---|---|---|---|
| Feature | `HAS_WORK_ITEM` | AtomicWorkItem | 1:N | order, sourceRelationshipType | Source-native |
| AtomicWorkItem | `HAS_CRITERION` | AcceptanceCriterion | 1:N | order | Source-native where supported |
| ConfluencePage | `HAS_VERSION` | PageVersion | 1:N | none | Source-native |
| PageVersion | `HAS_DESIGN_CONTENT` | VersionedDesignContent | 1:N | order, headingPath | Derived |
| VersionedDesignContent | `CHILD_OF` | VersionedDesignContent | N:0..1 | order | Derived or reviewed |
| VersionedDesignContent | `STATES_DECISION` | Decision | 1:N | extractionMethod | Declared or derived |
| VersionedDesignContent | `STATES_RULE` | BusinessRule | 1:N | extractionMethod | Declared or derived |
| Decision | `SUPERSEDES` | Decision | N:0..1 | reason | Declared or accepted inference |
| BusinessRule | `SUPERSEDES` | BusinessRule | N:0..1 | reason | Declared or accepted inference |
| VersionedDesignContent | `DESCRIBES` | Solution | N:N | contributionType, scopeLevel, viewType | Declared, derived or suggested |
| VersionedDesignContent | `DESCRIBES` | Component | N:N | contributionType, scopeLevel, viewType | Declared, derived or suggested |
| AtomicWorkItem | `SPECIFIED_BY_DESIGN` | VersionedDesignContent | N:N | scopeLevel | Accepted query view through TraceLink |

A Design TraceLink's `TARGET` is `VersionedDesignContent` once a unit is resolved, or `PageVersion` for a declared page-only reference that has not yet been resolved to a unit; see [Link creation and recovery](./AI-SDLC-link-creation-and-recovery.md) for the retargeting rule.

### Work item, Git and code

| Source | Relationship | Target | Cardinality | Relationship-specific fields | Creation method |
|---|---|---|---|---|---|
| AtomicWorkItem | `IMPLEMENTED_BY_PR` | PullRequest | 1:N; optional before implementation | attributionState, policyVersion, exceptionReason | Declared and policy-enforced |
| PullRequest | `HAS_COMMIT` | Commit | 1:N | commitOrder | Source-native |
| PullRequest | `HAS_FINAL_DIFF` | GitDiff | 1:1 when completed | baseSelectionRule | Derived |
| PullRequest | `IN_REPOSITORY` | Repository | N:1 | none | Source-native |
| Commit | `IN_REPOSITORY` | Repository | N:1 | none | Source-native |
| Commit | `HAS_PARENT_DIFF` | GitDiff | 1:1 for normal source commits | baseSelectionRule | Derived |
| GitDiff | `CONTAINS_FILE_CHANGE` | FileChange | 1:N | order | Derived |
| FileChange | `CONTAINS_SYMBOL_CHANGE` | SymbolChange | 1:N | changedRanges | Derived |
| SymbolChange | `AFFECTS` | CodeSymbol | N:1 | matchMethod | Derived |
| SymbolChange | `BEFORE_VERSION` | CodeSymbolVersion | N:0..1 | none | Derived |
| SymbolChange | `AFTER_VERSION` | CodeSymbolVersion | N:0..1 | none | Derived |
| CodeSymbolVersion | `VERSION_OF` | CodeSymbol | N:1 | none | Derived |
| CodeSymbolVersion | `OBSERVED_IN` | Commit | N:1 | extractionMethod | Derived |
| AtomicWorkItem | `IMPLEMENTED_BY_CODE` | CodeSymbol | N:N | contributionType | Accepted query view through TraceLink |

Rule: every production Pull Request has exactly one allowed `AtomicWorkItem` and one Repository. The combination of work-item ID and Repository ID may have at most one implementation Pull Request unless an approved exception is recorded. A Repository may still have many Pull Requests for different work items and at different times.

Rule: `FileChange` and `SymbolChange` are parsed only from the Pull Request's `HAS_FINAL_DIFF` GitDiff. The per-commit `HAS_PARENT_DIFF` GitDiff retains raw commit-level comparison evidence for history and display; it is not separately parsed into `FileChange` or `SymbolChange` records, so a file touched by several commits inside one PR is never attributed twice across the two diff levels.

### Whole-solution structure and dependency

| Source | Relationship | Target | Cardinality | Relationship-specific fields | Creation method |
|---|---|---|---|---|---|
| Solution | `IN_DOMAIN` | Domain | N:1 | none | Registry |
| Component | `PART_OF` | Solution | N:1 | validFrom, validTo | Registry |
| Component | `OWNED_BY` | Team | N:1 | responsibilityType | Registry |
| Solution | `OWNED_BY` | Team | N:1 | responsibilityType | Registry |
| Component | `OWNED_BY` | Person | N:1 | responsibilityType | Registry, used only when accountability is individual rather than team-based |
| Solution | `OWNED_BY` | Person | N:1 | responsibilityType | Registry, used only when accountability is individual rather than team-based |
| Component | `USES_REPOSITORY` | Repository | N:N | contributionType, pathScope | Registry or accepted derivation |
| Module | `IN_REPOSITORY` | Repository | N:1 | none | Derived |
| File | `IN_MODULE` | Module | N:1 | none | Derived |
| CodeSymbol | `DECLARED_IN` | File | N:1 | none | Derived |
| CodeSymbol | `IN_MODULE` | Module | N:1 | derivedFrom | Calculated shortcut through File |
| CodeSymbol | `IMPLEMENTS` | Component | N:1 at a point in time | validFrom, validTo, mappingMethod, evidenceRef | Registry or accepted derivation |
| CodeSymbol | `DEPENDS_ON` | CodeSymbol | N:N directed | dependencyType, sourceVersion, targetVersion | Parser or declared contract |
| Component | `DEPENDS_ON` | Component | N:N directed | dependencyType, evidenceMode | Calculated view or declared contract |

### Test, execution and coverage

| Source | Relationship | Target | Cardinality | Relationship-specific fields | Creation method |
|---|---|---|---|---|---|
| AtomicWorkItem | `VERIFIED_BY_TEST` | TestCase | N:N | testPurpose | Accepted query view through TraceLink |
| AcceptanceCriterion | `VERIFIED_BY` | TestCase | N:N | verificationPurpose | Declared |
| TestCase | `AUTOMATED_BY` | TestDefinition | N:N | automationRole | Declared or derived |
| TestDefinition | `DECLARED_AS` | CodeSymbol | N:1 | none | Parser |
| TestDefinition | `IN_REPOSITORY` | Repository | N:1 | none | Parser |
| TestDefinition | `MEMBER_OF` | TestSuite | N:N | purpose | Source-native or metadata |
| TestDefinition | `EXECUTED_AS` | TestExecution | 1:N | none | Source-native |
| TestExecution | `TESTED_BUILD` | Build | N:1 | none | Source-native |
| TestExecution | `RAN_IN` | Environment | N:1 | configurationHash | Source-native |
| TestExecution | `PRODUCED` | TestResult | 1:1 | none | Source-native |
| TestExecution | `COVERS` | CodeSymbolVersion | N:N | coveredLines, coveredBranches, toolName | Coverage tool |
| Build | `BUILT_FROM` | Commit | N:N for multi-repository builds | repositoryRole | Pipeline and source evidence |
| Release | `INCLUDES_BUILD` | Build | 1:N | buildRole | Release platform |

### Program evidence and cross-source links

| Source | Relationship | Target | Cardinality | Relationship-specific fields | Creation method |
|---|---|---|---|---|---|
| ProgramPath | `STARTS_AT` | CodeSymbolVersion with EntryPoint role | N:1 | none | Derived |
| ProgramPath | `INCLUDES_SYMBOL_VERSION` | CodeSymbolVersion | N:N | pathOrder, callType, dispatchConfidence | Static analysis |
| ProgramPath | `HAS_PROGRAM_FACT` | ProgramFact | 1:N | pathOrder | Static analysis |
| ProgramPath | `CONTRIBUTES_TO` | TraceEvidence | N:N | contributionRole | Derived |
| ProgramFact | `CONTRIBUTES_TO` | TraceEvidence | N:N | contributionRole | Derived |
| VersionedDesignContent | `REALIZED_BY_CODE` | CodeSymbol | N:N | scope, validFrom, validTo | Declared or accepted TraceLink view |
| TestDefinition | `VERIFIES_CODE` | CodeSymbolVersion | N:N | verificationRole, validFrom, validTo | Accepted TraceLink view |
| AcceptanceCriterion | `GROUNDED_BY_CODE` | CodeSymbol | N:N | scope, mappingMethod, validFrom, validTo | Semantic candidate; strengthened or weakened by ProgramPath/ProgramFact evidence via TraceEvidence |

Behavior signatures are structured content inside work-item, design, code and test semantic profiles. Each signature may contain scope, `given`, `when`, `then`, optional `never`, business concepts and exact source anchors. A signature's `scope` may name one AcceptanceCriterion rather than the whole parent work item, so one Story can carry several independently gradeable behaviors without a separate profile node per criterion. Comparing these signatures can contribute `TraceEvidence`, but an accepted `TraceLink` always connects real entities such as a work item and CodeSymbol, design content and CodeSymbol, an AcceptanceCriterion and CodeSymbol, or TestDefinition and CodeSymbolVersion.

A regression-gap result is deficit `TraceEvidence`, not a new Behavior node or a permanent statement that no test exists. It records the exact code and test snapshots, assessment outcome, evidence level, gap priority, assessment rule version and review state. Runtime coverage is stronger than static reachability but is not proof of verification; assertion evidence, forbidden-side-effect checks, mutation results or historical-defect reproduction provide stronger support. Once evidence is sufficient to decide the `gap_candidate` outcome, `gapType` classifies it as `regression_test_gap` (behavior supported, no test covers it), `implementation_gap` (behavior contradicts the criterion), or `partial_test_gap` (a test exists but exercises the wrong branch); `gapType` is a refinement of the outcome, not a replacement for it.

Program-analysis questions generated for one grounding or verification attempt (for example, a control-flow reachability question or a data-flow question tying a parameter to a sink) are transient orchestration input to the code-analysis engine's deterministic operation adapter. They are not stored as graph nodes; only the `ProgramFact` and `TraceEvidence` records that result from running them are persisted, consistent with the modeling-approach document's rule against creating nodes for transient tokens.

### Semantic matching and trace governance

| Source | Relationship | Target | Cardinality | Relationship-specific fields | Creation method |
|---|---|---|---|---|---|
| Any traceable node or version | `HAS_SEMANTIC_PROFILE` | SemanticProfile | 1:N | sourceContentHash | Derived |
| SemanticProfile | `CONTRIBUTES_TO` | TraceEvidence | N:N | contributionRole | Derived |
| TraceLink | `SOURCE` | Any traceable node or version | N:1 | sourceRole | Declared, derived or suggested |
| TraceLink | `TARGET` | Any traceable node or version | N:1 | targetRole | Declared, derived or suggested |
| TraceLink | `SUPPORTED_BY` | TraceEvidence | 1:N | evidenceRole | Source-native, derived or suggested |
| TraceLink | `SUPERSEDES` | TraceLink | N:0..1 | reason | Review or change detection |

Allowed `TraceLink.status` values are candidate, pending, accepted, rejected, suspect and superseded. Suggested links must not be traversed as accepted facts unless the query explicitly asks for candidates. A raw model score is a ranking score; populate `calibratedConfidence` only after measurement against representative reviewer decisions.

The first controlled `TraceLink.relationType` values are `SPECIFIED_BY_DESIGN` for AtomicWorkItem to VersionedDesignContent, `IMPLEMENTED_BY_CODE` for AtomicWorkItem to CodeSymbol, `VERIFIED_BY_TEST` for AtomicWorkItem to TestCase, `REALIZED_BY_CODE` for VersionedDesignContent to CodeSymbol, `VERIFIES_CODE` for TestDefinition to CodeSymbolVersion, and `GROUNDED_BY_CODE` for AcceptanceCriterion to CodeSymbol. Add another value only when its business meaning and endpoint types are different.

Each accepted query view listed in the directed relationship dictionary above reuses its TraceLink's `relationType` as the view's relationship name (`SPECIFIED_BY_DESIGN`, `IMPLEMENTED_BY_CODE`, `VERIFIED_BY_TEST`), so a query never has to translate between the stored assertion and the calculated shortcut that reads it.

Use one current TraceLink for the same source node or version, target node or version and `relationType`. New evidence attaches through `SUPPORTED_BY`; it does not create a second assertion. If a matching accepted assertion already exists, AI output may support or challenge it but must not create a parallel candidate. When an assertion changes, create its replacement and connect the replacement to the earlier link with `SUPERSEDES`.

## Common relationship fields

Use the smallest subset needed by the relationship. Do not add empty fields merely to make every relationship look the same.

| Field | Meaning |
|---|---|
| `linkOrigin` | `declared`, `derived`, `human-suggested` or `ai-suggested` |
| `method` | Source link, parser, coverage tool, rule or model that created the relationship |
| `methodVersion` | Version of the parser, rule or model |
| `evidenceRef` | Link to the source event, diff, coverage output or review evidence |
| `rankingScore` | Raw score used to order candidates; it is not a probability |
| `calibratedConfidence` | Acceptance probability only when measured against representative reviewer decisions |
| `status` | candidate, pending, accepted, rejected, suspect or superseded for a TraceLink; other direct relationships may use a smaller controlled state where needed |
| `classification`, `aclRef` | Relationship-level information classification and source ACL reference, populated when the link or its evidence is more sensitive than either endpoint alone; enforced before the link or its evidence is returned to a query or an AI model, alongside each endpoint's own `classification`/`aclRef` |
| `reviewedBy`, `reviewedAt` | Human or service validation record |
| `reviewDecision`, `reviewReason` | The reviewer's accept, reject or correction decision and its reason code |
| `validFrom`, `validTo` | Time period during which the statement was true |
| `observedAt` | Time the relationship was captured or recomputed |
| `derivedFrom` | Detailed relationship IDs used to create a shortcut or summary relationship |

## Foreign-key cleanup rules

The following names may appear in source payloads or relational staging, but should not be used as the logical graph connection.

| Foreign-key-like field | Graph relationship |
|---|---|
| `repositoryId` on PullRequest, Commit, File or TestDefinition | `IN_REPOSITORY` |
| `projectId` on Repository | Keep source project as part of `sourceKey`, or connect to a Project node if Project must be queried independently |
| `domainId` on Solution | `IN_DOMAIN` |
| `solutionId` on Component | `PART_OF` |
| `ownerId` | `OWNED_BY` to Team or Person |
| `beforeVersionId`, `afterVersionId` on SymbolChange | `BEFORE_VERSION`, `AFTER_VERSION` |
| `currentVersionId` on CodeSymbol | Calculate the current version from valid time or latest accepted version; do not store a second pointer |
| `codeSymbolId` on CodeSymbolVersion | `VERSION_OF` |
| `testSymbolId` on TestDefinition | `DECLARED_AS` |
| `environmentId` on TestExecution | `RAN_IN` |
| `pipelineRunId` on Build | Keep as source evidence or source identity, not a foreign key, unless PipelineRun becomes its own node |
| `supersedesId` | `SUPERSEDES` |

## Relational loading decision gate

Do not create the physical relational schema until the following questions are answered.

| Decision question | Why it changes the loading model |
|---|---|
| Will data be staged in SQL, lake tables, event files or loaded directly through graph APIs? | Determines whether tables and foreign keys are needed at all |
| Is the staging area temporary, historized or an operational source? | Determines retention, effective dating and audit fields |
| Which graph database and bulk-loading format will be used? | Determines node and relationship file shape, labels and type handling |
| Will one row represent current state or one observed version? | Determines keys and duplicate handling |
| Where will identity matching and TraceLink status be held? | Determines whether link records need their own staging tables |
| Which security boundary applies to Boards, Confluence, code and test evidence? | Determines whether one loading area is allowed |

If relational staging is confirmed, produce a separate loading design containing:

1. One node staging table per node type or per compatible node family.
2. One relationship staging table per relationship type or per compatible relationship family.
3. Primary keys, foreign keys and uniqueness rules.
4. Source-to-stage and stage-to-graph mappings.
5. Incremental loading, deletion, late-arriving data and retry rules.
6. Evidence, ranking score, calibrated confidence, status and valid-time fields on relationship tables.
7. Reconciliation queries proving that every loaded edge resolves to both endpoints.

The relational loading design must not be copied back into the graph logical model.

## SME review checklist

- Confirm node grain and stable source identity.
- Confirm every relationship name and direction.
- Confirm cardinality and optionality based on real delivery practice.
- Confirm which links are declared, derived or only suggested.
- Confirm which relationship fields are required for audit and access control.
- Confirm ownership for Solution, Component, TestCase and Environment identities.
- Confirm whether relational staging is required before physical design begins.
