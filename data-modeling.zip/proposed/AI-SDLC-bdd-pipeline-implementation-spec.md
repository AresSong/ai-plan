# BDD-to-code behaviour evidence pipeline: implementation specification

## Purpose and how to read this document

This is the build-level companion to [BDD-to-code behaviour evidence graph](./diagrams/ai-sdlc-bdd-behaviour-evidence-graph.html) and the "BDD-grounded criterion recovery" section of [Link creation and recovery](./AI-SDLC-link-creation-and-recovery.md). Those describe the four cooperating loops conceptually. This document turns them into thirteen concrete pipeline steps (`P1`-`P12`, with `P11` split into `P11a`/`P11b`), each with one tool, one input contract and one output contract, so another engineer or agent can implement the pipeline without re-deriving the design.

Three files ship alongside this document and are normative, not illustrative:

| File | Contents |
|---|---|
| [`bdd-pipeline-artifacts.schema.json`](./bdd-pipeline-artifacts.schema.json) | One JSON Schema `$def` per artifact type (`P1` output through `P12` output), plus the shared `Envelope` and `EvidenceItem` shapes every artifact reuses. |
| [`bdd-pipeline-worked-example.json`](./bdd-pipeline-worked-example.json) | One complete, schema-valid example object per step, all for the same criterion and pipeline run, so the chain can be read top to bottom. |
| [`validate_pipeline_example.py`](./validate_pipeline_example.py) | Reference validator: checks every example against its schema `$def`, then checks that every id one step invents (`businessElementId`, `codeSymbolId`, `questionId`, `testDefinitionId`) is defined upstream and consumed downstream with nothing dangling or invented. Run it against a real implementation's sample output before wiring the steps into an orchestrator; it currently passes on the shipped worked example (`ALL CROSS-STEP REFERENTIAL CHECKS PASSED`). |

Everything below reuses the shared logical graph's existing vocabulary (`AcceptanceCriterion`, `SemanticProfile`, `TraceLink`, `TraceEvidence`, `ProgramPath`, `ProgramFact`, `TestCase`, `TestDefinition`) as defined in [the modeling approach](./AI-SDLC-graph-data-modeling-approach.md) and [the logical data dictionary](./AI-SDLC-graph-logical-data-dictionary.md). This spec does not introduce new graph node types; where a step's artifact is graph-persisted, the "Persistence" row says exactly which existing node/relationship/property it becomes. Only two controlled-vocabulary values are new anywhere in this pipeline: `TraceLink.relationType = GROUNDED_BY_CODE` (D-28) and `TraceEvidence.gapType` (D-29).

## Global conventions

Every artifact carries these four fields (the `Envelope` in the schema), which is what lets any two artifacts for the same criterion be joined without a lookup table:

| Field | Meaning |
|---|---|
| `criterionId` | Shared id of the existing `AcceptanceCriterion` node. Identical on all thirteen artifacts for one criterion. |
| `runId` | One pipeline execution attempt (format `run-<id>`). Identical on all artifacts produced by one run, including a partial re-run triggered by a feedback edge. |
| `generatedBy` / `generatorVersion` | Tool, rule set or model and its version. Copies directly onto `TraceLink.method`/`methodVersion` or `TraceEvidence.extractionMethod`/`methodVersion` at persistence. |
| `producedAt` | ISO-8601 timestamp. Copies directly onto `observedAt` at persistence. |

Three id formats are fixed once and reused everywhere, so a later step never has to re-derive or guess an id an earlier step already minted:

- **`codeSymbolId`** = `"<repository>::<fullyQualifiedName>"`, e.g. `settlement-service::com.bank.settlement.AutoNettingService.add`. This is the existing `CodeSymbol.sharedId` rule (repository + fully qualified name); every step from `P4` candidate discovery through `P9` program evidence uses exactly this string, never a bare method name.
- **`businessElementId`** = a short id minted once in `P2` (`preconditionId`, `triggerId`, `effectId`) and referenced verbatim by `P5`, `P6` and `P10`. This is what lets a reviewer trace "why is `CounterpartyConfig.isAutoNettingEnabled` in this model" back to the exact `Given`/`When`/`Then`/`Never` clause it grounds, across three intervening steps.
- **`testDefinitionId`** = `"<repository>::<stableName>"`, matching the existing `TestDefinition` shared identity (`framework`, `stableName`, `sourcePath`).

Confidence handling is the same rule already in force elsewhere in the design (D-22, A-17): every step that scores a candidate emits a raw `rankingScore` (0-1, explicitly not a probability). `calibratedConfidence` stays `null` until it has been measured against reviewed decisions; nothing in this pipeline sets it automatically.

## Pipeline graph at a glance

```text
P1 AcceptanceCriterionRecord
  -> P2 BehaviourDecomposition ---------------------------------┐  Loop 1
  -> P3 BusinessConcepts                                         │
                                                                  ▼
  -> P4 CandidateSymbols  -> P5 SymbolMappings (TraceLink GROUNDED_BY_CODE)   Loop 2
       ▲                          │
       │ weak grounding           │ grounds
       └── widens search ─────────┘
                                   ▼
  -> P6 TechnicalBehaviourModel -> P7 ProgramAnalysisQuestions -> P8 ProgramEvidenceRaw
       ▲                                                              │            Loop 3
       │ revises rankingScore on the P5 TraceLink                     ▼
       └──────────────────────────────────── P9 ProgramEvidence ------┘
                                                   │
                                                   ▼
                                        P10 BehaviourVerification
                                                   │
                        ┌──────────────────────────┼───────────────────────┐
                        ▼ supported/partial                                ▼ contradicted, weak grounding
              P11a TestCandidates (TraceLink VERIFIED_BY_TEST)      back to P5 (re-ground before concluding a gap)
                        │                                          Loop 4
                        ▼
              P11b TestCoverage
                        │
                        ▼
              P12 GapClassification (deficit TraceEvidence, gapType)
                        │
                        ▼
              Human review (outside this pipeline; A-17 evaluation set)
```

The rendered version, with each step's persisted node/relationship shown alongside it, is [BDD-to-code behaviour evidence graph](./diagrams/ai-sdlc-bdd-behaviour-evidence-graph.html) and the new [pipeline implementation graph](./diagrams/ai-sdlc-bdd-pipeline-implementation-graph.html) (steps as nodes, artifacts as edges).

## Step reference

Each step below gives: purpose, tool, trigger/routing, input, output (schema `$def` name plus a trimmed worked example — the full example is in `bdd-pipeline-worked-example.json`), and persistence.

### P1 — Ingest acceptance criterion

- **Loop:** 1 (Requirement understanding), entry point.
- **Tool:** deterministic ingestion connector (Azure Boards work-item API, or a Gherkin feature-file reader). No LLM.
- **Trigger:** a new or changed `AcceptanceCriterion` is observed by the ingestion connector.
- **Input:** a work-item id or feature-file path/anchor.
- **Output:** `AcceptanceCriterionRecord`.

```json
{
  "criterionId": "AC-8421-03", "runId": "run-2026-09-06-0001", "schemaVersion": "bdd-pipeline-v1",
  "workItemId": "US-8421",
  "statement": "Given an obligation is eligible for automatic netting And the counterparty supports automatic netting When settlement processing is triggered Then the obligation is added to the automatic netting set And no manual-netting task is created",
  "sourceSystem": "AzureBoards", "sourceUrl": "https://dev.azure.com/example/_workitems/edit/8421"
}
```

- **Persistence:** confirms/updates the existing `AcceptanceCriterion` node (declared source; A-21). No new node type.

### P2 — Behaviour decomposition

- **Loop:** 1.
- **Tool:** LLM, JSON-mode, temperature 0, system-constrained: *do not invent code symbols at this stage*.
- **Trigger:** every `P1` output, and on any re-run requested by a downstream feedback edge with a narrower prompt (e.g. "focus only on the counterparty precondition").
- **Input:** `AcceptanceCriterionRecord.statement`.
- **Output:** `BehaviourDecomposition` — mints `preconditionId`, `triggerId`, `effectId` values that every later step references by exact string.

```json
{
  "criterionId": "AC-8421-03", "runId": "run-2026-09-06-0001",
  "scope": "automatic netting",
  "preconditions": [
    { "preconditionId": "PC-1", "entity": "obligation", "property": "eligible_for_auto_netting", "expected": true },
    { "preconditionId": "PC-2", "entity": "counterparty", "property": "supports_auto_netting", "expected": true }
  ],
  "trigger": { "triggerId": "TR-1", "action": "settlement_processing", "entity": "obligation" },
  "expectedEffects": [{ "effectId": "EF-1", "action": "add_to_auto_netting_set", "entity": "obligation" }],
  "forbiddenEffects": [{ "effectId": "FE-1", "action": "create_manual_netting_task" }],
  "businessEntities": ["obligation", "counterparty"]
}
```

- **Persistence:** written into the parent `AtomicWorkItem`'s `SemanticProfile.behaviorSignatures`, one entry scoped to `criterionId` (`scope`/`given`/`when`/`then`/`never` populated from `preconditions`/`trigger`/`expectedEffects`/`forbiddenEffects`). No new node.

### P3 — Business concept enrichment

- **Loop:** 1.
- **Tool:** LLM plus retrieval (RAG) over the domain glossary and Confluence.
- **Input:** `BehaviourDecomposition`.
- **Output:** `BusinessConcepts`.

```json
{
  "criterionId": "AC-8421-03", "runId": "run-2026-09-06-0001",
  "concepts": [{ "concept": "automatic netting", "synonyms": ["auto netting", "automated netting"],
                 "relatedTerms": ["netting engine", "netting set"], "sourceRefs": ["glossary:netting"] }]
}
```

- **Persistence:** merged into the same `SemanticProfile.concepts`/`keywords`.

### P4 — Candidate code discovery

- **Loop:** 2 (Code grounding), start.
- **Tool:** the staged evidence cascade already defined for candidate-link generation generally (lexical/grep search, embedding vector search over a code index, GitNexus/repo-graph neighbourhood traversal, Joern structural exploration). Retrieval only, no LLM judgement yet.
- **Input:** `BehaviourDecomposition` + `BusinessConcepts`.
- **Output:** `CandidateSymbols` — **ephemeral**: consumed by `P5` in the same run and not written to the graph (per the modeling approach's rule against nodes for transient tokens).

```json
{
  "criterionId": "AC-8421-03", "runId": "run-2026-09-06-0001",
  "candidates": [
    { "codeSymbolId": "settlement-service::com.bank.settlement.NettingEligibilityService.isEligible",
      "symbolKind": "method", "matchReason": "matches eligibility precondition", "matchMethod": "lexical", "rankingScore": 0.88 },
    { "codeSymbolId": "settlement-service::com.bank.settlement.CounterpartyConfig.isAutoNettingEnabled",
      "symbolKind": "method", "matchReason": "matches counterparty precondition", "matchMethod": "embedding", "rankingScore": 0.72 }
  ]
}
```

- **Persistence:** none.

### P5 — Business-code grounding

- **Loop:** 2.
- **Tool:** LLM judgement over the top-K `CandidateSymbols`, plus a deterministic-adapter structural check against the code-analysis engine (e.g. "is this candidate actually called from the trigger method?").
- **Input:** `CandidateSymbols` + `BehaviourDecomposition`.
- **Output:** `SymbolMappings` — one entry per `businessElementId`, each with its own `evidence` array (`EvidenceItem[]`).

```json
{
  "criterionId": "AC-8421-03", "runId": "run-2026-09-06-0001",
  "mappings": [
    { "businessElementId": "PC-2",
      "codeSymbolId": "settlement-service::com.bank.settlement.CounterpartyConfig.isAutoNettingEnabled",
      "mappingType": "predicate", "rankingScore": 0.72, "calibratedConfidence": null,
      "evidence": [{ "evidenceType": "semantic_similarity", "strengthLevel": "moderate", "score": 0.78,
                     "sourceAnchor": "AC-8421-03#PC-2", "targetAnchor": "CounterpartyConfig.java:41",
                     "explanation": "Embedding similarity only; not yet structurally confirmed.",
                     "extractionMethod": "embedding-cascade", "methodVersion": "1.0.0", "observedAt": "2026-09-06T09:00:20Z" }] }
  ]
}
```

- **Persistence:** for each mapping, write or update `TraceLink{relationType=GROUNDED_BY_CODE, SOURCE=criterionId, TARGET=codeSymbolId, status=candidate, rankingScore, method=generatedBy, methodVersion}`; attach each `EvidenceItem` as a `TraceEvidence` node linked `SUPPORTED_BY`.
- **Routing:**
  - If the best `rankingScore` for a *required* `businessElementId` (every precondition, the trigger, and every expected/forbidden effect) is below `GROUNDING_MIN_THRESHOLD` (suggested default `0.4`), loop back to **P4** with a widened search (more candidates, or a broader embedding radius) for that element specifically — this is the "weak grounding widens concept search" feedback edge.
  - Otherwise continue to **P6**. A mapping's `status` never moves past `candidate`/`pending` inside this pipeline; only a human reviewer moves it to `accepted` (D-22).
  - The PC-2 example above (`rankingScore` 0.72 from semantic similarity alone) is exactly the case the source design's "Joern is not only a final-stage tool" principle addresses: `P9`'s program evidence later confirms this predicate structurally controls the branch to `AutoNettingService.add`, and the same `TraceLink` is updated to `rankingScore = 0.94` (see `P9`'s persistence note) — a revision, not a new candidate.

### P6 — Technical behaviour model construction

- **Loop:** 2/3 boundary.
- **Tool:** LLM, constrained to use only `codeSymbolId` values that appear in `SymbolMappings` at or above `GROUNDING_MIN_THRESHOLD`; must not invent symbols.
- **Input:** `SymbolMappings` (filtered) + `BehaviourDecomposition`.
- **Output:** `TechnicalBehaviourModel`.

```json
{
  "criterionId": "AC-8421-03", "runId": "run-2026-09-06-0001",
  "entryPoint": { "codeSymbolId": "settlement-service::com.bank.settlement.SettlementProcessor.process" },
  "conditions": [
    { "businessElementId": "PC-1", "codeSymbolId": "settlement-service::com.bank.settlement.NettingEligibilityService.isEligible",
      "expression": "NettingEligibilityService.isEligible(obligation)", "expected": true }
  ],
  "expectedSinks": [{ "businessElementId": "EF-1", "codeSymbolId": "settlement-service::com.bank.settlement.AutoNettingService.add", "argumentRef": "obligation" }],
  "forbiddenSinks": [{ "businessElementId": "FE-1", "codeSymbolId": "settlement-service::com.bank.settlement.ManualNettingTaskService.create" }]
}
```

- **Persistence:** none directly (this artifact is the input contract to `P7`); it is the technical equivalent of the business BDD and is worth logging for audit even though it is not itself a graph node.

### P7 — Program-analysis question generation

- **Loop:** 3 (Program verification).
- **Tool:** deterministic rule mapping, not an LLM per run (the mapping rules — condition → control-flow question, entity→sink → data-flow question, effect → call-reachability question, forbidden effect → path-exclusion question — are authored once and reused).
- **Input:** `TechnicalBehaviourModel`.
- **Output:** `ProgramAnalysisQuestions` — **ephemeral**, consumed by `P8` in the same run.

```json
{
  "criterionId": "AC-8421-03", "runId": "run-2026-09-06-0001",
  "questions": [
    { "questionId": "Q1", "type": "control_flow",
      "sourceCodeSymbolId": "settlement-service::com.bank.settlement.SettlementProcessor.process",
      "sinkCodeSymbolId": "settlement-service::com.bank.settlement.AutoNettingService.add",
      "statement": "Is AutoNettingService.add reachable when both predicates are true?" }
  ]
}
```

- **Persistence:** none.

### P8 — Query planning and execution

- **Loop:** 3.
- **Tool:** the deterministic operation adapter (`getCallees`, `getCallers`, `getControlFlow`, `getDataFlow`, `getReferences`) translating each question into a query against the selected code-analysis engine (CPGQL for Joern, Cypher for GitNexus) and executing it (D-29). No LLM authors the engine query directly.
- **Input:** `ProgramAnalysisQuestions`.
- **Output:** `ProgramEvidenceRaw` — raw engine result. **Must not be read directly by an LLM**; `P9` normalizes it first (design principle: normalize before interpretation).

```json
{
  "criterionId": "AC-8421-03", "runId": "run-2026-09-06-0001",
  "results": [
    { "questionId": "Q1", "engine": "joern", "operation": "getControlFlow", "status": "path_found",
      "paths": [["settlement-service::com.bank.settlement.SettlementProcessor.process",
                 "settlement-service::com.bank.settlement.NettingEligibilityService.isEligible",
                 "settlement-service::com.bank.settlement.CounterpartyConfig.isAutoNettingEnabled",
                 "settlement-service::com.bank.settlement.AutoNettingService.add"]],
      "rawRef": "joern-run-0001/Q1.json" }
  ]
}
```

- **Persistence:** `rawRef` may be archived (object storage) for audit; the structured content is not itself graph-persisted.

### P9 — Evidence normalization

- **Loop:** 3.
- **Tool:** deterministic normalizer (no LLM) turning raw engine paths into graph-shaped evidence.
- **Input:** `ProgramEvidenceRaw` + `ProgramAnalysisQuestions` (for the claim text) + `TechnicalBehaviourModel` (for the entry point).
- **Output:** `ProgramEvidence`.

```json
{
  "criterionId": "AC-8421-03", "runId": "run-2026-09-06-0001",
  "items": [
    { "questionId": "Q1", "claim": "AutoNettingService.add is reachable when isEligible and isAutoNettingEnabled are both true",
      "result": "supported", "confidence": 0.94, "programPathId": "PP-AC842103-01", "programFactIds": ["PF-01", "PF-02"],
      "support": ["settlement-service::com.bank.settlement.NettingEligibilityService.isEligible",
                  "settlement-service::com.bank.settlement.CounterpartyConfig.isAutoNettingEnabled",
                  "settlement-service::com.bank.settlement.AutoNettingService.add"] }
  ]
}
```

- **Persistence:** create one `ProgramPath` node (`pathHash`, `sourceSnapshot`, `extractionMethod`, `extractionVersion`) `STARTS_AT` the entry-point `CodeSymbolVersion`; create one `ProgramFact` node per `programFactIds` entry, `HAS_PROGRAM_FACT` on that path; both `CONTRIBUTES_TO` a `TraceEvidence` node. That `TraceEvidence` is attached `SUPPORTED_BY` to the `P5` `GROUNDED_BY_CODE` `TraceLink` for the same `businessElementId` (join `questionId` → `TechnicalBehaviourModel` → `businessElementId`), and **its `confidence` revises that `TraceLink`'s `rankingScore`** — this is the "program evidence revises ranking score" feedback edge: the `PC-2` mapping from `P5` (`rankingScore 0.72`) becomes `rankingScore 0.94` once this control-flow confirmation lands, without creating a second candidate (D-24).

### P10 — Behaviour verification

- **Loop:** 3/4 boundary.
- **Tool:** LLM, constrained to read only `ProgramEvidence` (normalized), never `ProgramEvidenceRaw`.
- **Input:** `TechnicalBehaviourModel` + `ProgramEvidence`.
- **Output:** `BehaviourVerification`.

```json
{
  "criterionId": "AC-8421-03", "runId": "run-2026-09-06-0001",
  "status": "supported",
  "then": [{ "effectId": "EF-1", "status": "reachable" }, { "effectId": "FE-1", "status": "not_reachable_on_expected_path" }]
}
```

- **Persistence:** none directly; consumed by `P11`/`P12` and used to update the `GROUNDED_BY_CODE` `TraceLink`'s review-readiness (not its `status`, which still requires a human decision).
- **Routing:**
  - `status = "supported"` or `"partially_supported"` → continue to **P11a**.
  - `status = "contradicted"` and the grounding `rankingScore` from `P5` was already high (≥ `GROUNDING_MIN_THRESHOLD`, meaning the right symbol was chosen but it does not behave as expected) → skip test verification and go straight to **P12** with an `implementation_gap` candidate.
  - `status = "contradicted"` or `"inconclusive"` and the grounding `rankingScore` was marginal → loop back to **P5** to re-ground (the wrong candidate may have been picked) before concluding an implementation gap.

### P11a — Test discovery and candidate matching

- **Loop:** 4 (Test verification).
- **Tool:** the staged evidence cascade over tests (semantic test search, repo graph, Joern test-to-code call graph) plus LLM judgement.
- **Input:** `TechnicalBehaviourModel` + `BehaviourVerification`.
- **Output:** `TestCandidates`.

```json
{
  "criterionId": "AC-8421-03", "runId": "run-2026-09-06-0001",
  "candidates": [{ "testDefinitionId": "settlement-service::SettlementProcessorTest.shouldAutomaticallyNetEligibleObligation",
                    "matchedAspects": ["eligibility=true", "autoNetting=true", "AutoNettingService.add called"], "rankingScore": 0.95 }]
}
```

- **Persistence:** `TraceLink{relationType=VERIFIED_BY_TEST, SOURCE=criterionId, TARGET=testCaseId (resolved from testDefinitionId), status=candidate}`, `SUPPORTED_BY` a `semantic_similarity` `TraceEvidence`. (`VERIFIED_BY_TEST` is the same relationship type already used at `AtomicWorkItem` grain; here its `SOURCE` is the finer-grained `AcceptanceCriterion`, which the existing dictionary already permits generically.)

### P11b — Test path verification

- **Loop:** 4.
- **Tool:** deterministic test-AST parser / static analysis of the test source (mock-setup and `verify`/`assert` detection — the same technique as the source design's Mockito example), optionally cross-checked against a coverage tool.
- **Input:** `TestCandidates` (filtered to `rankingScore` above a test-matching threshold) + `TechnicalBehaviourModel`.
- **Output:** `TestCoverage`.

```json
{
  "criterionId": "AC-8421-03", "runId": "run-2026-09-06-0001",
  "testDefinitionId": "settlement-service::SettlementProcessorTest.shouldAutomaticallyNetEligibleObligation",
  "preconditionsCovered": ["PC-1", "PC-2"], "triggerCovered": true,
  "positiveEffectsCovered": ["EF-1"], "negativeEffectsCovered": ["FE-1"], "overall": "covered"
}
```

- **Persistence:** `TraceEvidence{evidenceType=assertion|coverage|mutation}` `CONTRIBUTES_TO` the `P11a` `VERIFIED_BY_TEST` `TraceLink`; a `"covered"` result is what a human reviewer needs to move that link's `status` toward `accepted`.

### P12 — Gap classification

- **Loop:** 4, terminal automated step.
- **Tool:** deterministic rule engine (no LLM) — the table below is the entire rule set.
- **Input:** `BehaviourVerification` + `TestCoverage` (absent/`null` when `P11a` found no candidate at all).
- **Output:** `GapClassification`.

| `BehaviourVerification.status` | `TestCoverage.overall` | `outcome` | `gapType` |
|---|---|---|---|
| `supported` / `partially_supported` | `covered` | `not_applicable` | `null` |
| `supported` / `partially_supported` | `partial` | `gap_candidate` | `partial_test_gap` |
| `supported` / `partially_supported` | `not_covered` / no candidate found | `gap_candidate` | `regression_test_gap` |
| `contradicted` | any | `gap_candidate` | `implementation_gap` |
| `inconclusive` | any | `insufficient_evidence` | `null` |

```json
{
  "criterionId": "AC-8421-03", "runId": "run-2026-09-06-0001",
  "outcome": "not_applicable", "gapType": null,
  "codeSnapshot": "abc123", "testSnapshot": "def456",
  "evidenceRefs": ["TL-GROUNDED-AC842103-EF1", "TL-VERIFIED-AC842103-01", "TE-Q1", "TE-Q2", "TE-Q3"],
  "reviewState": "pending"
}
```

- **Persistence:** one dated deficit `TraceEvidence` (D-27) carrying the new `gapType` property (D-29), `reviewState = pending` until a human reviewer accepts or rejects it. This is the pipeline's only output that a reviewer is expected to act on directly; every upstream artifact exists to make this one decision explainable.

### Beyond P12 — human review and calibration (not automated)

A reviewer accepts, rejects or corrects each `candidate`/`pending` `TraceLink` (the `P5` `GROUNDED_BY_CODE` link and the `P11a` `VERIFIED_BY_TEST` link) and each `P12` `GapClassification`. Those decisions are what populate the A-17 evaluation set and, over time, `calibratedConfidence`. This step is out of this pipeline's automated scope by design (D-22): no step above ever moves a `TraceLink.status` past `candidate`/`pending`, or sets `calibratedConfidence` to anything but `null`.

## Configuration parameters

These are illustrative defaults, not fixed policy — tune them per A-17 calibration once a reviewed evaluation set exists.

| Parameter | Default | Used by |
|---|---|---|
| `GROUNDING_MIN_THRESHOLD` | `0.4` | P5 (loop back to P4 below this), P6 (symbol eligible for the technical behaviour model at or above this) |
| `GROUNDING_REGROUND_ON_CONTRADICTION_THRESHOLD` | `0.6` | P10 routing: below this, a `contradicted` result re-grounds via P5 instead of concluding `implementation_gap` |
| `TEST_MATCH_MIN_THRESHOLD` | `0.5` | P11b: minimum P11a `rankingScore` for a candidate to be structurally checked |

## Verifying a new implementation

Before wiring these steps into a real orchestrator, run `validate_pipeline_example.py` against the new implementation's own sample output for one criterion (swap in real `codeSymbolId`/`testDefinitionId` values from the target repository). A passing run proves two things mechanically rather than by inspection: every artifact matches its schema `$def`, and no step invented an id another step didn't define or consume correctly. Treat a failing consistency check the same as a failing unit test — it means two steps' code disagrees about the shape of the artifact between them, which is exactly the class of integration bug this contract is meant to prevent.
