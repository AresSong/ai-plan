# AI SDLC graph data-modeling approach

## Purpose

This document converts the initial AI SDLC traceability investigation into a repeatable data-modeling method. It covers business discovery, a high-level model, detailed models for each subject area, database design, and user views without breaking the links between levels.

The method does not choose a graph database until the detailed model is understood. A labeled property graph is a practical starting choice because the main needs are following links, finding impact, showing evidence, and loading data from working systems. RDF is still an option if sharing formal definitions across organizations becomes more important later.

Eight companion diagrams and one controlled data dictionary are provided:

- [Graph logical data dictionary](./AI-SDLC-graph-logical-data-dictionary.md)

- [Graph modeling lifecycle](./diagrams/graph-modeling-lifecycle.html)
- [AI SDLC business activity flow](./diagrams/ai-sdlc-business-activity-flow.html)
- [Connected AI SDLC system overview](./diagrams/ai-sdlc-connected-logical-graph.html)
- [AI SDLC target graph data model](./diagrams/ai-sdlc-target-graph-data-model.html)
- [Alternative ER: strict Story-to-commit 1:1](./diagrams/ai-sdlc-story-commit-1-to-1-er.html)
- [Detailed Story-to-Confluence design model](./diagrams/ai-sdlc-confluence-design-model.html)
- [Detailed Story-to-test traceability model](./diagrams/ai-sdlc-test-traceability-model.html)
- [Detailed whole-solution code structure model](./diagrams/ai-sdlc-solution-code-structure-model.html)

## What to take to the SME

Do not start the SME session with a blank page. Start with the filled-in working draft below and ask the SME to correct it.

The draft is based on the initial investigation. Items marked **Known** come directly from it. Items marked **Working recommendation** should be corrected or approved by the SME.

### Current setting already known

| Topic | Working detail | Status |
|---|---|---|
| Delivery tracking | Feature, Story and Task are held in Azure Boards | Known |
| Business and technical design | Design is held in Confluence pages and, where useful, meaningful page sections | Known |
| Source code | Java and JavaScript are mainly held in Azure Repos | Known |
| Tests | Test code is held in repositories; test runs and results may be published through pipelines | Known |
| Main purpose | Connect delivery, design, code and tests so AI can explain change, impact and evidence | Known |
| Estate | Brownfield banking environment with existing gaps and uneven links | Known |
| Main human link point | Story is the normal link point for a change, but it is not the parent of every design, code or test item | Working recommendation |
| Link strategy | New work and brownfield recovery create the same target links; every link retains its evidence and quality state | Working recommendation |
| History | Keep past PRs, code versions, replaced design and deleted code; build a separate current-state view | Working recommendation |
| Test relationship | A test can verify a Story even when it does not run in the PR pipeline | Working recommendation |

### Working assumptions to take to the SME

These assumptions let the model be discussed as a filled-in proposal. They are not facts until the relevant SME approves them.

| ID | Working assumption | Why it is currently used | What the SME must confirm |
|---|---|---|---|
| A-01 | User Story is the normal business-intent anchor | It is the smallest understandable business change shared across Azure Boards, design, code and tests | Are defects, incidents or other work-item types equal anchors in some teams? |
| A-02 | Story links primarily to a normal source Commit, not to the PR as its implementation unit | The commit has an immutable SHA and a defined parent comparison from which file and symbol changes can be derived | Can every production repository retain or capture the relevant source commits before squash completion? |
| A-03 | Pull Request is review and merge context | A PR may contain several Stories and commits; assigning every PR change to every Story creates false fine-code links | Which PR policies and work-item links must be retained as evidence? |
| A-04 | Strict Story 1:1 implementation Commit is an optional delivery rule, not a graph limitation | It gives the cleanest automatic attribution but may not fit follow-up commits, cross-repository changes or emergency fixes | Should strict 1:1 be enforced, piloted for selected teams, or rejected? |
| A-05 | Commit-to-code detail is derived from the parent Git comparison | Git provides file changes; Java and JavaScript/TypeScript parsing can identify affected symbols | Which languages and generated/configuration files need broader file-level handling? |
| A-06 | Code Symbol is the impact-analysis unit when parsing succeeds | Methods, functions, classes and interfaces support more useful dependency traversal than a diff hunk | Which symbol kinds and dependency types are reliable enough for production use? |
| A-07 | Confluence page ID and page version are available | Stable source IDs and versions are required to identify the exact design evidence | Which Confluence APIs, retention rules and page restrictions apply? |
| A-08 | Only meaningful stable page sections become graph records | Graphing every paragraph creates noise and unstable identities | What makes a section important enough to promote? |
| A-09 | Story-to-design recovery may use an LLM only to propose links | Brownfield volume makes full manual linking unrealistic, while model output alone is not reliable enough to accept as fact | What confidence and review rules are required? |
| A-10 | Test Case states intended verification; Test Execution is dated evidence | The same Test Case may run many times against different builds and environments | Which system supplies the durable Test Case ID and result evidence? |
| A-11 | Component is a stable solution boundary and may span repositories | Repository layout is a source-code concern and may not match business or deployment structure | Who owns the Solution and Component registry? |
| A-12 | Historical evidence is retained and current state is a view | Replaced design, old commits, deleted code and failed tests remain necessary for explanation and audit | What retention, privacy and access rules limit history? |

### Architecture decision log

| ID | Decision | Reason | Main consequence or exception |
|---|---|---|---|
| D-01 | Use C4-style progressive detail, not the exact C4 levels | The useful idea is moving from business scope to connected overview to subject detail; this is a data model rather than a software architecture description | All levels are views of one target graph, not separate databases |
| D-02 | Make `Story -> Commit` the primary implementation path in the overview | Commit SHA is immutable and its parent diff can be parsed into exact changes | PR remains connected as review context; brownfield uncertainty may stop at PR or Commit |
| D-03 | Do not make Story the parent of design, components, code or tests | Those records have independent identities and lifecycles and may serve many Stories | Connect them with named relationships carrying evidence and time |
| D-04 | Do not store routine Story IDs in source-code comments | The full reasoning is listed below | A lasting business rule or design explanation may still belong in a code comment |
| D-05 | Treat a diff hunk as evidence, not the impact unit | Hunk boundaries are created for patch display and can split one method or combine nearby items | Parse affected lines into FileChange and SymbolChange records |
| D-06 | Separate Code Symbol from Code Symbol Version | A stable method/function identity must survive several commits, while historical analysis needs the exact version | Version identity includes Commit SHA or source snapshot |
| D-07 | Store one directed `DEPENDS_ON` relationship | One relationship supports outbound traversal forward and inbound traversal backward | Do not store a duplicate inverse relationship |
| D-08 | Keep solution structure separate from repository structure | Components may span repositories and repositories may contain several components | Model Component-to-Repository as many-to-many where required |
| D-09 | Link Story to an exact Confluence Section Version through Story Design Link | Page-level links are often too broad; the link itself needs evidence, confidence, review and valid time | Whole-page links remain allowed when the page is truly Story-specific |
| D-10 | Use deterministic evidence before LLM suggestions | Explicit IDs, Git links and source history are more dependable than semantic similarity | Model-generated links remain suggested until accepted |
| D-11 | Separate Test Case, Test Definition, Test Execution and Test Result | Intended behavior, executable code, a run attempt and its outcome change independently | A retry creates another execution/result rather than overwriting the first |
| D-12 | Record runtime coverage from Test Execution to Code Symbol Version | Coverage is observed for one build and run, not permanently true for a Test Case | Test Case-to-code views are calculated summaries |
| D-13 | Put foreign keys and link tables only in a relational loading model | Graph relationships provide the logical links; SQL staging still needs referential checks | The graph and relational loading schema are separate deliverables |
| D-14 | Keep inferred links incomplete when evidence is incomplete | A fully connected but incorrect graph would produce misleading impact results | Missing, suggested, conflicting and accepted states remain visible |
| D-15 | Allow shortcut links only when their detailed evidence path can be rebuilt | Aggregated Feature-to-Component views are useful but must remain explainable | Store derivation rule, source link IDs, time and freshness |

#### Why routine Story IDs do not belong in code comments

Staleness is only one problem. Routine Story annotations in methods, classes or files are rejected as the main linking practice for these reasons:

1. **The relationship is many over time.** The same method can be created for one Story and later changed for many others. One comment cannot represent the full contribution history without becoming a growing manual list.
2. **Refactoring changes location, not business history.** Code may be renamed, split, merged, moved or copied. A comment follows whichever text was moved, while the Story contribution may apply to only part of the new code or to several new symbols.
3. **Deletion removes the annotation.** When code is deleted, the Story link disappears from the current source even though historical explanation still needs it.
4. **Comments are not a controlled relationship store.** They cannot reliably hold link origin, evidence, confidence, reviewer, valid time, rejection state or access rules.
5. **They create two sources of truth.** Azure Boards and Git already contain work-item and commit history. A second manually maintained ID inside code will eventually disagree with them.
6. **They couple code to one tracking system.** Story IDs may collide across Azure DevOps projects, change during migration, or be meaningless when code is reused in another product or organization.
7. **Coverage would be uneven.** Generated code, configuration, SQL, scripts and third-party code cannot follow the same comment convention, so apparent completeness would be misleading.
8. **They expose business metadata unnecessarily.** Repository readers may gain access to sensitive work-item identifiers or business context that has stricter permissions in Azure Boards or Confluence.
9. **They add review and maintenance noise.** Developers would spend time updating tracing comments during routine refactoring, and reviewers could not easily prove that every annotation remains correct.
10. **Git already provides the immutable join point.** A Story-to-Commit relationship plus the parent diff and parsed SymbolChanges reconstructs the fine code link with time and evidence, without modifying executable source.

Code comments should still explain a lasting business rule, safety constraint or non-obvious design reason that a maintainer needs while reading the code. The comment should explain the rule itself; an external decision or design link may be included when it is stable and useful, but a transient Story ID should not be the only explanation.

### Draft business activities

| Activity | Business outcome | Main records | Minimum human action | Links software can add | SME should confirm |
|---|---|---|---|---|---|
| Shape a change | A business capability or change is agreed | Epic, Feature, owner, affected area | Create the Feature and ownership | Read existing hierarchy and component ownership | Where are Epics and portfolio goals held? |
| State the need | The change is small enough to build and test | Story, Acceptance Criteria, Task | Put the Story under a Feature; write testable criteria | Read parent/child links and named components | Is Story the normal change unit for every team? |
| Prepare design | Business rules and technical choices are recorded | Confluence page/section, decision, business rule | Link the Story or Feature to the design, or record that no design is needed | Read page ID, section, version and replacement history | Which changes need business design, technical design or an exception? |
| Implement change | Reviewed code changes can be traced to intent | Pull Request, Commit, GitDiff, FileChange, SymbolChange, CodeSymbol | Link the normal source Commit to its primary Story; keep PR work-item links as review context | Parse commit diffs into file and symbol changes; inherit Story attribution only when unambiguous | Can strict Story 1:1 Commit be enforced, and which repositories need an exception? |
| Define verification | Expected behavior has a durable test link | Test Case, automated test, suite, purpose | Link important acceptance/system/end-to-end tests to Story or Feature | Discover unit/component tests and suite membership | Where should Story/test links be stored: Test Plans, metadata file or both? |
| Run verification | A dated result proves what ran against which build | Test Run, Test Result, Build, Environment | Normally none beyond existing test work | Test -> Run -> Result -> Build/Commit; coverage -> code | Which pipelines and environments produce usable evidence today? |
| Release or deploy | A release can be explained by included changes and results | Release, deployment, approval, environment | Follow the existing approval process | Release -> Build -> Commit -> Story and test evidence | What is the release record and source of truth? |
| Maintain and assess impact | Teams understand why code exists and what may be affected | Current component/code, dependency, owner, history | Keep component ownership and key design current | Calls, dependencies, code history, covering tests and related Stories | Which dependency and ownership sources are trusted? |

### Draft shared business objects

These are the high-level objects for the first business model. Detailed types can be added later without changing the overall shape.

| Object group | Suggested high-level objects | Main source | Why it matters |
|---|---|---|---|
| Change intent | Feature, Story, Acceptance Criterion | Azure Boards | Explains why a change exists |
| Design knowledge | Design Page, Design Section, Decision, Business Rule | Confluence | Explains intended behavior and choices |
| Product structure | Domain, Solution, Component, Module | Architecture/service records plus code | Provides stable grouping above files and methods |
| Change history | Pull Request, Commit | Azure Repos | Provides reviewed and dated change evidence |
| Code | Repository, File, Class, Function/Method, Code Version | Git plus code parsers | Shows the actual implementation |
| Test intent | Test Case, Automated Test, Test Suite | Test Plans and repositories | States what behavior should be checked |
| Run evidence | Build, Test Run, Test Result, Environment, Release | Pipelines and test tools | Proves what happened at a particular time |
| Responsibility and access | Team, Owner, Source System, Access Rule | Existing identity and ownership sources | Keeps answers owned and permission-safe |

### Graph bus matrix

This adapts the dimensional-model bus matrix. Rows are business activities. Columns are shared graph objects. Each cell says how the activity uses the object.

The matrix is the best workshop tool for checking scope and finding missing links. It should be used together with the activity flow, not instead of it.

| Business activity | Change intent | Design knowledge | Product structure | Change history | Code | Test intent | Run evidence | Owner/access |
|---|---|---|---|---|---|---|---|---|
| Shape a change | **Creates Feature** | Reads domain context | Names affected area | - | - | Defines test approach | - | Assigns owner |
| State the need | **Creates Story and criteria** | Links when needed | Names component | - | - | Sets expected behavior | - | Uses team access |
| Prepare design | Links Feature/Story | **Creates or updates design** | Describes solution/component | - | May name key code area | Defines scenarios | - | Records owner/status |
| Implement change | Links Story/Bug | Reads design | Selects repository/component | **Creates PR and commits** | **Changes files and symbols** | Adds/updates automated tests | Produces build when available | Uses repository access |
| Define verification | Links Story/criteria | Reads rules and design | Names tested component | May refer to PR | Points to tested area | **Creates Test Case/test definition** | - | Uses test access |
| Run verification | Reads linked Story | Reads expected behavior | Identifies component | Binds to commit/build | Adds coverage evidence | Selects tests/suites | **Creates run and result** | Uses environment access |
| Release or deploy | Groups included Stories | Reads approved design | Identifies deployed components | Uses merged commits | Uses built version | Uses required test set | **Creates release evidence** | Records approval/access |
| Maintain/impact | Explains past reasons | Shows current/replaced design | **Finds owner and dependencies** | Reads full change history | **Finds current and past code** | Finds covering tests | Reads latest trusted result | Checks caller access |

Use these questions to review every row with the SME:

1. Is this a real business activity or only a system action?
2. Who is responsible for it?
3. What record proves it happened?
4. Which link must a person or source system create?
5. Which links can software safely work out?
6. What does “complete” mean for this activity?
7. Which users may see the object and its content?

### Recommended visual set

| Visual | Best question | Use in SME session |
|---|---|---|
| Business activity flow | How does change and evidence move through the SDLC? | Correct the sequence, work streams, hand-offs and current gaps |
| Graph bus matrix | Which shared objects does each activity create, link or read? | Check scope, ownership and missing object groups |
| Target graph data model | How do Story, design, fine code changes, tests and solution structure connect? | Agree the target records, relationship meanings, evidence and quality states |
| Detailed model by area | What is the exact level of detail, ID and history rule? | Work with each specialist after the high-level model is agreed |

A normal flowchart alone is not enough because it makes the SDLC look like one strict pipeline. The initial investigation shows that design, implementation and testing can move on partly independent paths. The activity flow therefore uses separate work streams, while the bus matrix checks that the same shared objects are used consistently.

## Executive recommendation

Use the discipline of dimensional modeling, but not its fact/dimension shape.

Retain these habits:

- start with business processes and decisions;
- define the questions the model must answer;
- declare the exact level of detail before fields and relationships;
- use shared IDs and agreed terms;
- separate the high-level, detailed, and stored models;
- validate with representative queries and data-quality rules;
- publish governed aggregate views for consumers.

Replace these dimensional assumptions:

| Dimensional-model habit | Graph-model equivalent |
|---|---|
| Business process selects a fact table | Business activity selects the connected objects and starting points it needs |
| Declare the fact-table level | Declare object identity, relationship meaning, version level, and when each record is valid |
| Dimensions provide context | Context is represented by graph objects and named relationships |
| Conformed dimensions connect stars | Shared IDs and agreed relationship names connect each subject area |
| Rollups are stored aggregates | Rollups are named graph views or derived relationships with a path back to their evidence |
| Slowly changing dimensions preserve history | Unchanged historical versions, dated relationships, and current-state views preserve history |

The main design principles are:

> Define one target graph for new changes and brownfield recovery. The target meanings do not change; only the way links are collected changes.

> Build the graph at the finest useful level of detail, but never claim more precision than the evidence supports. Every uncertain link must remain visibly uncertain.

> Story is the main business-intent anchor. The target is to connect Story, design, code, tests, and solution structure. Component-level links help discovery and grouping, but they do not replace Story-to-design or Story-to-code links.

## Target graph data model

Define the target graph before choosing new-work controls or brownfield recovery techniques. Both approaches must produce the same node types, link types, evidence fields, and quality states.

### Target end-to-end paths

```text
Feature -> Story -> StoryDesignLink -> DesignSectionVersion
                 -> Commit -> GitDiff -> FileChange -> SymbolChange -> CodeSymbol
                 -> TestCase -> TestDefinition -> TestExecution -> TestResult

PullRequest -> Commit
CodeSymbol -> Module -> Component -> Solution
TestExecution -> COVERS -> CodeSymbolVersion
```

Story-to-design and Story-to-code relationships carry evidence, source, confidence, and review state. They do not require a separate link node in the target graph unless the selected database cannot adequately search, secure, or version relationship properties.

### Core target objects

| Object | Exact level | Purpose |
|---|---|---|
| Story | One understandable unit of business change | Main anchor for why design, code, and tests exist |
| DesignSectionVersion | One meaningful Confluence section at one page version | Identifies the exact design content that explains a Story |
| StoryDesignLink | One evidence-bearing statement that a design section specifies a Story | Holds evidence, source, confidence, review state, and effective time |
| PullRequest | One reviewed change proposal in one repository | Provides review and merge context; may contain work for several Stories |
| Commit | One immutable repository revision | Provides build and change history; is not required to be one-to-one with Story |
| GitDiff | One comparison between a base commit and a target commit | Defines exactly which two Git trees were compared; it can represent a commit diff or the final PR diff |
| FileChange | One file path added, modified, deleted, moved, or renamed in one GitDiff | Stores file status and diff hunks without treating each hunk as a business object |
| SymbolChange | One Java or JavaScript/TypeScript class, function, method, interface, or export affected by one FileChange | Provides the preferred fine code unit for Story attribution and impact analysis |
| CodeSymbol | One logical class, function, method, interface, or export across versions | Provides the stable code identity used by call and dependency relationships |
| CodeSymbolVersion | One CodeSymbol at one commit or source snapshot | Supports exact historical explanation and before/after comparison |
| Component/Solution | One agreed implementation or solution boundary | Groups code, design, tests, dependencies, and ownership |
| TestCase | One intended behavior check | Connects Story or Acceptance Criterion to what must be verified |
| TestDefinition | One executable JUnit, Jest, or similar test | Implements a Test Case and produces build-specific executions |
| TestExecution | One attempt to run one Test Definition against one build and environment | Provides time-bound evidence and runtime coverage |
| TestResult | One outcome for one Test Execution | Records pass, fail, skipped, duration, and evidence without overwriting earlier attempts |

### Story-to-code target

The target implementation chain is:

```text
PullRequest -> Commit -> GitDiff -> FileChange -> SymbolChange -> CodeSymbol
                                                                  |
                                                                  +-> Module -> Component
```

A Git diff hunk is a block of added and removed lines created for display and patching. It is not a stable or meaningful code object for impact analysis. One method can contain several hunks, and one hunk can include imports, formatting, or several nearby code items.

For this Java and JavaScript/TypeScript estate:

- `GitDiff` records `repositoryId`, `baseCommitSha`, `targetCommitSha`, and whether it represents a commit comparison or the final PR comparison.
- `FileChange` records one affected path plus add/modify/delete/rename/move status and retains its diff hunks as evidence.
- `SymbolChange` is produced by parsing the file before and after the diff. It records one affected Java class/method/interface or JavaScript/TypeScript class/function/method/export, the change type, changed line ranges, and before/after symbol versions.
- `CodeSymbol` is the longer-lived identity. For Java, use repository plus fully qualified class/method name and signature. For JavaScript/TypeScript, use repository, module path, exported/local scope, symbol name, and signature where available.

The Story attaches directly to the finest supported record:

```text
Story -[IMPLEMENTED_BY_COMMIT]-> Commit
Story -[IMPLEMENTED_BY_FILE_CHANGE]-> FileChange
Story -[IMPLEMENTED_BY_SYMBOL_CHANGE]-> SymbolChange
```

These are three allowed relationship types, not three copies of one change. If a Story has an accepted `IMPLEMENTED_BY_SYMBOL_CHANGE` relationship, the graph calculates its file, commit, PR, module, component, and solution through the implementation chain. It does not also create maintained Story-to-file and Story-to-commit relationships for the same evidence.

Every Story-to-code relationship needs these fields:

| Field | Meaning |
|---|---|
| `storyId` | Story or accepted equivalent such as a defect or incident |
| `targetId` | Commit, FileChange, or SymbolChange ID |
| `contributionType` | Business implementation, test code, configuration, data change, documentation, or supporting refactor |
| `evidenceRef` | PR work-item link, commit message, approved mapping, diff, review note, or recovery evidence |
| `linkOrigin` | Declared, derived from an unambiguous rule, or suggested |
| `confidence` | Strength of the attribution, not similarity alone |
| `reviewStatus` | Not needed, pending, accepted, or rejected |
| `validFrom`, `validTo` | Period for which the attribution applies when it is time-bound |

### How the fine code link is built

For a new change:

1. Azure Boards supplies the Story.
2. Azure Repos supplies the PR, its source commits, and any commit-to-work-item links.
3. For each commit used for attribution, compare the commit with its parent to create one GitDiff and its FileChanges.
4. Parse the before and after Java or JavaScript/TypeScript source to find which classes, functions, or methods intersect the changed lines. Create one SymbolChange per affected symbol, not one per diff hunk.
5. If the commit has one primary Story, derive Story-to-SymbolChange relationships for its parsed symbol changes and Story-to-FileChange relationships for changes that cannot be parsed, such as configuration files.
6. If a commit contains several primary Stories, do not allocate every SymbolChange to every Story. Split the commit, or have the author/reviewer confirm the Story-to-SymbolChange allocation. Keep unresolved changes at commit level.

One Story can have many commits. The proposed new-work rule is therefore not one-to-one. It is: each normal source commit should name one primary Story when fine Story-to-code attribution is required. A commit may name supporting Stories, but supporting links do not automatically inherit every FileChange and SymbolChange.

Azure Repos can create a commit/work-item link when the commit message contains `#<work item ID>` and commit mention linking is enabled. The built-in linked-work-item branch policy checks the PR, not each commit, so enforcing one primary Story per commit requires a custom PR validation check or status check. If squash merge is used, the target branch receives one new commit without the source-commit history; capture source commit attribution and diffs before PR completion, or use a merge method that retains the commit history where this evidence is required.

Do not put routine Story IDs in code comments. The consolidated reasoning is recorded in architecture decision D-04: the relationship is historical and many-over-time, refactoring and deletion break location-based annotations, comments cannot carry evidence and review state, and Git already supplies the immutable join point. Use a code comment only for a lasting business rule or design decision that a maintainer needs to understand in the source.

### How fine code drives impact analysis

Impact analysis starts from `CodeSymbol`, not from the diff hunk:

1. use the Story link to find its SymbolChanges;
2. resolve added or modified changes to the after-version CodeSymbol, and deleted changes to the before-version CodeSymbol;
3. follow incoming calls, imports, inheritance, interface implementation, build dependencies, API use, events, and data-contract dependencies at the selected point in time;
4. roll affected symbols up to files, modules, components, repositories, and solutions;
5. retrieve tests, owners, design, and other Stories only after the technical impact set is known.

If only a FileChange link is available, the impact seed is every relevant symbol in that file, so the result is broader. If only a Commit link is available, parse all its FileChanges and SymbolChanges, but mark Story-specific results as ambiguous when the commit has several primary Stories.

### Precision rules for Story-to-code links

- Story-to-commit, Story-to-file-change, and Story-to-symbol-change are many-to-many relationships. Do not enforce one commit per Story or one PR per Story.
- For new work, one primary Story per normal source commit is the preferred practice because it gives software a defensible attribution rule. One Story may still have many commits.
- When several primary Stories share a commit, do not copy every changed file or method to every Story. Keep the known commit-level links and create finer links only where evidence supports the allocation.
- A suggested method link may help discovery, but it must not be used as accepted fact in audit or impact answers.
- Keep current code dependencies separate from historical Story contributions. Technical impact starts with changed/current code and follows current calls and dependencies. Stories are retrieved afterward to explain why affected code exists.

### Story-to-design target

The target relationship is:

```text
Story -> StoryDesignLink -> DesignSectionVersion -> DesignArtifact
```

A page-level link is allowed when the whole page is about one Story. Otherwise the target should identify the relevant section and page version. One design section may specify several Stories, and a Story may use several design sections.

`StoryDesignLink` carries the same origin, evidence, confidence, review, validity, and security fields as other evidence-bearing links. A Component or Solution link can support discovery, but it does not replace the target Story-to-design statement.

### Same target, two achievement approaches

| Concern | New changes | Brownfield recovery |
|---|---|---|
| Story-to-PR | Require every production PR to name the relevant Story or accepted equivalent | Import existing work-item links, PR text, branch names, and commit references |
| Story-to-commit | Encourage focused commits and a Story reference when a commit clearly serves one Story; allow many commits per Story | Recover existing Story IDs and work-item links; do not assume all commits in a multi-Story PR belong equally to every Story |
| Story-to-file/method | Parse the diff; for a multi-Story or large PR, have tooling propose the allocation and let the author/reviewer confirm only the ambiguous part | Rebuild historical diffs and code structure; combine explicit IDs, dates, authors, design text, and code meaning to propose links |
| Story-to-design | Capture Story and Component/Solution IDs in change-specific page metadata or links | Read existing links and IDs first; then propose section-level matches from page history and content |
| Link quality | Prevent new gaps at source and review exceptions in the normal workflow | Preserve accepted, suggested, missing, and conflicting states; prioritize review by business value and risk |
| Human work | Confirm exceptions and ambiguous allocations, rather than annotate every method | Review a selected high-value queue, rather than backfill every page and code item manually |

The new-work practice should not require one commit per Story. A practical middle ground is:

1. require Story links on the PR;
2. encourage each commit to have one primary Story when the work can be separated naturally;
3. parse every merged diff into file and symbol changes;
4. automatically inherit Story attribution only when the evidence is unambiguous;
5. for multi-Story or large PRs, generate a proposed Story-to-file/method allocation for author or reviewer confirmation;
6. retain unresolved parts at PR or commit level rather than inventing method-level certainty.

For brownfield recovery, an LLM is one candidate generator, not the source of truth. Its output must identify the proposed Story, page section or code change, the supporting source excerpts or diff, confidence, model version, and review state. Deterministic evidence always takes priority.

## What “aggregate” means in this graph

An aggregate graph is a view of the shared detailed graph for a particular audience or use. It is not a separately maintained summary model.

For example, an aggregate relationship:

```text
Feature F-8420 -[IMPLEMENTED_BY]-> Component cards-api
```

may be derived from this evidence path:

```text
Feature F-8420
  -[PARENT_OF]-> Story US-8421
  -[IMPLEMENTED_BY_SYMBOL_CHANGE]-> SymbolChange SC-617-08
  -[AFFECTS]-> CodeSymbol calculateLimit
  <-[CONTAINS]- Component cards-api
```

The convenience edge is safe only when it records its derivation rule, source path or evidence reference, observation time, and freshness. The detailed path remains authoritative.

## Modeling lifecycle

### Stage 1 - Frame the business process and decisions

Start with the work people perform and the decisions they need to make, not with graph technology or source-system tables.

Inputs:

- business processes and lifecycle stages;
- actors and responsibilities;
- source systems and security boundaries;
- audit, compliance, and AI-assistance needs;
- representative brownfield and new-delivery cases.

Produce a business-question list. Each question must identify the expected answer, how far the graph may be followed, the required point in time, and the permitted evidence level.

Representative questions:

| ID | Business question | Required path | Time view |
|---|---|---|---|
| CQ-01 | What implements Feature F-8420? | Feature -> Story -> SymbolChange -> CodeSymbol -> component | Current |
| CQ-02 | Why does `calculateLimit()` exist? | CodeSymbol <- SymbolChange <- Story; Story -> StoryDesignLink -> design/rule | Historical |
| CQ-03 | What could break if this method changes? | Current code item -> current callers/dependencies -> components/tests/owners; retrieve Stories afterward for explanation | Current plus latest evidence |
| CQ-04 | Does a Story have sufficient release evidence? | Story -> design -> PR/build -> test execution/result | Release snapshot |
| CQ-05 | Which active components have only a suggested design link? | Component -> design link, filtered by link origin | Current |

Gate: do not continue until the priority questions, authorized users, and required time perspective are explicit.

### Stage 2 - Create the conceptual aggregate graph

Model business concepts and the few relationships needed to answer the priority questions. Avoid source-specific IDs, implementation fields, and exhaustive taxonomies.

Recommended conceptual domains:

| Domain | Business purpose | Stable anchor concepts |
|---|---|---|
| Delivery intent | Explain why change was requested | Epic, Feature, Story, Acceptance Criterion |
| Design knowledge | Explain intended behavior and governing decisions | Design Artifact, Design Section, Decision, Business Rule |
| Implementation | Explain how and where change was realized | Component, Pull Request, Commit, Code Symbol |
| Verification | Explain what behavior is checked | Test Case, Test Definition, Test Suite |
| Execution evidence | Prove what happened at a point in time | Build, Test Execution, Test Result, Environment, Release |
| Organization and governance | Explain ownership, access, and policy | Team, Person/Agent, System of Record, Access Policy |

The conceptual backbone is:

```text
Feature -> Story -> StoryDesignLink -> DesignSectionVersion
                  -> Commit/FileChange/SymbolChange -> CodeSymbol
                  -> Test Case       -> Execution Evidence

Component connects design, code, ownership, dependencies, and tests.
```

Story is the primary change-intent anchor. It is not the universal root: components, code, design, tests, builds, and releases have lifecycles that span many Stories.

Gate: every high-level object and relationship must support at least one business question.

### Stage 3 - Decompose into connected domain and level models

Build one bounded model per domain. Within each model, distinguish containment from classification, change history, semantic linkage, and execution evidence.

Each domain model must declare:

1. scope and questions;
2. node types and their exact level of detail;
3. shared identity and source identity;
4. containment or hierarchy relationships;
5. cross-domain anchor relationships;
6. temporal and version behavior;
7. explicit, derived, and inferred link rules;
8. access-control inheritance;
9. validation constraints;
10. supported high-level views.

Gate: every domain has at least one stable cross-domain anchor. No domain is connected only by free-text similarity.

### Stage 4 - Define the detailed shared logical graph

Expand each subject area to the finest level that creates decision value. Do not equate “available in the source” with “must be a graph object.”

Detailed-object selection rules:

- create a node when the object has independent identity, lifecycle, access rules, or traversal value;
- use a property when the value has no independent lifecycle or relationships;
- use a separate version node when historical identity matters;
- use a link record when its origin, confidence, evidence, or approval must be queried;
- retain text chunks in a text/vector index unless they need stable graph identity;
- do not create nodes for every paragraph, source line, or transient parser token.

Gate: every detailed type has a shared ID rule, version rule, lifecycle rule, and roll-up path.

### Stage 5 - Map, implement, validate, and publish views

Map the shared types to source APIs and events, select the graph technology, enforce rules, and publish named views for AI and reporting.

Outputs:

- source-to-shared-model mapping specifications;
- graph constraints and indexes;
- incremental ingestion and reconciliation rules;
- current-state and historical views;
- user views and shortcut-link definitions;
- data-quality and traceability-coverage dashboards;
- query-based acceptance tests.

Gate: business-question queries return explainable answers with source evidence, access filtering, and a declared freshness level.

## Model hierarchy and connection contract

The levels below are deliverables, not separate databases.

| Level | Primary audience | Contains | Connects downward through | Verification |
|---|---|---|---|---|
| L0 Business scope | Business, risk, product | Processes, actors, decisions, business questions | Question-to-object coverage | Every priority question is testable |
| L1 High-level shared model | Business and architecture | Main subject areas, objects and business links | High-level-to-detailed type mapping | No technology or source detail |
| L2 Models by subject area | Subject experts and data modelers | Local hierarchies, levels of detail and internal links | Stable links between subject areas | Every area has stable links |
| L3 Shared logical graph | Data and graph engineers | Node types, relationship types, fields, number rules, time and link evidence | Source mapping and view rules | Rules and sample paths pass |
| L4 Stored graph | Platform engineers | Labels/classes, relationship storage, indexes, partitions and access strategy | Shared IDs and mapping versions | Load, query, security and scale tests |
| L5 User views | AI, reporting, controls | Current, historical, aggregate, evidence and impact views | `derivedFrom` links to detailed paths | Answers can be rebuilt from evidence |

Every type must have a traceability record across these levels:

```yaml
concept: Code Symbol
domain_model: Implementation
logical_type: CodeSymbol
physical_label: CodeSymbol
source_mappings:
  - parser: tree-sitter-java
  - parser: tree-sitter-javascript
shared_id: repository + fullyQualifiedName
version_id: shared_id + commitSha
rolls_up_to: File -> Module -> Component -> Repository
supports_questions: [CQ-01, CQ-02, CQ-03]
```

## Shared record design

### Node envelope

All graph objects should use a common set of basic fields. Area-specific fields are added only where needed.

| Field | Meaning |
|---|---|
| `sharedId` | Stable graph identity independent of mutable title or URL |
| `type` | Agreed graph object type |
| `sourceSystem` | System of record |
| `sourceId` | Native immutable or most stable source identifier |
| `uri` | Navigable source reference |
| `title` | Human-readable current label |
| `status` | Controlled lifecycle state |
| `ownerRef` | Team/person/agent identity |
| `classification` | Information classification |
| `aclRef` | Source ACL or security reference |
| `validFrom`, `validTo` | Business validity where applicable |
| `observedAt` | When the source state was observed |
| `textRef` | Reference to retrievable content, not duplicated graph text |
| `schemaVersion` | Shared model mapping version |

### Common link record

Relationships are evidence-bearing statements, not anonymous arrows.

| Field | Meaning |
|---|---|
| `sourceId`, `targetId` | Shared IDs of the two linked objects |
| `relationship` | Agreed relationship name |
| `linkOrigin` | `declared`, `derived`, or `suggested` |
| `method` | Source link, parser, coverage tool, rule, or model that created it |
| `evidenceRef` | Link to source event, diff, metadata, coverage, or inference evidence |
| `confidence` | Authoritative or scored confidence appropriate to the tier |
| `validFrom`, `validTo` | When the statement was true |
| `observedAt` | When it was captured or recomputed |
| `createdBy` | Human, service, parser, or model identity |
| `methodVersion` | Rule/parser/model version |
| `approval` | Optional human validation and timestamp |
| `derivedFrom` | IDs of the detailed links used to create a shortcut relationship |

In a labeled property graph these may be relationship fields. Store a link as its own node when the chosen database cannot properly search, secure, version, or connect evidence attached directly to a relationship.

### Trust tiers

| Tier | Definition | Examples | Allowed use |
|---|---|---|---|
| Declared | Explicit authoritative source relationship | Story linked to PR; Story linked to Test Case | Audit, compliance, AI answers |
| Derived | Deterministic machine relationship | PR changes symbol; test covers method | Audit when evidence is retained; AI answers |
| Inferred | Heuristic or model-generated candidate | Legacy Story likely matches design section | Discovery; requires qualification or approval |

An inferred edge must never silently replace a declared or deterministic relationship.

## Fine-grained domain models

### Delivery-intent model

| Node type | Exact level | Internal relationships | Links to other areas |
|---|---|---|---|
| Epic | One strategic initiative | `PARENT_OF` Feature | Design/domain governance |
| Feature | One coherent capability/change | `PARENT_OF` Story | Solution design, component, release |
| Story | Smallest independently understandable change intent | `PARENT_OF` Task; `HAS_CRITERION` | Design link, commit/file/symbol implementation links, Test Case |
| Task | One implementation activity | `CHILD_OF` Story | Cross-links optional |
| AcceptanceCriterion | One testable behavioral condition | `CRITERION_OF` Story | Test Case via `VERIFIED_BY` |

Rules:

- Story is the normal authoritative cross-domain trace unit.
- Task-to-code links are optional because implementation boundaries frequently cross Tasks.
- Delivery hierarchy edges must be acyclic and single-parent where the source process requires a tree.

### Design-knowledge model

| Node type | Exact level | Internal relationships | Links to other areas |
|---|---|---|---|
| DomainArchitecture | One domain-level design scope | `GOVERNS` Solution/Component | Domain, Feature, Component |
| SolutionArchitecture | One end-to-end solution scope | `DECOMPOSES_TO` ComponentDesign | Feature, Story |
| ComponentDesign | One service/application/module design scope | `CONTAINS` Section/Decision | Component, Story |
| DesignSection | One stable, meaningful page section | `SECTION_OF` Design Artifact | Story, Component, Rule |
| Decision | One architectural or design decision | `RECORDED_IN`; `SUPERSEDES` | Component, Story, code impact |
| BusinessRule | One independently referenceable rule | `SPECIFIED_IN`; `SUPERSEDES` | Acceptance Criterion, code, test |

Rules:

- Page identity uses stable source IDs; title and location are mutable properties.
- Promote only meaningful, stable sections to nodes. Paragraphs remain indexed text.
- Scope defines design level; team size does not.

### Implementation and change model

| Node type | Exact level | Identity/version rule | Important relationships |
|---|---|---|---|
| Repository | One source repository | Stable source repository ID | `CONTAINS` Component/Module |
| Component | One deployable or bounded implementation unit | Shared component ID | `CONTAINS`, `DEPENDS_ON`, `OWNED_BY` |
| Module/Package | One logical code container | Repository + path/name | `CONTAINS` File/Symbol |
| File | One repository path at current state | Repository + path | `HAS_VERSION`, `CONTAINS` |
| CodeSymbol | One logical class/interface/function/method | Repository + fully qualified name | `HAS_VERSION`, `CALLS`, `DEPENDS_ON` |
| CodeSymbolVersion | One symbol at one commit | CodeSymbol ID + commit SHA | `CHANGED_BY`, `EVOLVED_TO`, `REMOVED_IN` |
| PullRequest | One reviewed change proposal | Repository + PR ID | `HAS_COMMIT`, `HAS_FINAL_DIFF` |
| Commit | One immutable Git commit | Repository + SHA | `HAS_PARENT_DIFF`, `BUILT_IN` |
| GitDiff | One comparison between base and target commits | Repository + base SHA + target SHA + comparison type | `CONTAINS` FileChange |
| FileChange | One changed path in one GitDiff | GitDiff ID + before/after path | `CONTAINS` SymbolChange |
| SymbolChange | One affected parsed class/function/method/export | FileChange ID + CodeSymbol + before/after range | `AFFECTS` CodeSymbol; `BEFORE_VERSION`, `AFTER_VERSION` |

Rules:

- Do not require developers to annotate methods with Story IDs. Use work-item metadata, diffs, structured change attribution, and review evidence outside normal code comments.
- Do not enforce one-to-one Story/commit relationships. Focused commits are useful evidence, not a universal boundary.
- Do not spread every Story on a PR across every changed file or method. Preserve unresolved attribution at the broadest supported level.
- Preserve PR and commit history; do not overwrite older Story contributions when newer PRs modify the same symbol.
- Deletion is a state transition or tombstone, not erasure.
- Separate the append-only historical graph from the current-state view.

#### Code-level dependency

Model a code dependency as one directed many-to-many relationship:

```text
source CodeSymbol -[DEPENDS_ON]-> target CodeSymbol
```

The direction has two query meanings:

- outbound: follow the relationship forward to find symbols this symbol uses;
- inbound: traverse the same relationship backward to find callers and consumers that use this symbol.

Do not store a second inverse relationship merely to represent inbound use. The graph database can traverse the directed relationship in either direction.

Required dependency fields:

| Field | Meaning |
|---|---|
| `dependencyType` | Calls, imports, extends, implements, uses API, publishes event, subscribes to event, reads data, or writes data |
| `sourceVersionId` | Exact source CodeSymbolVersion used when the dependency was observed |
| `targetVersionId` | Exact target CodeSymbolVersion when it can be resolved |
| `observedAt` | Time the parser or resolver observed the relationship |
| `evidenceRef` | Parser output, source location, build dependency, API definition, or other supporting evidence |
| `method`, `methodVersion` | Parser/resolver name and version |
| `confidence` | Resolution quality, especially for dynamic JavaScript or runtime wiring |
| `validFrom`, `validTo` | Period in which the relationship belongs to the current code view |

`CALLS` is a filtered view of `DEPENDS_ON` where `dependencyType = calls`; do not store both edges for the same observation. Historical impact uses the recorded source and target versions. Current impact uses dependencies whose validity includes the current code snapshot.

### Verification and execution-evidence model

Test level, purpose, implementation, and execution are independent axes.

| Concept | Examples | Modeling choice |
|---|---|---|
| Test level | unit, component, integration, system, end-to-end | Attribute or controlled classification node |
| Test purpose | acceptance, smoke, regression, security, performance | Suite/tag membership, not a containment hierarchy |
| Implementation | manual, automated | Attribute plus optional automation relationship |
| Definition | Test Case, JUnit/Jest test | Stable node |
| Execution | One test in one run/environment/build | Immutable event node |
| Result | pass, fail, skipped, duration, evidence | Execution properties or result node when independently governed |

Recommended relationships:

```text
Story -[VERIFIED_BY]-> TestCase
AcceptanceCriterion -[VERIFIED_BY]-> TestCase
TestCase -[AUTOMATED_BY]-> TestDefinition
TestDefinition -[MEMBER_OF]-> TestSuite
TestDefinition -[EXECUTED_AS]-> TestExecution
TestExecution -[TESTED_BUILD]-> Build
TestExecution -[RAN_IN]-> Environment
TestExecution -[PRODUCED]-> TestResult
TestExecution -[COVERS]-> CodeSymbolVersion
```

Rules:

- Story/Test Case is a lasting link that states what behavior the test is meant to verify.
- Test Execution/Result is time-bound evidence.
- A test does not need to run inside the implementing PR pipeline to verify the Story.
- Smoke and regression are purposes/suites; they are not test levels.
- A retry creates another Test Execution and Test Result; it does not overwrite the earlier attempt.
- Runtime coverage points to the exact CodeSymbolVersion in the tested build. A direct Test Case-to-code link, if shown in a user view, is a calculated summary rather than a maintained source relationship.

The detailed view is in [Story-to-test traceability model](./diagrams/ai-sdlc-test-traceability-model.html). Story-to-Test Case stays many-to-many under both Story-to-commit options: a Story normally needs several Test Cases, and a reusable Test Case may verify behavior shared by several Stories.

### Graph model versus relational loading model

The controlled node, relationship, cardinality and relationship-field definitions are maintained in the [Graph logical data dictionary](./AI-SDLC-graph-logical-data-dictionary.md). The diagrams are readable views of that shared definition.

The diagrams describe the target graph. In that model, records do not need foreign-key fields merely to point to another record. A graph relationship is the link. For example:

```text
source CodeSymbol -[DEPENDS_ON { dependencyType, observedAt, evidenceRef }]-> target CodeSymbol
Story -[VERIFIED_BY { source, reviewState, validFrom, validTo }]-> TestCase
```

If data is first prepared in SQL tables, use foreign keys there. A many-to-many relationship becomes a link table. Examples:

| Relational loading table | Key columns | Relationship fields |
|---|---|---|
| `CodeSymbolDependency` | `sourceCodeSymbolId`, `targetCodeSymbolId`, `sourceVersionId`, `targetVersionId` | `dependencyType`, `observedAt`, `evidenceRef`, `confidence` |
| `StoryTestCase` | `storyId`, `testCaseId` | `source`, `reviewState`, `validFrom`, `validTo` |
| `TestExecutionCoverage` | `executionId`, `symbolVersionId` | covered lines/branches, coverage tool, evidence reference |

Those ID columns should be foreign keys in the relational loading database. The graph loader converts each table row into a graph relationship and its fields. Do not also copy the same relationship into inbound and outbound JSON arrays: that duplicates facts and makes updates inconsistent. JSON may carry graph data between systems, but JSON by itself does not remove the need to define one owner and one direction for each relationship.

The tables above are examples, not a completed physical loading schema. Create the full relational loading design only after confirming that relational staging is required, which graph database and loading format will be used, and whether the staging layer is temporary or historized. The decision gate and required loading deliverables are listed in the graph logical data dictionary.

## Controlled relationship vocabulary

Start small and prefer precise inverse traversal over synonyms.

| Relationship | Meaning | Typical link origin |
|---|---|---|
| `PARENT_OF` | Hierarchical decomposition | Declared/source native |
| `HAS_DESIGN_LINK` | Story has an evidence-bearing design attribution | Declared, derived, or suggested |
| `SPECIFIED_BY` | StoryDesignLink points to the design section/version that specifies the Story | Declared or suggested candidate |
| `DESIGNED_BY` | Change/component is intentionally designed by artifact/section | Declared |
| `IMPLEMENTED_BY_COMMIT` | Commit is the finest supported implementation attribution for a Story | Declared, derived, or suggested |
| `IMPLEMENTED_BY_FILE_CHANGE` | FileChange is the finest supported implementation attribution for a Story | Declared, derived, or suggested |
| `IMPLEMENTED_BY_SYMBOL_CHANGE` | Parsed class/function/method/export change is attributed to a Story | Declared, derived, or suggested |
| `HAS_COMMIT` | PR contains commit | Derived/source native |
| `HAS_PARENT_DIFF` / `HAS_FINAL_DIFF` | Commit or PR has a defined Git comparison | Derived from Git |
| `CONTAINS` | GitDiff contains FileChanges; FileChange contains SymbolChanges | Derived from diff/parser |
| `AFFECTS` | SymbolChange identifies its stable CodeSymbol | Derived from parser |
| `BEFORE_VERSION` / `AFTER_VERSION` | SymbolChange identifies the code version on each side | Derived from diff/parser |
| `CONTAINS` | Structural containment | Derived or authoritative registry |
| `DEPENDS_ON` | Directed code or component dependency; relationship type describes calls/imports/interfaces/APIs/events/data use | Derived or declared |
| `CALLS` | Query/view of `DEPENDS_ON` where dependency type is `calls`, not a duplicate stored edge | Derived view |
| `VERIFIED_BY` | Test is intended to verify behavior | Declared |
| `COVERS` | Test execution exercised code | Derived from coverage |
| `EXECUTED_AS` | Test definition produced an execution | Derived |
| `BUILT_FROM` | Build used a source revision | Derived/source native |
| `SUPERSEDES` | New artifact/decision replaces an older one | Declared; sometimes validated inference |
| `OWNED_BY` | Accountable owner | Declared/registry |
| `GOVERNED_BY` | Policy or architecture governs an object | Declared |

Avoid synonyms such as `coded_by`, `developed_by`, and `realised_by` for the same meaning.

## High-level view rules

### Types of views

| View | Purpose | Example behavior |
|---|---|---|
| Current-state | Answer “what exists now?” | Select nodes/edges valid at the effective time and latest logical versions |
| Historical/evidence | Explain how the system evolved | Retain every PR, commit, symbol version, replacement and removal |
| Delivery aggregate | Summarize implementation/testing by Feature | Traverse Feature -> Stories -> change/test paths |
| Component impact | Show change blast radius | Traverse symbols, callers, dependencies, tests, Stories, and owners |
| Release evidence | Prove readiness at a release snapshot | Bind Story, build, environment, executions, results, and approvals |
| AI retrieval | Supply authorized evidence and text | Use graph traversal to select artifacts, then retrieve permitted content |

### Derived-edge contract

Every stored shortcut link must define:

```yaml
name: FEATURE_IMPLEMENTED_BY_COMPONENT
source_pattern: Feature-PARENT_OF->Story-IMPLEMENTED_BY_SYMBOL_CHANGE->SymbolChange-AFFECTS->CodeSymbol<-CONTAINS-Component
output_relationship: IMPLEMENTED_BY
link_origin: derived
validity_rule: path is valid at the view's effective time
refresh_rule: event-driven plus nightly reconciliation
source_link_ids: retain every detailed link used
security_rule: output visibility is no broader than every required source path
```

Never create a summary relationship that cannot be explained by its detailed path.

### Accumulating versus superseding change

- Accumulating: several Stories contribute to the same current behavior. Retain all contribution paths.
- Superseding: a new component, decision, or symbol explicitly replaces an old one. Add `SUPERSEDES` or `EVOLVED_TO`; do not delete history.
- Removal: close validity and record the removal event/commit. Preserve the removed node version for historical questions.

## Source mapping and ownership

The graph is a stored knowledge and traceability view. Source systems remain authoritative.

| Shared graph information | System of record |
|---|---|
| Feature, Story, Task, status | Azure Boards |
| PR, commit, file change, build | Azure Repos/Pipelines |
| Design content and section anchors | Confluence |
| Code structure and calls | Git plus parsers/language tooling |
| Test definition | Test repository/Test Plans |
| Test execution and result | Pipeline/test platform |
| Ownership | Agreed service/component registry or authoritative team source |
| Relationship origin and evidence | Shared graph link/evidence store |

The ingestion layer should normalize identities and events. The graph should not become a second workflow UI where users maintain duplicate titles, statuses, or test results.

## Validation rules

### Structural constraints

- shared IDs are unique within type;
- a source-system identity maps to at most one active shared identity unless an explicit merge/split record exists;
- delivery parent relationships are acyclic;
- containment relationships do not cross incompatible containers;
- relationship endpoints follow the allowed source-type and target-type rules;
- current logical identity resolves to zero or one current version;
- deleted versions remain queryable historically.

### Evidence and governance constraints

- every derived edge has evidence and method version;
- every inferred edge has confidence, model/rule identity, and qualification in AI output;
- a declared edge cannot be overwritten by a lower-trust edge;
- high-level links retain `derivedFrom` paths back to the detailed links;
- ACL/classification is enforced before graph context or text is returned to an AI model;
- freshness is visible for every source area and view.

### Query acceptance tests

Use business questions as executable model tests. A model update is complete only when representative queries return:

1. the correct objects;
2. the complete evidence path;
3. the appropriate current or historical state;
4. link origin and freshness;
5. only information the requesting identity may access.

### Coverage metrics

Measure useful coverage rather than total nodes or edges:

- active Stories with a Feature parent;
- production PRs with a linked work item;
- Stories with an accepted or clearly qualified StoryDesignLink, or an explicit exemption;
- Stories with accepted implementation links at commit, file change, or symbol change level;
- multi-Story PRs with accepted fine-code allocation, unresolved attribution, or an approved exception;
- Stories/criteria with acceptance or system tests;
- PRs with parsed changed symbols;
- tests with identifiable component and execution evidence;
- active components with owner and governing design;
- orphan design sections and active modules;
- declared versus derived versus inferred edge proportions;
- stale links and views;
- AI answers with authoritative citations and complete evidence paths.

## Component-model specification template

Use this template for every component and level model.

```yaml
model_name: <domain/component/level>
business_purpose: <decisions enabled>
business_questions: [<CQ IDs>]

nodes:
  - type: <shared type>
    exact_level: <exactly one ...>
    shared_id: <rule>
    lifecycle: <created/changed/closed/deleted>
    versioning: <logical and immutable identity>
    source_of_record: <system>
    required_properties: []

relationships:
  - relationship: <agreed verb>
    source_type: <type>
    target_type: <type>
    cardinality: <0..1, 1..N, N..M>
    link_origins_allowed: [declared, derived, suggested]
    temporal_rule: <validity behavior>
    evidence_rule: <required evidence>

cross_domain_anchors:
  - <stable identity and relationship>

rollups:
  - view: <name>
    source_path: <detailed graph path>
    path_back_required: true

security:
  acl_source: <system/rule>
  inheritance: <rule>

quality_rules:
  - <constraint>

sample_instances:
  - <positive, historical, deletion, and ambiguous examples>
```

## Worked vertical slice

Use one thin end-to-end slice before expanding the model:

```text
Feature F-8420
  -> Story US-8421
     -> StoryDesignLink SDL-208
        -> DesignSectionVersion CONFL-431200#eligibility-rules@v17
     -> IMPLEMENTED_BY_SYMBOL_CHANGE SC-617-08
        -> SymbolChange calculateLimit modified
           -> FileChange src/cards/LimitService.java
           -> GitDiff base456..abc123
           -> Commit abc123
           -> PullRequest PR-617
           -> AFFECTS CodeSymbol calculateLimit
     -> TestCase SYS-9017
        -> TestExecution run-2831
           -> TestResult PASS
        -> COVERS calculateLimit@abc123
```

Acceptance tests for the slice:

- traverse forward from Feature to the attributed code change, current component, and code;
- traverse backward from code to the Stories and design that explain it;
- show the exact evidence and review state for Story-to-design and Story-to-code relationships;
- keep an ambiguous multi-Story PR at PR/commit level until a finer allocation is supported;
- show that the Test Case verifies the Story independently of the PR pipeline;
- distinguish test intent from a particular PASS result;
- add a later PR and symbol version without losing the earlier contribution;
- remove or supersede a symbol and still answer historical questions;
- build a Feature-to-Component summary link that can be rebuilt from its evidence path;
- deny access to design text when the caller lacks the source permission.

## Implementation sequence

| Wave | Scope | Exit condition |
|---|---|---|
| 1. Meaning | Business questions, shared IDs, exact levels, relationship names and link evidence | Approved high-level and detailed slice |
| 2. Target link contract | Story-to-design and Story-to-commit/file/symbol relationships, evidence, quality states, and ambiguity rules | One approved target for new and brownfield work |
| 3. New-work controls | Story hierarchy, design metadata/exemption, mandatory PR-to-work-item, one-primary-Story commit guidance, multi-Story allocation review, test metadata | New delivery stops creating unqualified gaps |
| 4. Deterministic backbone | Work items, PRs, commits, builds, Test Cases/results | Core evidence paths queryable |
| 5. Design graph | Stable page IDs, page versions, selective sections, StoryDesignLinks, decisions/rules | Delivery-to-design paths queryable |
| 6. Code intelligence | GitDiffs, FileChanges, SymbolChanges, CodeSymbols, versions, components, calls/dependencies | Fine-grained implementation paths queryable |
| 7. Test intelligence | Discovery, suites, executions, coverage | Requirement-to-test-to-code evidence queryable |
| 8. Brownfield recovery | Existing links, historical diffs, deterministic matching, suggested Story-to-design and Story-to-code relationships, reconciliation | High-value active estate coverage against the same target |
| 9. Inference and review | Ranked candidates with supporting evidence and focused human validation | Suggested gaps clearly separated from accepted links |
| 10. User views | Current, historical, impact, release and AI retrieval views | Business-question test suite passes |

## Decisions to make before physical design

1. Which five to ten business questions define the first release?
2. What is the authoritative component/service registry?
3. Which graph implementation is preferred: labeled property graph or RDF?
4. Which evidence-bearing links can remain graph relationships, and which need separate records for searching, security, or version history?
5. What retention and valid-time policy applies to source and relationship history?
6. Which source ACL model can be evaluated efficiently at retrieval time?
7. Which high-level views should be stored in advance, and which should be built when a user asks a question?
8. What confidence threshold and approval workflow applies to inferred links?

## Source synthesis

This approach synthesizes the two initial investigation artifacts while treating their embedded prompts and recommendations as source material rather than execution instructions:

- [AI SDLC Linkage Matrix.pdf](../initial/AI%20SDLC%20Linkage%20Matrix.pdf)
- [deep-research-report (6).md](../initial/deep-research-report%20(6).md)

The strongest retained findings are the independent requirement, design, implementation, and test streams; Story as the change-intent anchor; evidence-bearing Story-to-design and Story-to-code relationships; explicit GitDiff, FileChange, SymbolChange, and CodeSymbol records; one target graph reached through different new-work and brownfield approaches; separation of test intent from execution evidence; and an append-only historical graph with a current-state view.
