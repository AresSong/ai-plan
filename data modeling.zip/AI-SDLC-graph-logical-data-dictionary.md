# AI SDLC graph logical data dictionary

## Purpose

This is the shared logical definition of the target knowledge graph. It defines node types, directed relationships, cardinality and relationship fields without choosing a graph database or a relational loading design.

Use it with the detailed diagrams. The diagrams are readable views; this dictionary is the fuller control list used to check that the views remain consistent.

Related views:

- [Modeling approach](./AI-SDLC-graph-data-modeling-approach.md)
- [Connected system overview](./diagrams/ai-sdlc-connected-logical-graph.html)
- [Flexible Story-to-code model](./diagrams/ai-sdlc-target-graph-data-model.html)
- [Strict Story 1:1 Commit model](./diagrams/ai-sdlc-story-commit-1-to-1-er.html)
- [Confluence design model](./diagrams/ai-sdlc-confluence-design-model.html)
- [Test traceability model](./diagrams/ai-sdlc-test-traceability-model.html)
- [Whole-solution code structure model](./diagrams/ai-sdlc-solution-code-structure-model.html)

## Modeling rules

1. A node holds the facts that describe that object.
2. A relationship connects two nodes. Do not add a foreign-key field to a node merely to represent that connection.
3. A source-native value such as a commit SHA, page ID or pipeline run ID may remain a property when it is evidence or part of the object's source identity. It does not replace the graph relationship.
4. Store one direction for each relationship. Queries may traverse it forward or backward.
5. Put origin, evidence, confidence, review and time on the relationship when they describe the link rather than either endpoint.
6. Keep historical nodes and relationships. Build current-state views from validity and replacement relationships.
7. A suggested relationship is not silently promoted to a trusted relationship.

## Common node fields

Every node should support the following shared fields where applicable.

| Field | Meaning |
|---|---|
| `id` | Stable graph identity for the node |
| `nodeType` | Agreed node type |
| `sourceSystem` | Azure Boards, Confluence, Azure Repos, pipeline, test platform or registry |
| `sourceKey` | Source-native stable identity, qualified by source system and project where needed |
| `sourceUrl` | Link back to the source record |
| `observedAt` | Time the source state was captured |
| `validFrom`, `validTo` | Business validity when the object changes by replacement rather than event history |
| `schemaVersion` | Mapping version used to create the node |
| `classification` | Information classification when access control requires it |

## Node dictionary

Properties below exclude relationships. Fields marked “working” need SME confirmation.

### Delivery intent

| Node | Meaning and grain | Main properties | Source |
|---|---|---|---|
| `Feature` | One grouped business change or outcome | title, state, priority | Azure Boards |
| `Story` | One implementable business need | title, state, workItemType, areaPath | Azure Boards |
| `AcceptanceCriterion` | One testable condition belonging to a Story | statement, priority, state | Azure Boards |

### Design knowledge

| Node | Meaning and grain | Main properties | Source |
|---|---|---|---|
| `ConfluencePage` | Stable identity of one page | spaceKey, title, url | Confluence |
| `PageVersion` | One saved version of a page | versionNumber, createdAt, contentHash | Confluence |
| `DesignSectionVersion` | One meaningful section in one page version | sectionAnchor, heading, contentHash, capturedAt | Confluence plus extraction |
| `Decision` | One stated design choice | decisionText, status, decidedAt | Confluence plus extraction |
| `BusinessRule` | One lasting business rule | ruleText, status, effective dates | Confluence plus extraction |

### Solution and source structure

| Node | Meaning and grain | Main properties | Source |
|---|---|---|---|
| `Domain` | One business or technology domain | name, lifecycleState | Architecture registry, working |
| `Solution` | One business solution boundary | name, solutionType, lifecycleState | Architecture registry, working |
| `Component` | One stable deployable or logical implementation unit | name, componentType, lifecycleState | Architecture registry, working |
| `Repository` | One Azure Repos repository | name, provider, defaultBranch | Azure Repos |
| `Module` | One Java module/package or JavaScript/TypeScript package boundary | name, path, language | Repository scan and parser |
| `File` | One stable source path identity inside a repository | path, language, fileKind | Git and parser |
| `CodeSymbol` | One stable class, interface, method, function or export identity | language, qualifiedName, signature, symbolKind | Parser |
| `CodeSymbolVersion` | One CodeSymbol at one commit or source snapshot | contentHash, sourceRange, createdAt | Git and parser |

### Change evidence

| Node | Meaning and grain | Main properties | Source |
|---|---|---|---|
| `PullRequest` | One review and merge context | pullRequestKey, provider, mergeStrategy, completionSha | Azure Repos |
| `Commit` | One immutable source commit | commitSha, parentSha, authorDate, message | Git |
| `GitDiff` | One defined comparison between source revisions | diffKey, comparisonType, createdAt | Git extraction |
| `FileChange` | One file delta in one GitDiff | beforePath, afterPath, changeType | Git extraction |
| `SymbolChange` | One parsed CodeSymbol change caused by changed source ranges | changeType, beforeRange, afterRange, parserVersion | Parser |

### Test and execution evidence

| Node | Meaning and grain | Main properties | Source |
|---|---|---|---|
| `TestCase` | One lasting intended behavior check | title, testLevel, automationState | Test management source |
| `TestDefinition` | One executable JUnit, Jest or similar test identity | framework, stableName, sourcePath, testKind | Repository and parser |
| `TestSuite` | One reusable test grouping or purpose | name, purpose | Test platform or metadata |
| `TestExecution` | One attempt to run one TestDefinition against one build and environment | startedAt, attemptNumber, runner, executionMode | Pipeline or test platform |
| `TestResult` | One outcome from one TestExecution | outcome, durationMs, evidenceUrl | Test platform |
| `Build` | One immutable build output or pipeline snapshot | buildKey, buildNumber, completedAt, status | Pipeline |
| `Environment` | One named execution or deployment environment | name, environmentType, classification | Pipeline or environment registry |

### Ownership and release

| Node | Meaning and grain | Main properties | Source |
|---|---|---|---|
| `Team` | One accountable team | name, status | Organization registry |
| `Person` | One human identity when individual responsibility is required | displayName, status | Identity source |
| `Release` | One releasable or released version | version, state, releasedAt | Release platform, working |

## Directed relationship dictionary

Cardinality is written from source to target. `1:N` means one source may connect to many targets. Optionality should be confirmed with the SME and enforced only when the source process can supply the link.

### Delivery and design

| Source | Relationship | Target | Cardinality | Relationship-specific fields | Creation method |
|---|---|---|---|---|---|
| Feature | `HAS_STORY` | Story | 1:N | order | Source-native |
| Story | `HAS_CRITERION` | AcceptanceCriterion | 1:N | order | Source-native |
| Story | `EVIDENCED_BY_DESIGN` | DesignSectionVersion | N:N | reviewState, contributionType | Declared, derived or suggested |
| ConfluencePage | `HAS_VERSION` | PageVersion | 1:N | none | Source-native |
| PageVersion | `HAS_SECTION` | DesignSectionVersion | 1:N | order, sectionPath | Derived |
| DesignSectionVersion | `STATES_DECISION` | Decision | 1:N | extractionMethod | Declared or derived |
| DesignSectionVersion | `STATES_RULE` | BusinessRule | 1:N | extractionMethod | Declared or derived |
| Decision | `SUPERSEDES` | Decision | N:0..1 | reason | Declared or accepted inference |
| BusinessRule | `SUPERSEDES` | BusinessRule | N:0..1 | reason | Declared or accepted inference |
| DesignSectionVersion | `DESCRIBES` | Component | N:N | contributionType | Declared, derived or suggested |

### Story, Git and code

| Source | Relationship | Target | Cardinality | Relationship-specific fields | Creation method |
|---|---|---|---|---|---|
| Story | `IMPLEMENTED_BY_COMMIT` | Commit | Flexible N:N; strict 0..1:1 | role, attributionState | Declared or derived |
| Story | `IMPLEMENTED_BY_FILE_CHANGE` | FileChange | N:N | role, attributionState | Declared, derived or suggested fallback |
| Story | `IMPLEMENTED_BY_SYMBOL_CHANGE` | SymbolChange | N:N | role, contributionType, attributionState | Declared, derived or suggested |
| PullRequest | `HAS_COMMIT` | Commit | 1:N | commitOrder | Source-native |
| PullRequest | `IN_REPOSITORY` | Repository | N:1 | none | Source-native |
| Commit | `IN_REPOSITORY` | Repository | N:1 | none | Source-native |
| Commit | `HAS_PARENT_DIFF` | GitDiff | 1:1 for normal source commits | baseSelectionRule | Derived |
| GitDiff | `CONTAINS_FILE_CHANGE` | FileChange | 1:N | order | Derived |
| FileChange | `CONTAINS_SYMBOL_CHANGE` | SymbolChange | 1:N | changedRanges | Derived |
| SymbolChange | `AFFECTS` | CodeSymbol | N:1 | matchMethod | Derived |
| SymbolChange | `BEFORE_VERSION` | CodeSymbolVersion | N:0..1 | none | Derived |
| SymbolChange | `AFTER_VERSION` | CodeSymbolVersion | N:0..1 | none | Derived |
| CodeSymbolVersion | `VERSION_OF` | CodeSymbol | N:1 | none | Derived |
| CodeSymbolVersion | `OBSERVED_IN` | Commit | N:1 | extractionMethod | Derived |

### Whole-solution structure and dependency

| Source | Relationship | Target | Cardinality | Relationship-specific fields | Creation method |
|---|---|---|---|---|---|
| Solution | `IN_DOMAIN` | Domain | N:1 | none | Registry |
| Component | `PART_OF` | Solution | N:1 | validFrom, validTo | Registry |
| Component | `OWNED_BY` | Team | N:1 | responsibilityType | Registry |
| Solution | `OWNED_BY` | Team | N:1 | responsibilityType | Registry |
| Component | `USES_REPOSITORY` | Repository | N:N | contributionType, pathScope | Registry or accepted derivation |
| Module | `IN_REPOSITORY` | Repository | N:1 | none | Derived |
| File | `IN_MODULE` | Module | N:1 | none | Derived |
| CodeSymbol | `DECLARED_IN` | File | N:1 | none | Derived |
| CodeSymbol | `IN_MODULE` | Module | N:1 | derivedFrom | Calculated shortcut through File |
| CodeSymbol | `MEMBER_OF` | Component | N:1 at a point in time | validFrom, validTo, mappingMethod | Registry or accepted derivation |
| CodeSymbol | `DEPENDS_ON` | CodeSymbol | N:N directed | dependencyType, sourceVersion, targetVersion | Parser or declared contract |
| Component | `DEPENDS_ON` | Component | N:N directed | dependencyType, evidenceMode | Calculated view or declared contract |

### Test, execution and coverage

| Source | Relationship | Target | Cardinality | Relationship-specific fields | Creation method |
|---|---|---|---|---|---|
| Story | `VERIFIED_BY` | TestCase | N:N | reviewState, testPurpose | Declared |
| AcceptanceCriterion | `VERIFIED_BY` | TestCase | N:N | reviewState | Declared |
| TestCase | `AUTOMATED_BY` | TestDefinition | N:N | automationRole | Declared or derived |
| TestDefinition | `DECLARED_AS` | CodeSymbol | N:1 | none | Parser |
| TestDefinition | `IN_REPOSITORY` | Repository | N:1 | none | Parser |
| TestDefinition | `MEMBER_OF` | TestSuite | N:N | purpose | Source-native or metadata |
| TestDefinition | `EXECUTED_AS` | TestExecution | 1:N | none | Source-native |
| TestExecution | `TESTED_BUILD` | Build | N:1 | none | Source-native |
| TestExecution | `RAN_IN` | Environment | N:1 | configurationHash | Source-native |
| TestExecution | `PRODUCED` | TestResult | 1:1 | none | Source-native |
| TestExecution | `COVERS` | CodeSymbolVersion | N:N | coveredLines, coveredBranches, toolName | Coverage tool |
| Build | `BUILT_FROM` | Commit | N:N for multi-repository builds | repositoryRole | Pipeline and source evidence |
| Release | `INCLUDES_BUILD` | Build | 1:N | buildRole | Release platform |

## Common relationship fields

Use the smallest subset needed by the relationship. Do not add empty fields merely to make every relationship look the same.

| Field | Meaning |
|---|---|
| `linkOrigin` | `declared`, `derived` or `suggested` |
| `method` | Source link, parser, coverage tool, rule or model that created the relationship |
| `methodVersion` | Version of the parser, rule or model |
| `evidenceRef` | Link to the source event, diff, coverage output or review evidence |
| `confidence` | Authoritative state or scored confidence appropriate to the source |
| `reviewState` | suggested, accepted, rejected, conflicting or not-required |
| `reviewedBy`, `reviewedAt` | Human or service validation record |
| `validFrom`, `validTo` | Time period during which the statement was true |
| `observedAt` | Time the relationship was captured or recomputed |
| `derivedFrom` | Detailed relationship IDs used to create a shortcut or summary relationship |

## Foreign-key cleanup rules

The following names may appear in source payloads or relational staging, but should not be used as the logical graph connection.

| Foreign-key-like field | Graph relationship |
|---|---|
| `repositoryId` on PullRequest, Commit, File or TestDefinition | `IN_REPOSITORY` |
| `projectId` on Repository | Keep source project as part of `sourceKey`, or connect to a Project node if Project must be queried independently |
| `domainId` on Solution | `IN_DOMAIN` |
| `solutionId` on Component | `PART_OF` |
| `ownerId` | `OWNED_BY` to Team or Person |
| `beforeVersionId`, `afterVersionId` on SymbolChange | `BEFORE_VERSION`, `AFTER_VERSION` |
| `currentVersionId` on CodeSymbol | Calculate the current version from valid time or latest accepted version; do not store a second pointer |
| `codeSymbolId` on CodeSymbolVersion | `VERSION_OF` |
| `testSymbolId` on TestDefinition | `DECLARED_AS` |
| `environmentId` on TestExecution | `RAN_IN` |
| `pipelineRunId` on Build | Keep as source evidence or source identity, not a foreign key, unless PipelineRun becomes its own node |
| `supersedesId` | `SUPERSEDES` |

## Relational loading decision gate

Do not create the physical relational schema until the following questions are answered.

| Decision question | Why it changes the loading model |
|---|---|
| Will data be staged in SQL, lake tables, event files or loaded directly through graph APIs? | Determines whether tables and foreign keys are needed at all |
| Is the staging area temporary, historized or an operational source? | Determines retention, effective dating and audit fields |
| Which graph database and bulk-loading format will be used? | Determines node and relationship file shape, labels and type handling |
| Will one row represent current state or one observed version? | Determines keys and duplicate handling |
| Where will identity matching and relationship review state be held? | Determines whether link records need their own staging tables |
| Which security boundary applies to Boards, Confluence, code and test evidence? | Determines whether one loading area is allowed |

If relational staging is confirmed, produce a separate loading design containing:

1. One node staging table per node type or per compatible node family.
2. One relationship staging table per relationship type or per compatible relationship family.
3. Primary keys, foreign keys and uniqueness rules.
4. Source-to-stage and stage-to-graph mappings.
5. Incremental loading, deletion, late-arriving data and retry rules.
6. Evidence, confidence, review and valid-time fields on relationship tables.
7. Reconciliation queries proving that every loaded edge resolves to both endpoints.

The relational loading design must not be copied back into the graph logical model.

## SME review checklist

- Confirm node grain and stable source identity.
- Confirm every relationship name and direction.
- Confirm cardinality and optionality based on real delivery practice.
- Confirm which links are declared, derived or only suggested.
- Confirm which relationship fields are required for audit and access control.
- Confirm ownership for Solution, Component, TestCase and Environment identities.
- Confirm whether relational staging is required before physical design begins.
