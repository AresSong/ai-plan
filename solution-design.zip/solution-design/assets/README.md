# Design assets

`source-images/` contains the original screenshot/reference images used during discovery. These files
are preserved as evidence inputs and are not normative specifications.

