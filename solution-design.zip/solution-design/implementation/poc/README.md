# PoC coding handoff

**Status:** proposed implementation specification; no PoC application code exists yet  
**Scope:** Java 17 repositories and selected Confluence pages only

This folder turns the v5 solution design into instructions that a coding agent can execute and test
without access to institutional data. The design deliberately uses a **modular monolith**, not eight
microservices: component boundaries are Python packages, versioned contracts and separate stores.
They can be extracted later without changing the contracts.

Read in this order:

1. [implementation-plan.md](implementation-plan.md) — assumptions, repository layout and gated build order.
2. [contracts.md](contracts.md) — exact ports, normalized records and error rules.
3. [architecture.md](architecture.md) — module and storage boundaries.
4. [flows.md](flows.md) — ingest, link, review and stale-evidence sequences.
5. [variables.md](variables.md) — the only place real-environment values enter.
6. [permissions.md](permissions.md) — PoC identity, access and secret handling.
7. [automation.md](automation.md) — OpenKB/LLM execution controls.
8. [tests.md](tests.md) — fixture packs, test cases and release gates.

The authoritative enterprise semantics remain in
[the v1 contract](../../contracts/v1/README.md). If this coding handoff conflicts with
that contract, the v1 contract wins. Tool-native fields must remain inside adapters.

## Definition of done for the coding handoff

The implementing agent must not claim live integration when a fixture is in use. A completed PoC
must expose provider status on every view and pass the cold-start verification in `tests.md` with:

- code only;
- document only;
- linked code and document;
- ambiguous link;
- unavailable source;
- manual decision and export; and
- changed evidence causing a stale decision.
