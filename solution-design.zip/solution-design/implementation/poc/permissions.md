# PoC permissions and trust boundaries

**Status:** proposed PoC controls; not production authorization

## Roles

| Role | Read evidence | Run ingest | Decide knowledge | Export |
|---|---:|---:|---:|---:|
| `viewer` | Yes | No | No | Yes |
| `reviewer` | Yes | No | Yes, item-level | Yes |
| `operator` | Yes | Yes | No unless separately assigned reviewer | Yes |

The manual UI asks for reviewer ID, display name and actual role. It labels the assignment
`PROVISIONAL_MOST_RELATED_ROLE`. Blank identity is never allowed for a decision. This is audit
capture, not authentication; the UI must show that limitation on every review/export screen.

## Trust boundaries

- Bind the BGA and OpenKB services to `127.0.0.1` only.
- Confluence and Git adapters are read-only. The PoC never edits source pages or repositories.
- OpenKB receives only explicitly scoped, approved/synthetic normalized pages.
- Subprocesses get a minimal environment and explicit argument list; never use `shell=True`.
- Validate and sanitise all Markdown/HTML before browser rendering.
- Store tokens outside configuration and artifacts. Redact authorization headers and model prompts
  containing source text from normal logs.
- Validate artifact paths before reads/writes; reject traversal and symbolic-link escape.

## Production gaps

Formal SSO, RBAC enforcement, segregation of duties, electronic signatures, retention/legal hold,
central audit, encryption/key management and institutional approval are not implemented. Therefore a
PoC knowledge decision is not a formal approval and never becomes a release decision.

