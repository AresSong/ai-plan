# PoC implementation architecture

**Status:** proposed; the repository currently contains design documents and reference tools, not the application

## Architecture decision

Use one local FastAPI application as a composition root while preserving logical component contracts.
This is the smallest realistic implementation for ten days and delayed infrastructure. Independence
comes from ports, fixtures, ownership and stores—not from premature network deployment.

Each feature package must expose a component-only test profile and accept fixture implementations for
all inbound dependencies. The combined application imports public service/port modules only. It may
not import another component's adapter, SQL repository or private model. This is the enforceable PoC
meaning of “built and validated separately.”

| Module | v5 component | Owns | May call |
|---|---|---|---|
| `code` | C1 | Grafel artifacts and normalized code graph | Grafel process, Git read-only |
| `documents` | C2 | Confluence snapshots, spans and compiled candidates | Confluence REST, OpenKB REST |
| `ekg` | C6 | canonical entities, evidence and cross-domain edges | no provider stores |
| `linker` | C7 | link computation and explanation | C1/C2 read ports, C6 proposal port |
| `governance` | C3 | review packets, decisions, history, outbox | C6 status-projection port |
| `review` | C8 | HTTP/session/view composition only | component service ports |
| `reporting` | C5 | run ledger, partial report and export rendering | read ports only |

## Dependency rules

- `common` depends on no feature module.
- Feature modules may depend on `common` contracts, never another module's adapter or repository.
- The composition root wires ports to implementations.
- `review` and `reporting` have no SQL connection.
- C7 can propose; only C3 records decisions; only C6 owns canonical cross-domain edges.
- External tools are replaceable leaf adapters. Their native schemas never cross the module boundary.

## Data ownership

```text
data/
  artifacts/<analysis-id>/...      immutable source/tool snapshots
  code.db                          optional C1 private normalized index
  ekg.db                           C6 only
  governance.db                    C3 only
  exports/<review-packet>/...      regenerated from frozen reads
```

SQLite is an implementation choice, not the enterprise contract. Each DB has its own migrations and
repository. Cross-store consistency uses idempotent operations and a governance outbox; there is no
distributed transaction. Exports are derived artifacts, not systems of record.

## Related diagrams and documents

- [C4 system context](../../architecture/diagrams/c4-context.md)
- [C4 containers](../../architecture/diagrams/c4-containers.md)
- [PoC component diagram](../../architecture/diagrams/c4-components-poc.md)
- [Manual approval dynamic view](../../architecture/diagrams/c4-dynamic-manual-approval.md)
- [Runtime flows](flows.md)
- [Contracts](contracts.md)
- [Permissions](permissions.md)
- [Variables](variables.md)
- [Tests](tests.md)
- [Automation controls](automation.md)
