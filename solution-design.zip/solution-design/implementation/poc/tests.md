# PoC verification plan

**Status:** proposed tests; existing application coverage is **none** because implementation has not started

## Test strategy

Tests are layered so every component runs without live dependencies:

| Layer | Purpose | Dependencies |
|---|---|---|
| Unit | hashing, URNs, normalization, matching, SQL repositories | none/live services forbidden |
| Contract | every port and canonical JSON Schema | fixture adapters |
| Adapter | native Grafel/OpenKB/Confluence samples to canonical records | checked-in redacted samples/mocked HTTP |
| Integration | module plus its own SQLite/artifacts | temporary directory |
| E2E | three inspection views, decision and export | all fixtures first; one live gold run later |

## Required fixture packs

- `code`: Java 17 before/after source, Git diff, valid Grafel schema-1 JSON, partial graph, bad schema,
  wrong SHA and missing edge endpoint.
- `confluence`: raw fixture with headings/table/macro, normalized Markdown, span index, second version,
  missing page and sanitisation payload.
- `openkb`: `/meta`, `/init`, `/add`, `/status`, `/list`, `/page` responses; valid cited candidate,
  hallucinated/no-span candidate and partial failure.
- `linker`: at least five true pairs, three plausible false pairs, two ambiguous pairs and one conflict.
- `governance`: all four decisions, repeated idempotency key, evidence-hash conflict and superseding decision.

Fixture filenames include contract/native schema version. No real institutional source is committed.

## Mandatory cases

### Contracts and configuration

- Reject missing version, blank IDs, non-UTC timestamp, invalid hash, unknown enum and unknown major version.
- Reject credential values in YAML; accept only environment-variable names.
- Produce identical canonical JSON/hash regardless of dictionary insertion order.

### Code

- Normalize Grafel entity/edge and resolve source evidence at the requested SHA.
- Reject graph schema other than 1, SHA mismatch, absolute/escaping path, invalid line range and dangling edge.
- A process timeout is `UNAVAILABLE`, not an empty `AVAILABLE` graph.
- Code-only inspection and partial report work with every document dependency offline.

### Documents

- The same raw page/version normalizes byte-identically twice.
- Every span round-trips to the expected Markdown substring and hash.
- Unsupported macro marker and HTML sanitisation are visible and safe.
- OpenKB candidates without a resolvable original span do not enter C6/review.
- Document-only inspection works with Grafel and Git offline.

### Linker

- Deterministic tiers run before semantic scoring.
- Negative pairs do not link; close alternatives remain `AMBIGUOUS`.
- Semantic-disabled output is stable and no model call occurs.
- Linker failure leaves existing C6 graph readable.

### EKG and governance

- Process restart retains nodes, edges, evidence, packets and decisions.
- Traversal enforces predicate, depth and node limits.
- C7 cannot write decisions and C8 cannot write either DB directly.
- Decision is append-only, item-level and idempotent.
- Changed commit/page/evidence hash retains the old decision and projects `STALE`.
- Governance outbox replay is idempotent.

### UI and export

- Code, document and linked views show source versions, evidence, provider status and limitations.
- Linked view shows both evidence sides, mechanism, confidence and alternatives.
- Rationale is required for qualification, rejection and clarification.
- Evidence change after page load yields `409 STALE_WRITE` and no decision.
- Markdown and JSON exports contain identical item/evidence/decision IDs and content hashes.
- Same frozen packet yields byte-identical canonical JSON and semantically stable Markdown.
- Manual/non-formal and non-release-approval notices are visible.

## Verification commands to implement

`scripts/verify-poc.ps1` must run, in order, without network by default:

```text
python -m pytest tests/unit tests/contract tests/integration
python -m pytest tests/e2e -m fixture
python -m bga verify-fixtures
python -m bga export --packet <fixture-packet> --verify
```

A separate explicitly enabled `-m live` suite performs capability checks and the selected gold slice.
It must skip with an honest reason when access is absent. The final report lists fixture and live pass
counts separately.

## Human acceptance

A person unfamiliar with the build receives only the manifest, start command and local URL. They must
find a code entity, a document claim and their link; inspect exact evidence; identify an ambiguous
link; record one decision; and export the pack. Record time, confusion and any hidden operator step.

The PoC passes only if automated gates pass and the cold reviewer completes this path without direct
database or artifact edits.

