# PoC implementation contracts

**Status:** normative for the PoC implementation, subordinate to the enterprise v1 contract

## 1. Contract rules

- Canonical records are Pydantic models and JSON Schema generated from the same models.
- `contract_version` is exactly `v1`; unknown major versions fail with `CONTRACT_INCOMPATIBLE`.
- Required strings are non-blank. Timestamps contain a timezone. Hashes use `sha256:<64 lowercase hex>`.
- Mutations require `idempotency_key`; retries return the original result.
- Unknown provider fields are ignored only at a tool adapter. Unknown canonical fields are rejected.
- A provider result always contains `provider_status`. Empty data and provider failure are different.

## 2. Ports

```python
class CodeGraphSource(Protocol):
    def check(self, context: AnalysisContext) -> ProviderStatus: ...
    def build(self, context: AnalysisContext, repository: RepositoryInput) -> CodeGraphSnapshot: ...

class DocumentSource(Protocol):
    def check(self, context: AnalysisContext) -> ProviderStatus: ...
    def fetch(self, context: AnalysisContext, page: ConfluencePageInput) -> DocumentSnapshot: ...

class DocumentCompiler(Protocol):
    def check(self, context: AnalysisContext) -> ProviderStatus: ...
    def compile(self, context: AnalysisContext, snapshot: DocumentSnapshot) -> list[KnowledgeCandidate]: ...

class CandidateLinker(Protocol):
    def link(self, context: AnalysisContext, code: list[CodeAnchor],
             documents: list[KnowledgeCandidate]) -> list[LinkCandidate]: ...

class GraphRepository(Protocol):
    def propose(self, context: AnalysisContext, proposal: SubgraphProposal) -> ProposalResult: ...
    def query(self, context: AnalysisContext, query: SubgraphQuery) -> Subgraph: ...

class GovernanceRepository(Protocol):
    def create_packet(self, request: CreatePacket) -> ReviewPacket: ...
    def record_decision(self, request: RecordDecision) -> Decision: ...
```

No implementation method accepts a Grafel, OpenKB or Confluence SDK object beyond its adapter.

## 3. Source inputs

`RepositoryInput` requires `repo_id`, absolute `local_path`, full `base_revision`, full
`head_revision`, `source_roots`, `include_globs`, and `exclude_globs`.

`ConfluencePageInput` requires `site_id`, `page_id`, exact integer `version`, `source_mode`, and
optional `fixture_path`. `source_mode` is `fixture` or `rest`.

## 4. Normalized code snapshot

```json
{
  "snapshot_urn": "urn:code-snapshot:payments-service:8f41c2a...",
  "contract_version": "v1",
  "repository_urn": "urn:repo:payments-service",
  "revision": "8f41c2a...full-sha",
  "backend": {"name":"grafel-json","version":"<pinned>","schema_version":"1"},
  "coverage": "FULL",
  "entities": [{
    "entity_urn":"urn:code:payments-service:java:method:com.bank.SettlementValidator.validate",
    "provider_ref":"grafel:<native-id>",
    "kind":"METHOD",
    "qualified_name":"com.bank.SettlementValidator.validate",
    "signature":"validate(Payment)",
    "path":"src/main/java/com/bank/SettlementValidator.java",
    "start_line":84,
    "end_line":101,
    "evidence_ref":"urn:evidence:<uuid>"
  }],
  "edges": [{
    "from_urn":"urn:code:...",
    "predicate":"CALLS",
    "to_urn":"urn:code:...",
    "provider_ref":"grafel:<native-edge-id>",
    "confidence":1.0
  }],
  "provider_status": {"provider":"C1_GRAFEL","state":"AVAILABLE","mode":"LIVE","warnings":[]}
}
```

`coverage` is `FULL` or `PARTIAL`. `mode` is `LIVE` or `FIXTURE`. A working-tree snapshot whose
`indexed_sha` differs from the requested revision is rejected with `SOURCE_VERSION_MISMATCH`.

## 5. Normalized document snapshot

```json
{
  "snapshot_urn":"urn:confluence:design:page:12345:v:17",
  "contract_version":"v1",
  "site_id":"design",
  "page_id":"12345",
  "version":17,
  "title":"Settlement validation",
  "source_url":"https://<approved-site>/pages/12345",
  "retrieved_at":"2026-08-25T00:00:00Z",
  "raw_artifact":"confluence/design/12345/17/raw.json",
  "normalized_artifact":"confluence/design/12345/17/page.md",
  "content_hash":"sha256:<hex>",
  "spans":[{
    "span_id":"h-blocking-rules-1-p-2",
    "heading_path":["Settlement validation","Blocking rules"],
    "start_char":418,
    "end_char":536,
    "content_hash":"sha256:<hex>"
  }],
  "provider_status":{"provider":"C2_CONFLUENCE","state":"AVAILABLE","mode":"LIVE","warnings":[]}
}
```

Offsets index Python Unicode strings in the normalized Markdown and use a half-open interval
`[start_char,end_char)`. Span IDs need only be stable within the immutable page version.

## 6. Candidate knowledge and links

```json
{
  "candidate_urn":"urn:candidate:entity:<uuid>",
  "version":1,
  "candidate_type":"BEHAVIOR",
  "label":"Block non-STP settlement",
  "statement":"A non-STP settlement is blocked before submission.",
  "source_snapshot_urn":"urn:confluence:design:page:12345:v:17",
  "evidence_refs":["urn:evidence:<document-span>"],
  "compiler":{"name":"openkb-rest","version":"<pinned>","model":"<model>","prompt_version":"openkb:<pinned>"},
  "candidate_hash":"sha256:<canonical-json-hash>"
}
```

```json
{
  "edge_urn":"urn:candidate:edge:<uuid>",
  "version":1,
  "subject_urn":"urn:candidate:entity:<uuid>",
  "predicate":"DESCRIBES",
  "object_urn":"urn:code:payments-service:java:method:com.bank.SettlementValidator.validate",
  "mechanism":"EXPLICIT_SYMBOL",
  "confidence":1.0,
  "resolution_state":"RESOLVED",
  "alternatives":[],
  "features":[{"name":"qualified_symbol","value":"SettlementValidator.validate"}],
  "evidence_refs":["urn:evidence:<document-span>","urn:evidence:<code-span>"],
  "ruleset_version":"deterministic-v1",
  "candidate_hash":"sha256:<canonical-json-hash>"
}
```

Allowed mechanisms are `EXPLICIT_SYMBOL`, `PATH_OR_MODULE`, `CONTROLLED_ALIAS`,
`SEMANTIC_CANDIDATE`, and combinations recorded as `EXPLICIT_SYMBOL_PLUS_SEMANTIC_CONFIRMATION`.
Semantic-only links remain candidates even at confidence 1.0. If two candidates are within the
configured ambiguity margin, return `AMBIGUOUS` and list both; never choose one silently.

## 7. Evidence

Every evidence record contains the enterprise v1 fields plus an optional `excerpt` for display.
Code evidence points to repository, full commit, relative path and inclusive line range. Document
evidence points to site, page ID, version and span ID. The service verifies the stored content hash
before display; a mismatch sets provider `STALE` and disables unqualified approval.

## 8. Review and decision

`ReviewPacket` freezes candidate versions and computes `evidence_set_hash` from sorted evidence URNs,
content hashes and source versions. `RecordDecision` requires:

- packet URN/version and item URN/version;
- the evidence-set hash shown to the reviewer;
- one of `APPROVED`, `APPROVED_WITH_QUALIFICATION`, `REJECTED`, `NEEDS_CLARIFICATION`;
- reviewer ID, display name, actual role, `PROVISIONAL_MOST_RELATED_ROLE` assignment marker;
- rationale for all decisions except unqualified approval;
- idempotency key and UI/contract versions.

A hash/version conflict returns HTTP `409` with code `STALE_WRITE`; it does not append a decision.
Successful decisions are immutable. Correction means a new decision superseding the previous ID.

## 9. Errors and HTTP mapping

| Code | HTTP | Meaning |
|---|---:|---|
| `VALIDATION_ERROR` | 400 | Canonical request is malformed |
| `UNAUTHORIZED_ROLE` | 403 | Local actor lacks the required PoC role |
| `NOT_FOUND` | 404 | Canonical object is absent |
| `STALE_WRITE` | 409 | Candidate/evidence changed after view load |
| `CONTRACT_INCOMPATIBLE` | 422 | Unsupported schema or enum |
| `SOURCE_VERSION_MISMATCH` | 422 | Actual commit/page differs from pinned input |
| `PROVIDER_UNAVAILABLE` | 503 | Expected live tool/source failed |
| `PROVIDER_OUTPUT_INVALID` | 502 | Tool returned an unusable or unsafe shape |

All errors include `code`, safe `message`, `correlation_id`, `provider_status`, and optional structured
`details`. Never return credentials, raw subprocess environment or stack traces to the browser.

