# OpenKB and model automation controls

**Status:** proposed; all generated knowledge remains advisory

## Allowed automation

The application may start/check the pinned OpenKB service, initialize an isolated KB, upload scoped
Markdown, and read generated pages. It may calculate deterministic and semantic link candidates. It
may not edit/delete Confluence, edit code, call OpenKB page-edit/delete/watch endpoints, approve a
candidate, or set a release decision.

## Required controls

- Global kill switch: `linker.semantic_enabled=false` works without code changes.
- Per-run input allow-list: exact repository, commit, page IDs and page versions.
- Network allow-list: Confluence endpoint, loopback OpenKB endpoint and approved model endpoint only.
- Timeout, size and retry caps; at most one retry for an idempotent read and no blind retry of model
  compilation.
- Record OpenKB version, model, endpoint classification, compiler/prompt version, input hashes,
  output hashes, elapsed time and safe error code.
- Validate generated structures before persistence. Do not ask another LLM to repair invalid output.
- Generated claims without an original document span are diagnostic-only.
- Prompt or model changes create new candidate versions and force review; they never rewrite evidence.

## Failure handling

An OpenKB/model timeout marks compilation `UNAVAILABLE` and retains the Confluence snapshot. Partial
OpenKB output is accepted only item by item after schema and span validation. Invalid items are listed
in run limitations. Existing approved knowledge remains queryable but can become stale only through a
new source version/evidence hash, not merely because the model is offline.

