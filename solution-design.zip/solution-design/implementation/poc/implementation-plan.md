# Code and Confluence PoC — detailed implementation plan

**Status:** build-ready proposed plan  
**Target implementer:** coding agent with human review at each gate  
**Time box:** ten staffed days after source readiness

## 1. Decisions and assumptions

These choices remove ambiguity for the first implementation:

- Runtime: Python 3.11, FastAPI, Pydantic v2, Jinja2, built-in `sqlite3`, `httpx`, `pytest`.
- Deployment: one local process with separately testable packages and ports. Do not build eight
  deployables in the PoC.
- Persistence: `ekg.db` and `governance.db` are separate SQLite files; immutable source artifacts are
  files. No module reads another module's tables.
- Code integration: execute a pinned Grafel binary and import its version-1 `graph.json`. Do not bind
  the application to preview MCP tool names.
- Document integration: snapshot Confluence first, normalize it to Markdown plus a span index, then
  send the Markdown to a pinned OpenKB REST service. Do not modify OpenKB.
- Linking: deterministic anchors first; optional semantic scoring only for unresolved candidates.
- UI: server-rendered pages plus small JavaScript. No React build is required.
- Authentication: localhost-only manual identity and provisional role, visibly marked non-formal.
- All dates are UTC ISO-8601. All content hashes are SHA-256 over UTF-8 bytes after the documented
  normalization step.

If the real environment conflicts with one of these assumptions, change the adapter or manifest,
not a canonical contract. A change to a required contract field or enum needs design-owner review.

This choice satisfies independent **build validation and substitution**: each component has its own
port, fixtures, repository/migrations where applicable, and a test command that runs with every other
component mocked. It does not prove independent network deployment in ten days. If separate runtime
deployment is itself a PoC acceptance criterion, that conflicts with this plan and must replace other
scope rather than being added silently.

## 2. What must be obtained first

Before connecting real systems, a human creates `config/poc-input.yaml` from the contract in
`variables.md` and answers these questions:

1. Which repository, full base SHA, full head SHA, Java source roots and exclusions define the slice?
2. Can Grafel run on the checked-out repository, and what exact executable/version is approved?
3. Is Confluence supplied as fixtures/export or REST, and which exact page IDs and versions are in scope?
4. Which credential environment-variable names may the process read? Never put values in YAML.
5. Which OpenKB version, model endpoint and data-egress classification are approved?
6. Who will act as code reviewer and document/meaning reviewer under the provisional PoC mechanism?

Source access is not needed to build gates 0–2. Use the synthetic gold slice first.

## 3. Target repository layout

The implementing agent creates only this new application tree; existing solution documents remain
unchanged except for deliberate links:

```text
poc/
  pyproject.toml
  src/bga/
    api/main.py
    common/{config,contracts,errors,hashing,urns}.py
    code/{ports,grafel_json,fixtures,service}.py
    documents/{ports,confluence_rest,confluence_fixture,normalizer,openkb_rest,service}.py
    ekg/{repository,service}.py
    linker/{deterministic,semantic,service}.py
    governance/{repository,service}.py
    review/{routes,view_models}.py
    review/templates/{inbox,code,document,linked,export}.html
    reporting/{approval_pack,partial_report}.py
  contracts/v1/*.schema.json
  migrations/{ekg,governance}/001_initial.sql
  config/poc-input.example.yaml
  fixtures/{code,confluence,openkb,linker,expected}/
  tests/{unit,contract,integration,e2e}/
  scripts/{verify-poc.ps1,run-local.ps1}
```

Every module exposes a Python `Protocol` port and accepts an implementation in its constructor.
Tests use fixture adapters. Production-shaped adapters use subprocess or HTTP. No global service
locator and no direct cross-package database access.

## 4. Gated build order

The agent must finish each verification gate before starting the next. A fixture-backed gate is a
valid result but must be labelled `FIXTURE` in provider status.

| Gate | Build | Verification required |
|---:|---|---|
| 0 | Project skeleton, config loader, typed errors, URNs, hashing | Invalid config fails before startup; schema examples validate |
| 1 | Canonical dataclasses/Pydantic models and fixture ports | Round-trip fixtures; unknown major version and unknown enum rejected |
| 2 | Synthetic Java/Confluence gold slice and expected links | Positive, negative, ambiguous and changed-source cases reviewed by human |
| 3 | Grafel runner and JSON normalizer | Import pinned SHA; reject schema != 1; every code entity resolves to source lines |
| 4 | Confluence fixture then REST snapshot adapter | Stable Markdown/span index; rerun of same page version is byte-identical |
| 5 | OpenKB REST adapter and candidate normalizer | Status/add/list/page calls mocked; every accepted candidate has original span evidence |
| 6 | EKG SQLite repository and bounded query | Restart retains graph; owner rules and depth/node limits enforced |
| 7 | Deterministic linker, optional semantic scorer | True/false/ambiguous gold cases; semantic result cannot approve or overwrite |
| 8 | Governance repository and stale projection | Decisions append-only; evidence hash mismatch returns `409 STALE_WRITE` |
| 9 | Three inspection views, decisions and exports | Keyboard-operable cold review; JSON/Markdown IDs and hashes agree |
| 10 | Partial report and full verification script | Code-only remains useful; absent Confluence is `SOURCE_ABSENT`, not “no requirement” |

## 5. Adapter implementation details

### 5.1 Grafel

The runner invokes an argument list without a shell:

```text
grafel index <repo-path> --export-json --out <run-dir>/grafel-graph.json
  --repo-tag <repo-id> --quiet --json-progress
```

Prerequisite: the pinned Grafel daemon is running. Record `grafel --version`, process exit code,
stdout/stderr digest and generated graph digest. Accept only `version: 1`, required top-level fields,
the expected `indexed_sha`, Java entities, relative source paths within the repository, positive line
ranges and edges whose endpoints exist. Ignore optional tool fields not used by the canonical model.

Map native entity IDs to canonical URNs inside the adapter. Preserve the native ID only in
`provider_ref`. Copy `CALLS`/dependency-like edges into the C1 private graph. Publish only selected
code anchors to C6. A Grafel failure returns `UNAVAILABLE` or `PARTIAL`; it never creates an empty
successful graph.

SCIP is not on the critical path. The local reference contains the SCIP protocol but not a Java
indexer. Implement only a `CodeGraphSource`-compatible fixture initially. A later time-boxed spike may
acquire and pin `scip-java`; failure must not block the Grafel slice.

### 5.2 Confluence snapshot

Implement `ConfluenceFixtureSource` first, then `ConfluenceRestSource`. The REST adapter requests a
specific page ID and version; it must never silently substitute “latest.” Store the raw response,
selected metadata, normalized Markdown and `spans.json` under:

```text
data/artifacts/confluence/<site>/<page-id>/<version>/
```

Normalization rules are deterministic: UTF-8, LF line endings, trim trailing whitespace, retain
heading order, convert tables to stable Markdown, replace unsupported macros with an explicit
`[UNSUPPORTED_MACRO:<type>]` marker, and list attachments without downloading them unless enabled.
Each block gets `h-<heading-slug>-<ordinal>` or `p-<ordinal>` and exact start/end character offsets
in the normalized file. Hash the normalized Markdown. Sanitise rendered HTML before display.

### 5.3 OpenKB

Run the pinned `openkb-web` on `127.0.0.1`; the application talks only to `/api/v1` using an optional
Bearer token. Required calls are:

- `GET /meta` for version capability;
- `POST /init` with KB name, model and absolute isolated KB path;
- multipart `POST /add` with `stream=false` and normalized Markdown files;
- `POST /status` and `POST /list`;
- `POST /page` for `summaries/<name>`, `concepts/<name>` and `entities/<name>`;
- `POST /document/source` when source inspection is needed.

Do not use OpenKB query/chat, page edit, delete, watch or auto-fix endpoints in this PoC. Treat all
OpenKB text as a candidate. The normalizer maps a candidate back to one or more original span IDs by
explicit citation, exact excerpt, then deterministic phrase match. If no span can be resolved, retain
the output as diagnostic data but do not submit it to C6 or review.

### 5.4 Storage and traversal

`ekg.db` owns canonical nodes, edges, evidence and source-version projections.
`governance.db` owns packets, immutable decisions and an outbox for status projections. Use explicit
SQL migrations and foreign keys. Use transactions for one aggregate at a time. Implement bounded
breadth-first traversal in the EKG service with predicate allow-list, maximum depth 3 and maximum
nodes 200 by default. Reject caller values above configured hard limits.

## 6. Real-data adaptation procedure

1. Copy the example manifest; enter identifiers and paths, never credentials.
2. Run provider `check` commands. Save capability/version output in the run ledger.
3. Snapshot one repository revision and one Confluence page version into a new `analysis_id` folder.
4. Compare normalized artifacts with fixtures; add adapter tests for every new macro/entity shape.
5. Have the most-related human mark the gold expected links before tuning semantic thresholds.
6. Run code-only and document-only independently before the linked flow.
7. Enable semantic linking only after deterministic links and negative cases pass.
8. Export the approval pack, rerun unchanged for stability, then alter one source fixture and verify
   staleness.

Never tune against production pages without recording the examples added to the gold set. Never put
raw institutional content into the repository.

## 7. Stop conditions

Stop and return a useful partial result when a provider is absent, credentials are unavailable, or a
tool cannot run. Stop the linked path entirely if source revision/version is unpinned, a candidate has
no exact evidence, the Grafel schema is unknown, or OpenKB/model egress is not approved. The code-only
view and report remain available whenever valid code evidence exists.
