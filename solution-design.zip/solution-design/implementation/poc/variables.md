# PoC configuration and variables

**Status:** proposed configuration contract

Create `poc/config/poc-input.example.yaml` with placeholders and validate it at startup. Real values
go in an ignored `poc-input.yaml`; credentials exist only in environment variables or an approved
secret store.

```yaml
contract_version: v1
environment: poc
work_dir: C:/absolute/path/to/poc-work

repository:
  repo_id: payments-service
  local_path: C:/absolute/path/to/repository
  base_revision: "<40-hex-sha>"
  head_revision: "<40-hex-sha>"
  source_roots: [src/main/java]
  include_globs: ["**/*.java"]
  exclude_globs: ["**/generated/**", "**/target/**", "**/build/**"]

confluence:
  source_mode: fixture # fixture | rest
  site_id: design
  base_url: "https://confluence.example.invalid"
  pages:
    - page_id: "12345"
      version: 17
      fixture_path: fixtures/confluence/page-12345-v17.json
  credential_env: CONFLUENCE_TOKEN
  user_env: CONFLUENCE_USER
  download_attachments: false

grafel:
  executable: C:/absolute/path/to/grafel.exe
  expected_version: "<pin-after-capability-check>"
  graph_schema_version: 1
  timeout_seconds: 300

openkb:
  base_url: http://127.0.0.1:7566/api/v1
  expected_version: "<pin-after-capability-check>"
  kb_name: bga-poc
  bearer_token_env: OPENKB_API_TOKEN
  model: "<approved-litellm-provider/model>"
  model_api_key_env: LLM_API_KEY
  model_api_base_env: OPENAI_API_BASE
  timeout_seconds: 600

linker:
  semantic_enabled: false
  confidence_threshold: 0.85
  ambiguity_margin: 0.05
  ruleset_version: deterministic-v1

limits:
  max_upload_bytes: 10485760
  max_graph_depth: 3
  max_graph_nodes: 200
  max_pages_per_run: 5

review:
  bind_host: 127.0.0.1
  bind_port: 8080
  session_secret_env: BGA_SESSION_SECRET
```

## Validation rules

- All filesystem paths are absolute after resolution and stay beneath configured allowed roots.
- Git revisions are full 40-character hexadecimal SHAs for live runs.
- Confluence pages have a positive integer version; “latest” is invalid for an analysis run.
- The app binds to loopback in manual-identity mode.
- `semantic_enabled=true` requires an approved model, endpoint and secret variable name.
- Thresholds are in `[0,1]`; ambiguity margin is non-negative and below the threshold.
- Tool versions are compared during `check`; mismatch is a startup warning or hard failure according
  to `strict_tool_versions`, which should be true for the final demonstration.

Do not log environment-variable values. Log only whether each required variable is present and a
stable secret identifier if supplied by the secret store.

