# PoC runtime flows

**Status:** proposed implementation behavior

## 1. Fixture-first startup

1. Load and validate the manifest; resolve only declared secret environment variables.
2. Apply each module's own migrations.
3. Register fixture adapters and set provider mode to `FIXTURE`.
4. Load the synthetic code and Confluence snapshots.
5. Build C1/C2 candidates independently, propose them to C6, then run C7 linking.
6. Start the UI only after status endpoints can describe every provider.

This flow must work with Grafel, Confluence, OpenKB and the model endpoint offline.

## 2. Live code ingest

1. Validate the repository path is under an allowed root and the requested commit exists.
2. Use an isolated checkout/worktree pinned to `head_revision`; do not alter the user's checkout.
3. Run Grafel with an argument array and a timeout into the analysis artifact directory.
4. Verify schema version, `indexed_sha`, coverage, paths, line ranges and edge endpoints.
5. Hash and retain the native JSON, then normalize into C1 records.
6. Persist C1 detail and propose only evidence-bearing anchors to C6.
7. Return C1 status and warnings even when the normalized graph is empty.

Base/head change classification comes from Git, not inferred from the graph. Grafel supplies the
entity and relationship context around changed paths/lines.

## 3. Live Confluence and OpenKB ingest

1. Fetch exactly the configured page ID/version and retain the raw response.
2. Normalize to Markdown and a span index; verify deterministic output by running normalization twice.
3. Create or reuse an isolated OpenKB knowledge base for the analysis.
4. Upload the normalized page with `stream=false`; poll/read status with a bounded timeout.
5. List and fetch generated summary/concept/entity pages.
6. Convert generated content to candidates and resolve each claim to original spans.
7. Submit only candidates with valid span evidence to C6; retain unresolved output as diagnostics.
8. Report the Confluence and OpenKB/model states separately so one does not hide the other.

## 4. Linking

For each document candidate, C7 evaluates in order:

1. exact qualified symbol in text/frontmatter;
2. exact simple symbol plus unique repository resolution;
3. configured module/path anchor;
4. controlled alias from a reviewed alias fixture;
5. optional semantic candidate scoring.

Each step records features and alternatives. A deterministic result can be strengthened by semantic
confirmation but never weakened silently. Negative gold pairs suppress known false matches. Ambiguous
results remain candidates and are shown to the reviewer.

## 5. Inspection and decision

1. C8 loads a frozen review packet from C3.
2. It resolves code evidence through C1, document evidence through C2 and edge detail through C6.
3. It displays provider status, source versions, relationship mechanism, confidence and alternatives.
4. The reviewer enters identity/role and chooses one item-level decision.
5. C8 sends the candidate version and displayed evidence-set hash to C3.
6. C3 rechecks the current hash, appends the decision, and queues a C6 projection event.
7. C6 applies the projection idempotently. Until then, C3 is authoritative and UI shows projection pending.

No bulk approval and no automatic release decision exist in the PoC.

## 6. Stale evidence

1. A new code commit or Confluence page version produces new evidence records; old records remain.
2. C6/C3 compare the approved evidence-set hash with the current candidate projection.
3. The current governance projection becomes `STALE`; the prior decision is not edited or deleted.
4. C8 disables unqualified approval of the old packet and offers creation of a new review packet.

## 7. Partial operation

| Available | Result |
|---|---|
| Code only | Code inspection and useful partial change report; document state `SOURCE_ABSENT` |
| Document only | Document inspection and candidates; change impact explicitly unavailable |
| Both, linker down | Independent views and prior links; no new link claims |
| Both, EKG down | Provider-native inspection; linked view `UNAVAILABLE` |
| OpenKB down | Original Confluence snapshot remains inspectable; compilation `UNAVAILABLE` |

