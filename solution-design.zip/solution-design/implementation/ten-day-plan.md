# Behavior Gap Analyzer — Implementation Plan

**Version:** v5  
**PoC duration:** ten staffed days  
**Sources:** Java 17 repositories and selected Confluence pages  
**Primary output:** independently inspectable code, document and linked knowledge plus manual approval pack

## 1. Outcome and fixed constraints

The PoC must prove a narrow vertical slice:

```text
code change -> code impact -> documented behavior -> candidate link -> human review -> approval pack
```

Fixed constraints:

- code access is the only required source for change analysis;
- Confluence may be absent, incomplete or stale;
- components must be independently deployable and testable with fixtures;
- a persistent C6 EKG, not C5 report-time federation, owns cross-domain links;
- approval is manual and PoC-only until a formal workflow exists;
- Java is version 17;
- ten staffed days cannot expand;
- a managed database or DBA may not be available on the first calendar/staffed day;
- tests, ADO delivery metadata, workflow definitions and runtime history are out of the current ingest scope.

## 2. Success criteria

By day ten, a cold reviewer can:

1. inspect a Java 17 change, symbols and bounded impact paths;
2. inspect a versioned Confluence page and compiled candidate claims;
3. inspect candidate code-document links with exact evidence and confidence;
4. see ambiguity, contradictions, source absence and staleness explicitly;
5. decide each candidate through the manual interface;
6. export a frozen Markdown approval pack and equivalent JSON manifest;
7. rerun after a source change and see prior decisions retained but stale;
8. run every component's contract tests using mocks instead of live dependencies.

## 3. Readiness and staffed-day clock

The clock starts when one core engineer has:

- read access to the selected Java repositories and base/head commits;
- a runnable Java 17 build or a documented reason indexing does not require it;
- approved sample Confluence exports or API access;
- permission to use synthetic/de-identified PoC material; and
- a local development environment.

DBA and managed graph infrastructure are not entry criteria. C6 begins behind the same contract with
a local persistent implementation. A production database decision is a post-PoC action.

## 4. Scope and staffing

### 4.1 Mandatory path

- common contracts and fixtures;
- C1 Grafel adapter and normalized code model;
- SCIP contract fixture and, only if an approved `scip-java` binary is acquired in time, a live
  index/import comparison for the selected Java 17 slice;
- C2 Confluence snapshot and OpenKB adapter/fixture;
- C6 local persistent EKG;
- C7 deterministic and semantic candidate linker;
- C3 governance API;
- C8 three-mode inspection and manual review UI;
- approval-pack Markdown and JSON export;
- C5 minimal evidence-linked partial report;
- degraded-source and stale-approval demonstrations.

### 4.2 Explicitly excluded

- production graph scaling/HA;
- enterprise-wide Confluence crawling;
- test ingestion or missing-test verdicts;
- ADO/workflow/runtime mining;
- formal SSO, electronic signatures or institutional approval integration;
- automatic release gating;
- PDF as a canonical record (optional rendering only).

## 5. Day-by-day plan

The executable gate definitions, adapter commands, manifest and test cases are specified in
[`poc/implementation-plan.md`](poc/implementation-plan.md). That document
uses a local modular monolith for the ten-day PoC while preserving these component contracts.

| Staffed day | Implementation | Verification milestone |
|---:|---|---|
| 1 | Freeze `AnalysisContext`, URNs, evidence, candidate, decision and EKG contracts; choose one gold slice | Schemas validate; positive, negative and ambiguous fixtures reviewed by a human |
| 2 | Implement C1 change surface and Grafel adapter on Java 17 | Changed entities and source evidence returned at pinned commits |
| 3 | Time-box the SCIP comparison. The local reference contains the protocol but not a Java indexer; acquire/pin `scip-java` only if approved, otherwise validate the SCIP port with fixtures and keep Grafel live | Difference or spike-blocker recorded honestly; the Grafel path remains usable |
| 4 | Implement Confluence snapshot adapter and OpenKB/fixture compilation | Page/version/span evidence and candidate claims are reproducible |
| 5 | Implement C6 local persistence and bounded query APIs | Code-only and document-only subgraphs survive process restart |
| 6 | Implement C7 deterministic resolution, then semantic candidates for unresolved pairs | Known matches link; negative pairs do not; ambiguous pairs remain unresolved |
| 7 | Implement C3 review packets, decisions, history and staleness | Decisions are item-level, immutable and tied to evidence-set hash |
| 8 | Implement C8 code/document/linked views and decision controls | Reviewer can inspect both sides and submit all four PoC decision types |
| 9 | Implement Markdown + JSON approval pack and minimal C5 report | Export equivalence, content hashes and source-absence profiles pass |
| 10 | Rerun, stale-source test, cold review and stop/go record | Acceptance matrix complete; real vs fixture capabilities explicitly named |

If an adapter slips, retain its fixture demonstration. Do not hide fixture-backed capability as a live
integration.

## 6. Contract-first integration

Every runtime component ships:

1. versioned request/response schemas;
2. status/capability endpoint;
3. success, empty, partial, stale, source-absent and unavailable fixtures where applicable;
4. idempotency behavior for writes;
5. deterministic pagination and bounded queries;
6. consumer contract tests that run without any other live component.

No component reads another component's tables. Cross-component references use canonical URNs and
immutable `EvidenceRef` values. C3 is the only decision writer; C7 is the only PoC link proposer; C6
is the only owner of canonical cross-domain edges.

## 7. Gold validation slice

Select a small set before model-assisted linking:

- one base/head Java 17 change;
- 10–30 relevant Java entities;
- one to five Confluence pages with fixed versions;
- at least five true code-document relationships;
- at least three plausible but false relationships;
- at least two deliberately ambiguous relationships;
- one changed-source case for stale-approval validation.

A human records expected outcomes. The system is evaluated against this set rather than a generated
answer judging itself.

## 8. Required conformance profiles

| Profile | Live/fixture components | Expected result |
|---|---|---|
| Code only | C1+C6+C8+C5 | Code inspection and useful `REPORT_PARTIAL`; document claims `UNKNOWN` |
| Document only | C2+C6+C8 | Document inspection; no change-impact conclusion |
| Linked | C1+C2+C6+C7+C8 | Candidate edges with both evidence sides |
| Ambiguous | Linker fixture | Alternatives shown; no forced canonical edge |
| Governance | C3 fixture + C8 | Item decisions stored with reviewer/role/rationale |
| Approval export | C3+C6+C8 fixtures | Markdown and JSON contain the same item/evidence/decision IDs |
| Stale source | Revised commit or page version | Previous decision retained; current projection `STALE` |
| Linker unavailable | Existing C6 data | Existing graph inspectable; no new link assertion |
| EKG unavailable | C1/C2 | Provider-native inspection only; linked view typed unavailable |

## 9. Manual review acceptance

The C8 review screen must:

- show source document and code evidence side by side;
- display relationship type, mechanism, confidence and ambiguity;
- allow `APPROVED`, `APPROVED_WITH_QUALIFICATION`, `REJECTED`, or
  `NEEDS_CLARIFICATION` per item;
- require rationale for qualification/rejection/clarification;
- capture actual reviewer and provisional most-related role;
- prevent editing immutable evidence;
- clearly label `POC_MANUAL_REVIEW` as non-formal;
- disable submission if the candidate/evidence hash changed since the screen loaded.

No bulk approval is included in the first PoC.

## 10. Approval-pack acceptance

The canonical Markdown and JSON must contain:

- analysis/review context and source versions;
- candidate statements and relationships;
- exact Confluence and code evidence references;
- mechanism, confidence, ambiguity and conflicts;
- item decisions, reviewer, provisional role, timestamp and rationale;
- contract, tool, compiler/model and ruleset versions;
- content/evidence-set hashes;
- limitations and missing/stale providers;
- explicit non-formal/non-release-approval notice.

Regenerating from the same frozen review returns byte-stable JSON and semantically stable Markdown.

## 11. Accountability

| Area | Interim most-related role |
|---|---|
| Java code relationship | Owning developer/technical lead |
| Confluence meaning | Page owner, BA or product owner |
| Cross-domain link | Joint code owner + closest business/design role where available |
| Governance mechanism | Architecture/risk/control representative |
| PoC stop/go | Named sponsor or delivery manager |

Every assignment is marked provisional. The record stores the actual actor rather than only a role
label.

## 12. Risks and mitigations

| Risk | Mitigation | Owner |
|---|---|---|
| Grafel preview behavior is unstable | Pin version; compare deterministic core with SCIP | C1 owner |
| SCIP Java indexer is unavailable or incompatible | Time-box on day 3; retain Grafel live path and SCIP contract fixtures | C1 owner |
| OpenKB lineage is too coarse | C2 adapter adds page/version/span, transformation and model metadata | C2 owner |
| Semantic false links | Deterministic-first ladder, gold negatives and mandatory review | C7 owner |
| Graph product delayed | Local persistent C6 implementation behind unchanged contract | C6 owner |
| Reviewer identity is informal | Label provisional/manual; capture actor, role and rationale | C3 owner |
| Approval pack is mistaken for release approval | Prominent disclaimer and separate release-decision field | C8/C5 owners |
| Ten days consumed by integration | One slice, time-box tools, preserve fixture proof | PoC lead |
| Sensitive content reaches external models | Synthetic/approved data and institution-controlled endpoint | Security owner |

## 13. Day-ten stop/go

Proceed only if:

- the vertical slice is independently inspectable in all three modes;
- candidate link precision on the small gold set is acceptable to the named reviewers;
- every displayed relationship resolves to evidence;
- ambiguous and missing-source states are honest;
- manual decisions and stale transitions are reproducible;
- approval artifacts are complete and internally consistent;
- the selected tools can be replaced through fixtures/contracts; and
- all production control gaps are explicitly recorded.

Do not proceed if the demo depends on hidden manual database edits, unverifiable generated claims,
forced ambiguous links or an unreported fixture.

## 14. Post-PoC sequence

1. select the production graph and deployment model;
2. integrate formal identity and approval workflow;
3. add C4 test knowledge and `VERIFIED_BY` edges;
4. add ADO/workflow-definition providers as available;
5. separately design runtime behavior/history mining;
6. define production retention, legal hold, HA/DR and model-risk controls.
