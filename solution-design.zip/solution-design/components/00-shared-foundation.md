# Behavior Gap Analyzer — Shared Design Foundation

**Normative version:** v5  
**PoC sources:** Java 17 code and Confluence  
**Approval:** manual PoC knowledge approval

## 1. Non-negotiable architecture

1. C1 and C2 are independent source providers with private stores.
2. C6 is the persistent EKG and owns canonical identities plus cross-domain edges.
3. C7 proposes links; it cannot approve them.
4. C3 owns review decisions and immutable history.
5. C8 is a replaceable UI/export client and never writes provider or EKG databases directly.
6. C5 consumes C6 and provider APIs; it is not the sole integration layer.
7. Every component can be validated against checked-in fixtures.
8. Missing source data becomes `UNKNOWN`/`SOURCE_ABSENT`, not a negative fact.
9. Detailed ASTs and full document content remain in provider-owned representations.
10. Formal institutional approval and human release approval are out of the manual PoC mechanism.

## 2. Canonical identifiers

URNs are lowercase where the source identifier is case-insensitive and must be stable across tools.

| Entity | Shape | Example |
|---|---|---|
| Repository | `urn:repo:<repo>` | `urn:repo:payments-service` |
| Commit | `urn:commit:<repo>:<sha>` | `urn:commit:payments-service:8f41c2a` |
| Code entity | `urn:code:<repo>:<language>:<kind>:<qualified-name>` | `urn:code:payments-service:java:method:com.bank.SettlementValidator.validate` |
| Confluence page version | `urn:confluence:<site>:page:<page-id>:v:<version>` | `urn:confluence:design:page:12345:v:17` |
| Document span | `<page-urn>#<stable-span-id>` | `urn:confluence:design:page:12345:v:17#heading-4.2-p2` |
| Candidate entity | `urn:candidate:entity:<uuid>` | generated once and versioned |
| Candidate edge | `urn:candidate:edge:<uuid>` | generated once and versioned |
| Canonical behavior | `urn:behavior:<domain>:<slug>` | `urn:behavior:settlement:block-non-stp` |
| Review packet | `urn:review:<uuid>:v:<n>` | immutable packet version |
| Decision | `urn:decision:<uuid>` | append-only decision record |
| Analysis run | `urn:analysis:<uuid>` | shared correlation root |

Provider-native IDs remain in `source_ref`; canonical URNs do not expose Grafel/OpenKB internal IDs
as the enterprise contract.

## 3. Analysis context

Every read, proposal and report uses one context:

```json
{
  "analysis_id": "urn:analysis:<uuid>",
  "base_revision": "<full git sha>",
  "head_revision": "<full git sha>",
  "confluence_scope": [
    {"page_id": "12345", "version": 17}
  ],
  "as_of": "2026-08-25T00:00:00Z",
  "environment": "poc",
  "contract_version": "v1"
}
```

Document-only inspection may omit base/head but must pin page versions. Change-impact analysis requires
both revisions. Historical replay excludes evidence created after `as_of`.

## 4. Provider status

| State | Meaning | Consumer behavior |
|---|---|---|
| `AVAILABLE` | Complete for declared scope | Use evidence |
| `PARTIAL` | Some declared scope is missing | Use returned evidence; dependent conclusions may be `UNKNOWN` |
| `STALE` | Evidence predates required source version | Display with warning; forbid unqualified approval |
| `SOURCE_ABSENT` | Source is legitimately not present/in scope | Continue with independent views |
| `OUT_OF_SCOPE` | Capability is intentionally excluded | Do not retry or infer |
| `UNAVAILABLE` | Expected provider failed | Isolate failure; keep existing evidence |

Empty results are not provider states. An `AVAILABLE` provider may return zero matches.

## 5. Evidence contract

Every claim, anchor and edge carries at least one immutable evidence reference:

```json
{
  "evidence_id": "urn:evidence:<uuid>",
  "source_kind": "GIT_SOURCE",
  "source_urn": "urn:commit:payments-service:8f41c2a",
  "locator": {
    "path": "src/main/java/com/bank/SettlementValidator.java",
    "start_line": 84,
    "end_line": 101
  },
  "content_hash": "sha256:<hex>",
  "observed_at": "2026-08-25T00:00:00Z",
  "mechanism": "SCIP_DEFINITION",
  "producer": "c1-scip-adapter",
  "producer_version": "<pinned-version>"
}
```

Confluence evidence additionally includes site, page ID, version, URL and stable span/heading. LLM
evidence includes model, prompt/template and compiler versions. Evidence records are append-only;
source deletion creates a tombstone.

## 6. Candidate and edge semantics

| Field | Requirement |
|---|---|
| `candidate_urn` | Stable across retries; new version on changed content/evidence |
| `subject_urn` / `object_urn` | Canonical or unresolved candidate URN |
| `predicate` | Controlled v1 vocabulary |
| `mechanism` | Deterministic or semantic linking mechanism |
| `confidence` | 0–1 estimate; never approval |
| `resolution_state` | `RESOLVED`, `AMBIGUOUS`, `UNRESOLVED`, `CONFLICT` |
| `governance_state` | C3-owned projection |
| `evidence_refs[]` | Non-empty and resolvable |
| `valid_from` / `valid_to` | Source validity window |
| `idempotency_key` | Required for mutation |

Initial predicates:

- `DESCRIBES`
- `IMPLEMENTS`
- `PARTIALLY_IMPLEMENTS`
- `CONTRADICTS`
- `RELATED_TO`
- `CALLS`
- `DEPENDS_ON`

`VERIFIED_BY` is reserved for the future C4 provider.

## 7. Governance states

Candidate lifecycle:

```text
CANDIDATE -> APPROVED
          -> APPROVED_WITH_QUALIFICATION
          -> REJECTED
          -> NEEDS_CLARIFICATION
approved/qualified -> STALE -> SUPERSEDED or re-reviewed
```

Only a named human can create the four decision states. C3 owns the decision; C6 stores a query
projection that includes `decision_ref`. Confidence does not map automatically to approval.

Required decision fields:

- candidate/version and evidence-set hash;
- decision;
- reviewer identifier and display name;
- actual role and `role_assignment=PROVISIONAL_MOST_RELATED_ROLE` when applicable;
- rationale when not unqualified approval;
- timestamp;
- `approval_mechanism=POC_MANUAL_REVIEW`;
- contract/UI version.

## 8. Inspection contracts

C8 supports:

1. **code inspection:** C1 detail plus C6 enterprise relationships;
2. **document inspection:** C2 source/compiled detail plus C6 relationships;
3. **linked inspection:** C6 edge with evidence resolved from C1 and C2.

Inspection returns provider states and evidence; it never implies approval. The interface must detect
an evidence hash change before accepting a decision.

## 9. Report semantics

| Field | Values | Owner |
|---|---|---|
| `report_status` | `REPORT_COMPLETE`, `REPORT_PARTIAL`, `ANALYSIS_FAILED` | C5 |
| `knowledge_state` | candidate/resolution/governance state | C6 projection from C3/C7 |
| `recommendation` | evidence-based next action | C5 |
| `human_release_decision` | `OPEN`, `PROCEED`, `REMEDIATE`, `DEFER`, `ESCALATE` | separate named human/workflow |

Manual knowledge approval never sets `human_release_decision`.

## 10. Component independence

Each component owns its migrations, credentials, store and lifecycle. Allowed interaction is API/event
only. An orchestration sequence may call multiple components but is not a distributed transaction.
Writes are idempotent; readers tolerate duplicate delivery and eventual status projection.

Required independent fixtures:

- C1: Java source/change and normalized code graph;
- C2: Confluence snapshot and compiled candidates;
- C3: review packet and decisions;
- C5: EKG subgraph and provider evidence bundle;
- C6: provider-neutral node/edge proposals;
- C7: positive, negative, ambiguous and conflict pairs;
- C8: mock inspection and governance APIs;
- C4: future test fixtures, not current PoC acceptance.

## 11. Failure rules

- Never ask an LLM to repair a malformed provider contract response.
- Never infer a missing relationship from a timeout or absent source.
- Never promote a semantic match without evidence.
- Never overwrite an earlier decision or evidence record.
- Never expose tool-private schema as the canonical EKG API.
- Bound traversals by depth, node count, predicate allow-list and time.
- Return typed errors with correlation ID and provider state.

## 12. PoC versus production

The PoC may use local persistent storage and manually entered reviewer identity. It must label those
limitations. Production requires formal IAM, authorization, segregation of duties, electronic
signature policy where applicable, retention/legal hold, encryption/key management, HA/DR, monitoring,
model-risk controls and approved data egress.
