# C7 — Knowledge Linker

**Owns:** entity-resolution computation, candidate code-document links and explanations  
**Consumes:** C1/C2 contracts and C6 identity/query contracts  
**Cannot:** approve knowledge or read provider databases

## 1. Responsibility

C7 links independently sourced code and Confluence knowledge. It produces candidate relationships
with evidence, mechanism, confidence and alternatives. It is independently testable using code and
document fixtures.

## 2. Deterministic-first ladder

Apply in order:

1. explicit Confluence/code URL or canonical ID;
2. exact package-qualified Java symbol;
3. repository/path/class/method anchor;
4. stable endpoint, event, configuration or data identifier;
5. governed alias/terminology mapping;
6. semantic similarity/reasoning.

Lower tiers may confirm higher-tier evidence. Semantic output cannot erase deterministic conflict.

## 3. Resolution results

| Result | Meaning |
|---|---|
| `RESOLVED` | One best candidate with sufficient evidence |
| `AMBIGUOUS` | Multiple plausible candidates; alternatives retained |
| `UNRESOLVED` | No defensible candidate |
| `CONFLICT` | Evidence supports incompatible relationships/statements |

`UNRESOLVED` does not mean unrelated. `RESOLVED` does not mean approved.

## 4. Candidate edge

Every edge includes:

- subject/predicate/object candidate or canonical URNs;
- source revisions;
- deterministic/semantic mechanism;
- confidence and rule/model version;
- positive evidence from both applicable sides;
- contrary evidence;
- alternatives;
- resolution state;
- idempotency key/version.

Proposed predicates are restricted by the v1 registry.

## 5. Semantic linking controls

- Use semantic linking only after deterministic tiers.
- Provide bounded source context with exact evidence references.
- Record model and prompt version.
- Require structured output validation.
- Reject invented URNs/spans.
- Use a gold set containing true, false and ambiguous pairs.
- Never auto-approve based on threshold.

## 6. Contracts

- `link_status`
- `link_candidates`
- `link_explain`

C7 submits valid candidates through `ekg_propose_subgraph`. It cannot call `gov_record_decision`.

## 7. Failure behavior

| Failure | Behavior |
|---|---|
| C1 absent | Document candidates remain; code links `UNKNOWN` |
| C2 absent | Code candidates remain; document links `UNKNOWN` |
| Semantic model unavailable | Deterministic tiers still run; state `PARTIAL` |
| Evidence not resolvable | Reject candidate |
| Multiple exact-looking matches | `AMBIGUOUS` |
| C6 unavailable | Return candidate bundle for retry; do not claim persistence |
| Rules/model changed | New candidate version; previous review may become stale |

## 8. Independent tests

1. Known positives resolve.
2. Known negatives do not link.
3. Ambiguous fixtures retain all material alternatives.
4. Deterministic conflict beats semantic similarity.
5. Every link explains features/mechanism/evidence.
6. Repeated identical inputs produce the same idempotent proposal.
7. C7 works with C1/C2/C6 fixtures and C3/C5/C8 offline.
8. No path exists from C7 to an approval write.

## 9. PoC metrics

On the small human-labeled gold set record:

- precision/recall separately by tier;
- ambiguous/unresolved rate;
- reviewer acceptance by mechanism;
- false positive cause;
- time per link batch;
- model/tool versions.

The set is too small for enterprise accuracy claims; results only support the PoC tool decision.
