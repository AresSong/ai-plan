# C8 — Knowledge Review Workbench

**Owns:** inspection experience, review interaction and approval-pack rendering  
**Decision system of record:** C3  
**PoC identity:** manually entered/selected and explicitly non-formal

## 1. Responsibility

C8 gives a reviewer three independent views:

1. code;
2. Confluence document/compiled knowledge;
3. linked code-document evidence.

It lets a named human make item-level decisions through C3 and exports a frozen Markdown approval
pack plus JSON manifest. C8 does not write C1/C2/C3/C6 databases directly.

## 2. Review inbox

Filters:

- new candidates;
- ambiguous/unresolved/conflict;
- stale approvals;
- needs clarification;
- source page/repository/domain;
- proposed reviewer role.

No bulk approval is included in the first PoC.

## 3. Inspection views

### Code

Show canonical reference, repository/commit, path/span, changed status, callers/dependencies/impact,
provider mechanism and linked documents.

### Document

Show Confluence URL/page/version, exact heading/paragraph, source metadata, compiled candidate,
transformation lineage, conflicts and linked code.

### Linked

Show side by side:

| Document evidence | Candidate relationship | Code evidence |
|---|---|---|
| Page/version/span | Predicate | Repo/commit/entity/span |
| Exact supported text | Mechanism/confidence | Relevant path/relationship |
| Compiler lineage | Alternatives/conflicts | Code-provider lineage |
| Source state | Governance/history | Source state |

## 4. Decision interaction

Buttons:

- `Approve`
- `Approve with qualification`
- `Reject`
- `Needs clarification`

Before submission C8 rechecks packet/item version and evidence-set hash. It captures reviewer,
provisional role and rationale, then calls `gov_record_decision`. It never edits the evidence.

The screen displays:

> PoC manual knowledge review. This is not formal institutional approval and does not approve a
> software release.

## 5. Approval pack

Canonical outputs:

- `approval-pack.md` for human review;
- `approval-pack.json` for machine use.

Both derive from one frozen view model and contain:

1. packet/context/source versions;
2. candidate statements and edges;
3. exact code/document evidence;
4. mechanisms, confidence, alternatives and conflicts;
5. item decisions and decision history;
6. reviewer, provisional role, rationale and timestamp;
7. provider/contract/model/rules versions;
8. content/evidence/export hashes;
9. missing/stale provider limitations;
10. non-formal/non-release-approval notice.

PDF may be rendered from the frozen Markdown but is not the canonical PoC record.

## 6. Contracts and data access

C8 calls:

- C1 `code_get_entity`/`code_impact_paths`;
- C2 `doc_get_candidate`/snapshot reads;
- C6 `ekg_query_subgraph`/`ekg_get_context`;
- C3 review/decision/history operations.

C8 stores only session/UI preferences and export files. Any cached review data is disposable.

## 7. Failure behavior

| Failure | UI behavior |
|---|---|
| One evidence provider unavailable | Show available side and typed limitation; disable unsupported approval |
| C6 unavailable | Provider-native views only; linked view unavailable |
| C3 unavailable | Read-only inspection; decision buttons disabled |
| Evidence changed while open | Reject submission, refresh packet, show stale warning |
| Export fails | Decision remains stored; retry export without resubmitting decision |
| Reviewer missing | Block submission |

## 8. Accessibility and security baseline

- Keyboard-operable decision controls and visible focus.
- Do not rely on color alone for status.
- Escape/sanitize Confluence and generated content.
- Never render untrusted HTML/scripts from source pages.
- Do not expose tokens/provider credentials in the browser.
- Log decision command metadata without logging sensitive source content.

## 9. Independent tests

1. All three views render from fixtures.
2. All four decisions call the correct C3 contract.
3. Stale hash prevents submission.
4. No bulk approval control exists.
5. Markdown/JSON exports contain identical IDs and decisions.
6. Export retry cannot duplicate a decision.
7. C8 works with all dependencies mocked.
8. The non-formal/non-release notice is present in UI and exports.

## 10. PoC exit

A cold reviewer can inspect each source and their links, verify the evidence without hidden database
access, record item-level manual decisions, and produce a reproducible approval pack.
