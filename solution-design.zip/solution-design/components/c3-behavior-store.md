# C3 — Knowledge Governance

**Owns:** review packets, item-level decisions, history and stale transitions  
**PoC mechanism:** manual review through C8  
**Does not own:** source content, canonical graph traversal or release approval

## 1. Responsibility

C3 is the system of record for what a named human reviewed and decided. It freezes the exact
candidate versions and evidence-set hash shown to the reviewer, records an append-only decision, and
publishes a status projection for C6.

The PoC mechanism is explicitly labeled `POC_MANUAL_REVIEW`. It is not a formal institutional
workflow, electronic signature or human release decision.

## 2. Review packet

A packet contains:

- context and packet version;
- candidate entity/edge versions;
- exact evidence references and evidence-set hash;
- provider/source states;
- linker mechanism, confidence and alternatives;
- conflict/staleness warnings;
- created time and producer versions.

Packets are immutable. A changed candidate or evidence set creates a new packet version.

## 3. Decision model

Allowed decisions:

- `APPROVED`
- `APPROVED_WITH_QUALIFICATION`
- `REJECTED`
- `NEEDS_CLARIFICATION`

Required fields:

```json
{
  "decision_urn": "urn:decision:<uuid>",
  "packet_urn": "urn:review:<uuid>:v:1",
  "item_urn": "urn:candidate:edge:<uuid>",
  "item_version": 1,
  "evidence_set_hash": "sha256:<hex>",
  "decision": "APPROVED_WITH_QUALIFICATION",
  "reviewer": {"id":"<local-id>","display_name":"Jane Smith"},
  "role": "Payments Business Analyst",
  "role_assignment": "PROVISIONAL_MOST_RELATED_ROLE",
  "rationale": "Rule is supported; exception path needs clarification.",
  "decided_at": "2026-08-25T14:30:00+08:00",
  "approval_mechanism": "POC_MANUAL_REVIEW"
}
```

Rationale is mandatory except for unqualified approval. The UI may require rationale for every
decision without changing the contract.

## 4. Concurrency and staleness

C3 rejects a decision if the submitted item version or evidence-set hash differs from the frozen
packet. C8 must refresh instead of silently approving changed evidence.

When C1/C2/C6 report a changed source/evidence set:

1. retain the original decision;
2. append a stale transition referencing the changed evidence;
3. project `STALE` to C6 for current queries;
4. create a new review packet if re-review is requested.

No decision is overwritten.

## 5. Provisional accountability

Until formal owners exist, C8 suggests the most-related role. C3 records:

- actual reviewer identity;
- stated role;
- `PROVISIONAL_MOST_RELATED_ROLE`;
- rationale for the assignment where necessary.

The suggestion does not grant production authority. The PoC must display this limitation.

## 6. Contracts

- `gov_create_packet`
- `gov_list_review_items`
- `gov_get_review_packet`
- `gov_record_decision`
- `gov_get_decision_history`
- `gov_mark_stale`

Only C3 accepts decision writes. C8 calls these contracts; C6 receives signed/idempotent status
projections and stores the `decision_ref`.

## 7. Approval pack relationship

C3 provides frozen data; C8 renders it. Exporting a pack does not change decisions. C3 stores the
export manifest reference/hash if audit of the generated artifact is required.

## 8. Failure behavior

| Failure | Behavior |
|---|---|
| C3 unavailable | Inspection remains read-only; approval controls disabled |
| Evidence hash changed | Reject with `GOV_STALE_PACKET` |
| Duplicate idempotency key/same payload | Return original decision |
| Duplicate key/different payload | `GOV_IDEMPOTENCY_CONFLICT` |
| Missing reviewer | Reject |
| Unauthorized decision value | Reject |
| C6 projection fails | Decision remains committed; retry projection idempotently |

## 9. Independent tests

1. All four decisions are recorded.
2. Qualification/rejection/clarification require rationale.
3. Stale packet cannot be approved.
4. Earlier decisions survive supersession.
5. Repeated idempotent writes do not duplicate history.
6. C3 runs against candidate/evidence fixtures with all other components offline.
7. C6 projection failure does not lose the decision.
8. Manual approval cannot set a release decision.

## 10. Future formal workflow

A later workflow system replaces C8's manual identity/decision entry while calling the same C3
decision contract or a compatible v2. Formal IAM, authorization, segregation of duties and electronic
signature requirements are added without moving the decision system of record into the UI.
