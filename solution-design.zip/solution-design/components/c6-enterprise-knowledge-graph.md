# C6 — Enterprise Knowledge Graph

**Owns:** canonical enterprise identities, cross-domain edges, evidence bindings, temporal validity
and governance-status projections  
**Does not own:** full source content, detailed code graph, link computation or decisions

## 1. Responsibility

C6 is the persistent unified semantic/query layer. It allows code, Confluence and future sources to
remain independent while making their shared meaning reusable outside a single C5 run.

C6 stores selected anchors and relationships:

```text
Confluence span -> DESCRIBES -> Behavior -> IMPLEMENTED_BY -> Java method
```

Full Confluence pages remain in C2/source; detailed code edges remain in C1.

## 2. Canonical model

Initial node types:

- `REPOSITORY`, `COMMIT`, `CODE_ENTITY`;
- `DOCUMENT`, `DOCUMENT_SECTION`;
- `BEHAVIOR`, `RULE`, `DATA_ELEMENT`, `SYSTEM`;
- `CANDIDATE_ENTITY` when identity is unresolved.

Initial edge types:

- `DESCRIBES`, `IMPLEMENTS`, `PARTIALLY_IMPLEMENTS`;
- `CONTRADICTS`, `RELATED_TO`;
- selected `CALLS`/`DEPENDS_ON` anchors.

Every edge carries source mechanism, confidence, resolution/governance state, evidence references,
validity and version.

## 3. Ownership and write policy

Allowed writers:

- C1/C2 adapters propose source anchors;
- C7 proposes cross-domain candidate edges;
- C3 applies governance-status projections.

C6 validates identity shape, evidence resolvability, schema and idempotency. Accepting a candidate
proposal does not approve it.

No client writes the C6 database directly.

## 4. Identity resolution

Canonical identity is stable across provider-tool replacement. Tool-private IDs are opaque provider
references. Resolution returns:

- exact canonical match;
- ambiguous alternatives;
- unresolved candidate;
- identity conflict.

C6 never chooses among ambiguous candidates based solely on confidence.

## 5. Temporal behavior

Nodes/edges retain:

- source revision/page version;
- observed/valid-from time;
- valid-to/tombstone when superseded;
- candidate version;
- governance projection version.

Queries execute as of `AnalysisContext.as_of` and pinned source revisions. A changed source may create
a new edge version while preserving the earlier reviewed state.

## 6. Contracts

- `ekg_status`
- `ekg_propose_subgraph`
- `ekg_resolve_entities`
- `ekg_query_subgraph`
- `ekg_get_context`
- `ekg_apply_status_projection`

Traversals require seed count, predicate allow-list, maximum depth, maximum nodes and time budget.
Pagination/order are deterministic.

## 7. Partition health

`ekg_status` reports code, document and future partitions independently:

```json
{
  "graph_state": "AVAILABLE",
  "partitions": {
    "code": {"state":"AVAILABLE","revision":"<sha>"},
    "document": {"state":"SOURCE_ABSENT"},
    "test": {"state":"OUT_OF_SCOPE"}
  }
}
```

A missing optional partition does not make the graph unavailable.

## 8. Storage

The PoC begins with a local persistent store behind the contract; exact technology is an
implementation binding, not a semantic decision. Required capabilities are:

- unique/idempotent versions;
- bounded typed traversal;
- evidence/status indexes;
- atomic write within one proposal/projection;
- backup/export for the PoC;
- process-restart persistence.

No distributed transaction spans C1/C2/C3/C6. Projection retries are idempotent.

## 9. Failure behavior

| Failure | Behavior |
|---|---|
| Invalid evidence reference | Reject item, not whole valid batch |
| Duplicate identical proposal | Return existing version |
| Duplicate key/different payload | Typed conflict |
| C3 projection delayed | Keep prior projection and decision reference status warning |
| Optional partition absent | Graph remains available |
| Query exceeds bounds | Return typed bounded-query error/partial where safe |
| Store unavailable | Linked inspection and C5 graph analysis unavailable; providers remain independent |

## 10. Independent tests

1. Provider-neutral fixtures create/query a code-only subgraph.
2. Document-only partition works independently.
3. Cross-domain edge requires evidence from both applicable sides.
4. Ambiguous identity is retained without forced merge.
5. Status projection cannot modify immutable evidence.
6. Stale/superseded versions remain historically queryable.
7. Traversal limits are enforced.
8. C6 tests run with C1/C2/C3/C5/C7/C8 offline.

## 11. PoC exit

C6 passes when code-only, document-only and linked subgraphs persist across restart, every relationship
can be explained through evidence, and no consumer depends on the chosen graph-store schema.
