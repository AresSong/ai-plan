# C2 — Confluence Knowledge Compiler

**PoC source:** selected Confluence pages/spaces  
**Implementation candidate:** OpenKB behind an adapter  
**Borrowed patterns:** `llm_wiki` purpose/schema, two-stage ingest, review and lint  
**Owns:** source snapshots and document-local candidate knowledge

## 1. Responsibility

C2 converts versioned Confluence content into inspectable candidate knowledge while retaining exact
source evidence. It can operate without code or the EKG.

C2 does not own canonical enterprise identity, cross-domain linking, review decisions or release
recommendations. Those belong to C6, C7, C3 and C5 respectively.

## 2. Layers

```text
immutable source snapshot
        |
        v
document-local analysis
        |
        v
compiled candidate knowledge
```

### Source snapshot

Store page/site ID, URL, version, title, author/update metadata, content hash, captured time and a
stable heading/paragraph span index. A changed page creates a new snapshot; deletion creates a
tombstone.

### Candidate knowledge

Initial types:

- `DOCUMENT`
- `SECTION`
- `BEHAVIOR`
- `RULE`
- `DATA_ELEMENT`
- `SYSTEM`
- `CODE_REFERENCE_HINT`
- `CONFLICT`

Candidate statements must point to exact source spans. Page-level `sources[]` alone is insufficient.

## 3. Compilation

### Stage A — analyze

Identify candidate entities, statements, explicit identifiers, contradictions, ambiguity and missing
context. This stage writes no canonical EKG data.

### Stage B — generate

Generate only candidates supported by Stage A. Each output includes source span, content hash,
compiler/model/prompt version and confidence. Normative words such as “must” are preserved only when
present in the evidence; the model cannot invent normative modality.

## 4. OpenKB boundary

OpenKB may perform document conversion, wiki compilation and local concept/entity synthesis. The C2
adapter must:

- map Confluence metadata and versions into immutable snapshots;
- add claim-level span provenance;
- normalize output into C2 candidates;
- prevent OpenKB wikilinks from becoming approved enterprise edges;
- record model/compiler versions;
- handle recompile/delete as new versions/tombstones;
- keep any cloud PageIndex use disabled until separately approved.

OpenKB files are a compiled projection, not the enterprise system of record.

## 5. `llm_wiki` patterns

Borrow:

- a `purpose` artifact defining PoC scope and questions;
- a separate schema/ontology artifact;
- analyze-then-generate ingest;
- contradiction and orphan detection;
- asynchronous review candidates;
- lint for broken links, stale evidence and isolated concepts.

Do not adopt its local desktop filesystem or page-level provenance as C6/C3 storage.

## 6. Purpose for the PoC

The compiler is asked to support:

1. what behavior/rule the page describes;
2. what systems or technical identifiers it names;
3. what statements may map to Java entities;
4. what conflicts or missing context require review;
5. what exact source span supports each answer.

It is not asked to infer test coverage, runtime behavior or release safety.

## 7. Contracts

- `doc_status`
- `doc_snapshot`
- `doc_compile`
- `doc_get_candidate`
- `doc_lint`

C2 may submit document anchors/candidates to C6 with `ekg_propose_subgraph`. C7 reads C2 candidates
through the contract, never the C2 database.

## 8. Inspection

Document-only inspection returns:

- source metadata/version and original link;
- stable spans and exact excerpts within policy limits;
- compiled claims/entities;
- confidence and transformation lineage;
- conflicts, orphan concepts and stale status;
- known C6 relationships when C6 is available.

If C1 is absent, code linkage is `UNKNOWN`; C2 does not label the page undocumented or unimplemented.

## 9. Failure behavior

| Failure | State/result |
|---|---|
| Confluence not used/in scope | `SOURCE_ABSENT` |
| Some pages inaccessible | `PARTIAL`; page IDs named without leaking content |
| Snapshot older than requested version | `STALE` |
| OpenKB/model unavailable | Snapshot remains inspectable; compilation `UNAVAILABLE` |
| Candidate lacks resolvable span | Reject candidate, retain diagnostic |
| Conflicting statements | Emit `CONFLICT` candidate; do not choose silently |
| Page removed | Tombstone; prior evidence remains auditable |

## 10. Independent tests

1. Same page/version produces the same snapshot hash.
2. Every candidate resolves to at least one span.
3. Compilation works from exported fixtures without Confluence.
4. OpenKB can be replaced by compiled fixtures.
5. Model output cannot create an unsupported source span.
6. Changed page creates new candidate versions and stale notifications.
7. C2 runs with C1/C3/C5/C6/C7/C8 offline.
8. `SOURCE_ABSENT` is distinct from failure.

## 11. PoC exit

C2 passes when a reviewer can inspect selected Confluence content and compiled candidates without
code, verify every candidate against exact source evidence, and replace OpenKB with fixtures without
changing downstream contracts.
