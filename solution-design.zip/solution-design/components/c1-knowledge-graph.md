# C1 — Code Intelligence Provider

**PoC language:** Java 17  
**Primary candidate:** Grafel  
**Optional deterministic comparison:** SCIP adapter; fixture-first until a Java indexer is acquired  
**Owns:** detailed code graph, change surface and code evidence

## 1. Responsibility

C1 answers code-native questions without requiring Confluence, C6 or C5:

- what changed between base and head;
- where an entity is defined;
- what references, calls or depends on it;
- what bounded impact paths follow from the change;
- which source spans prove each relationship.

C1 does not decide business meaning, create approved code-document links or infer documentation
absence.

## 2. Independent boundary

C1 owns its index/store, adapters, migrations, credentials and refresh lifecycle. It can be built and
tested from small Java 17 repositories. It never reads C2/C3/C6 tables.

Selected normalized code anchors may be submitted to C6 through `ekg_propose_subgraph`. The detailed
code graph remains in C1.

## 3. Normalized model

### CodeEntityRef

```json
{
  "entity_urn": "urn:code:payments-service:java:method:com.bank.SettlementValidator.validate",
  "kind": "METHOD",
  "repository": "payments-service",
  "revision": "<full-sha>",
  "path": "src/main/java/com/bank/SettlementValidator.java",
  "qualified_name": "com.bank.SettlementValidator.validate",
  "signature": "validate(Instruction):ValidationResult",
  "provider_refs": {
    "grafel": "<opaque-id>",
    "scip": "<package-qualified-symbol>"
  },
  "evidence_refs": ["urn:evidence:<uuid>"]
}
```

Initial edge kinds: `DEFINES`, `REFERENCES`, `CALLS`, `IMPLEMENTS`, `EXTENDS`, `DEPENDS_ON`,
`READS`, `WRITES`, `EXPOSES_ENDPOINT`, and `PUBLISHES_EVENT`. C1 maps tool-native edges to this
vocabulary and preserves the original mechanism in evidence.

## 4. Tool strategy

### 4.1 Grafel

Use Grafel to test local multi-repository and framework-aware navigation. Pin an exact version.
For this PoC, import schema-versioned `graph.json` produced by `grafel index --export-json` rather
than binding to preview MCP names. Never expose its native entity registry, `graph.json` or `graph.fb`
as the C1 public contract.

### 4.2 SCIP

The checked-in reference contains the language-neutral SCIP protocol, not a Java indexer. Keep a
`.scip` fixture adapter behind the same C1 port. Time-box acquisition and pinning of `scip-java`; if
available, run it on the same Java 17 slice to compare definitions, references and implementations.
Sourcegraph is not required for the provider contract.

### 4.3 Comparison

The PoC compares:

- entity identity and source ranges;
- definitions/references/implementations;
- cross-file and cross-repository resolution;
- repeated-index determinism;
- indexing time/resource use;
- Grafel-only framework/impact relationships.

The comparison is diagnostic. Consumers always receive the same C1 schema.

## 5. Change and impact algorithm

1. Validate base/head commits and repository scope.
2. Extract changed files and hunks.
3. Resolve enclosing code entities at both revisions.
4. Normalize renamed/deleted/added/modified entities.
5. Traverse allowed edge kinds with maximum depth, node and time limits.
6. Attach source evidence to every seed and returned edge.
7. Mark unresolved dynamic/reflection/framework paths explicitly.

`NO_IMPACT_FOUND` is allowed only when indexing is current, the changed surface was resolved, the
configured traversal completed and no qualifying path exists. Otherwise return `UNKNOWN`.

## 6. Contracts

- `code_status`
- `code_changed_entities`
- `code_get_entity`
- `code_impact_paths`
- `code_resolve_ref`
- `code_compare_backends`

All reads are revision-pinned and paginated/bounded. C1 returns typed `AMBIGUOUS`/`UNRESOLVED`
results rather than guessing.

## 7. C6 projection

C1 may propose:

- repository and commit anchors;
- selected changed/important code entities;
- code-native edges useful for cross-domain traversal;
- evidence references and provider pointers.

C6 acceptance validates shape/evidence only. It does not make a code-native edge a reviewed business
relationship.

## 8. Failure behavior

| Failure | State/result |
|---|---|
| Repository legitimately excluded | `SOURCE_ABSENT` for that repository |
| Index incomplete | `PARTIAL`; missing regions named |
| Index at wrong commit | `STALE` |
| Grafel fails but an optional live SCIP adapter succeeds | `PARTIAL`; deterministic subset remains |
| SCIP build/index fails but Grafel succeeds | `PARTIAL`; comparison limitation recorded |
| Grafel fails and no live alternative exists for required change | `UNAVAILABLE`; C5 change analysis fails |
| Symbol has multiple matches | `AMBIGUOUS`; alternatives returned |

## 9. Independent tests

1. Java 17 class/method identity is stable across repeated indexes.
2. Added, modified, renamed and deleted entities are represented.
3. Bounded impact traversal cannot exceed limits.
4. Every returned entity/edge resolves to source evidence.
5. Grafel and SCIP fixtures satisfy the same consumer tests.
6. C1 works with C2–C8 offline.
7. A stale commit cannot be rendered as current.
8. Ambiguity never becomes a deterministic match.

## 10. PoC exit

C1 passes when a reviewer can inspect a real Java 17 change and its evidence-backed bounded impact
without Confluence, and when the selected backend can be replaced by a fixture without changing C5,
C6, C7 or C8.
