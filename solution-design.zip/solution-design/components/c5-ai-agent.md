# C5 — Behavior Gap Analyzer

**Owns:** analysis orchestration, evidence-backed findings, limitations and report  
**Consumes:** C6 first, C1/C2 for detail  
**Does not own:** canonical linking, knowledge approval or release approval

## 1. Boundary

C5 is one consumer of the enterprise knowledge fabric. It queries C6 for canonical cross-domain
paths, then calls C1/C2 for source-native drill-down evidence. It does not rebuild the unified graph
inside each run and does not write provider stores.

The PoC report focuses on code/document alignment. Test-gap verdicts remain out of scope until C4 is
implemented.

## 2. Inputs

- `AnalysisContext` with base/head Java revisions, Confluence scope/version and `as_of`;
- changed code entities from C1;
- bounded C6 subgraph;
- C1/C2 evidence detail;
- C3 governance states projected through C6.

## 3. Workflow

1. Validate context and provider compatibility.
2. Require usable C1 for a requested change analysis.
3. Get changed entities and bounded impacts.
4. Query C6 for behaviors/documents/rules linked to changed code.
5. Resolve evidence through C1 and C2.
6. Classify each conclusion as supported, disputed or unknown.
7. Preserve candidate/governance status; never render candidate as approved.
8. Rank findings deterministically.
9. Render evidence, limitations and next action.

## 4. PoC finding types

- documented behavior linked to changed code;
- changed code with no resolved document link (`UNKNOWN` unless document scope is complete);
- documented claim with no resolved code link (`UNRESOLVED`, not “not implemented”);
- code/document contradiction;
- ambiguous candidate link requiring review;
- approved link made stale by source revision;
- approved/qualified knowledge relevant to the change.

## 5. Claim states

| State | Meaning |
|---|---|
| `SUPPORTED` | Evidence supports the claim within declared scope |
| `DISPUTED` | Evidence conflicts |
| `UNKNOWN` | Required evidence/source/resolution is missing, stale or partial |

No numeric default converts `UNKNOWN` into weak support. Link confidence and governance status are
reported separately.

## 6. Report contract

The report contains:

- context and source versions;
- changed code and impact summary;
- linked Confluence behaviors/documents;
- evidence-backed findings;
- unresolved/ambiguous/conflicting relationships;
- governance state and approval references;
- provider/source status and limitations;
- deterministic ranking explanation;
- recommended review/remediation;
- `human_release_decision=OPEN`.

`REPORT_COMPLETE` means every source relevant to the formed claims was current and applicable. It
does not mean the release is safe or approved.

## 7. Degradation

| Condition | Result |
|---|---|
| C1 unavailable for change request | `ANALYSIS_FAILED` |
| C2 source absent | Code-only `REPORT_PARTIAL` |
| C6 unavailable | `ANALYSIS_FAILED` for linked analysis; C1 native diagnostic may be shown separately |
| C7 unavailable | Use existing C6 edges; no new-link conclusion |
| C3 unavailable | Show last projected state with warning; no new decisions |
| Candidate/ambiguous link | Report as review item, not established fact |
| Stale approval | Report stale and request re-review |

## 8. Relationship to C8

C5 may deep-link a finding to the C8 inspection/review screen. C8 does not accept a release decision,
and C5 does not call `gov_record_decision` on behalf of the reviewer.

## 9. Independent tests

1. Code-only fixture produces useful `REPORT_PARTIAL`.
2. Linked fixture cites both code and Confluence evidence.
3. Ambiguous link is not rendered as fact.
4. Candidate and approved states are visibly distinct.
5. Stale approval triggers re-review recommendation.
6. Missing C2 cannot become “undocumented.”
7. C5 passes with all dependencies mocked.
8. Knowledge approval never changes `human_release_decision`.

## 10. Future extension

When C4/ADO/workflow/runtime providers arrive, C5 consumes their C6 edges and provider evidence
through new versioned capabilities. C5 does not gain ownership of their data or linking.
