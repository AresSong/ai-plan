# C4 — Test Knowledge Provider (Future Optional Component)

**Current PoC:** out of scope  
**Future role:** test inventory, assertion evidence, execution metadata and `VERIFIED_BY` proposals

## 1. Why this document remains

The current ten-day PoC ingests only Java 17 code and Confluence. C4 remains specified at the
boundary level so adding tests later does not change C6 ownership, C7 linking or C3 approval.

C4 is not required for current acceptance and no current report may claim `NOT_COVERED`.

## 2. Responsibility

When implemented, C4 will own:

- test/scenario inventory and source versions;
- glue/assertion evidence;
- bounded mappings from tests to code/behavior candidates;
- execution metadata imported from CI;
- evidence-backed proposals for `VERIFIED_BY` edges.

C4 will not own canonical behaviors, approved relationships, release decisions or C6 tables.

## 3. Absence semantics

Until a complete/current inventory exists:

- provider status is `OUT_OF_SCOPE` or `SOURCE_ABSENT`;
- coverage is `UNKNOWN`;
- C5 may recommend finding/adding tests but cannot state that coverage is missing;
- C1+C2+C6+C7+C8 remain independently usable.

`NOT_COVERED` is allowed only when the declared test scope is complete/current and no qualifying test
exists after deterministic/approved resolution.

## 4. Future contracts

- `test_status`
- `test_inventory`
- `test_get_case`
- `test_candidates_for`
- `test_execution_evidence`

Future candidate edges use `ekg_propose_subgraph` and the same evidence/governance lifecycle. C7 may
link test candidates, but C3 remains the only approval writer.

## 5. Future independent tests

1. C4 runs against a test-repository fixture with C1–C3/C5–C8 offline.
2. Missing inventory produces `UNKNOWN`, never `NOT_COVERED`.
3. Every proposed `VERIFIED_BY` edge cites test source/assertion evidence.
4. CI failure/pass is not confused with link approval.
5. Changed test source marks affected decisions stale.

## 6. Re-entry criterion

Move C4 into active scope only after the code+Confluence PoC has passed and a representative,
accessible test repository plus accountable reviewer are available.
