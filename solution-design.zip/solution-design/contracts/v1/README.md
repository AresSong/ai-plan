# Behavior Gap Analyzer contracts — v1

**Status:** pre-implementation PoC freeze  
**Scope:** Java 17 code, Confluence, persistent EKG, manual knowledge approval

This is the canonical contract between independently deployable components. Tool-specific schemas
from Grafel, SCIP, OpenKB or `llm_wiki` are never exposed to consumers.

## 1. Compatibility

- URI prefix: `/contracts/v1` or equivalent message schema namespace.
- Additive optional fields are backward compatible.
- Removing/renaming a field, changing enum meaning or weakening evidence requirements needs v2.
- Consumers reject unknown major versions and record a typed compatibility error.
- Every provider publishes fixture bundles before joining the PoC.
- All write requests require `idempotency_key`; all responses include `correlation_id`.

## 2. Analysis context

```json
{
  "analysis_id": "urn:analysis:<uuid>",
  "base_revision": "<full-sha-or-null>",
  "head_revision": "<full-sha-or-null>",
  "confluence_scope": [{"site":"design","page_id":"12345","version":17}],
  "as_of": "2026-08-25T00:00:00Z",
  "environment": "poc",
  "contract_version": "v1"
}
```

Code change analysis requires base/head. Document inspection may omit them. Linked inspection pins
both code and document versions.

## 3. Universal response envelope

```json
{
  "ok": true,
  "correlation_id": "<uuid>",
  "provider_status": {
    "provider": "C2",
    "state": "AVAILABLE",
    "as_of": "2026-08-25T00:00:00Z",
    "source_revision": "confluence:design:12345:v17",
    "warnings": []
  },
  "data": {},
  "errors": []
}
```

Provider states: `AVAILABLE`, `PARTIAL`, `STALE`, `SOURCE_ABSENT`, `OUT_OF_SCOPE`, `UNAVAILABLE`.
An empty result is data, not a failure state.

## 4. EvidenceRef

```json
{
  "evidence_id": "urn:evidence:<uuid>",
  "source_kind": "CONFLUENCE",
  "source_urn": "urn:confluence:design:page:12345:v:17",
  "locator": {"heading":"4.2","span_id":"heading-4.2-p2"},
  "content_hash": "sha256:<hex>",
  "observed_at": "2026-08-25T00:00:00Z",
  "mechanism": "OPENKB_CLAIM_EXTRACTION",
  "producer": "c2-openkb-adapter",
  "producer_version": "<pinned-version>",
  "transformation": {
    "model": "<model-or-null>",
    "prompt_version": "<version-or-null>"
  }
}
```

`source_urn`, locator, hash and producer version are mandatory. Evidence is immutable.

## 5. Canonical entities and edges

```json
{
  "entity_urn": "urn:behavior:settlement:block-non-stp",
  "entity_type": "BEHAVIOR",
  "label": "Block non-STP settlement",
  "provider_refs": ["urn:candidate:entity:<uuid>"],
  "evidence_refs": ["urn:evidence:<uuid>"],
  "valid_from": "2026-08-25T00:00:00Z",
  "valid_to": null
}
```

```json
{
  "edge_urn": "urn:candidate:edge:<uuid>",
  "subject_urn": "urn:behavior:settlement:block-non-stp",
  "predicate": "IMPLEMENTED_BY",
  "object_urn": "urn:code:payments-service:java:method:com.bank.SettlementValidator.validate",
  "mechanism": "EXPLICIT_SYMBOL_PLUS_SEMANTIC_CONFIRMATION",
  "confidence": 0.93,
  "resolution_state": "RESOLVED",
  "governance_state": "CANDIDATE",
  "evidence_refs": ["urn:evidence:<doc>", "urn:evidence:<code>"],
  "version": 1
}
```

Allowed v1 predicates: `DESCRIBES`, `IMPLEMENTS`, `PARTIALLY_IMPLEMENTS`, `CONTRADICTS`,
`RELATED_TO`, `CALLS`, `DEPENDS_ON`. `VERIFIED_BY` is reserved for future C4.

Resolution states: `RESOLVED`, `AMBIGUOUS`, `UNRESOLVED`, `CONFLICT`.

## 6. C1 Code Intelligence

| Operation | Request | Response |
|---|---|---|
| `code_status` | `AnalysisContext` | tool/index version, source revision, provider state |
| `code_changed_entities` | context + limits | normalized `CodeEntityRef[]`, change kind, evidence |
| `code_get_entity` | context + code URN | entity detail and source evidence |
| `code_impact_paths` | context + seeds + depth/node limits | bounded typed paths and evidence |
| `code_resolve_ref` | context + symbol/path hints | exact/ambiguous/unresolved candidates |
| `code_compare_backends` | context + entity set | Grafel/SCIP observed differences; PoC diagnostic |

C1 owns detailed code relationships. It may submit selected anchors to C6 but cannot create approved
business relationships.

## 7. C2 Confluence Knowledge Compiler

| Operation | Request | Response |
|---|---|---|
| `doc_status` | context | Confluence/OpenKB state and pinned versions |
| `doc_snapshot` | site/page/version | immutable metadata/content hash and span index |
| `doc_compile` | context + snapshot refs | candidate claims/entities with evidence |
| `doc_get_candidate` | candidate URN/version | compiled detail and exact source evidence |
| `doc_lint` | context + scope | orphan, contradiction, broken-span and stale findings |

C2 emits document-local candidates. It does not resolve canonical cross-domain identity.

## 8. C6 Enterprise Knowledge Graph

| Operation | Request | Response |
|---|---|---|
| `ekg_status` | context | graph/schema version, partition freshness and counts |
| `ekg_propose_subgraph` | context + idempotency key + entities/edges/evidence | accepted/rejected items and versions |
| `ekg_resolve_entities` | context + source refs/aliases | canonical, ambiguous or unresolved results |
| `ekg_query_subgraph` | context + seeds + predicates + depth/node limits | bounded nodes/edges/evidence/status |
| `ekg_get_context` | context + entity URNs + size budget | evidence-bearing context bundle |
| `ekg_apply_status_projection` | signed C3 decision projection | projected state/version or conflict |

Only C6 owns canonical cross-domain edges. Proposal acceptance means schema/evidence acceptance, not
human approval.

## 9. C7 Knowledge Linker

| Operation | Request | Response |
|---|---|---|
| `link_status` | context | rules/model/index versions and provider state |
| `link_candidates` | context + code/document candidate refs | candidate edges with alternatives/evidence |
| `link_explain` | edge candidate URN/version | features, mechanism, confidence and evidence |

C7 must evaluate deterministic tiers before semantic matching. It cannot call C3 decision writes.

## 10. C3 Governance

| Operation | Request | Response |
|---|---|---|
| `gov_create_packet` | context + candidate versions + evidence-set hash | immutable review packet |
| `gov_list_review_items` | filters + pagination | packet/item summaries |
| `gov_get_review_packet` | packet URN/version | frozen candidates, evidence and history |
| `gov_record_decision` | packet/item version + reviewer + decision + rationale + idempotency key | immutable decision and projection event |
| `gov_get_decision_history` | candidate/item URN | ordered immutable history |
| `gov_mark_stale` | prior decision + changed evidence hash | stale decision projection |

PoC decisions: `APPROVED`, `APPROVED_WITH_QUALIFICATION`, `REJECTED`,
`NEEDS_CLARIFICATION`. The mechanism is `POC_MANUAL_REVIEW`.

## 11. C8 Review Workbench

| Operation | Behavior |
|---|---|
| `inspect_code` | Composes C1 detail with C6 relationships |
| `inspect_document` | Composes C2 detail with C6 relationships |
| `inspect_link` | Resolves both evidence sides for one C6 edge |
| `submit_decision` | Calls C3 only after evidence-hash concurrency check |
| `export_approval_pack` | Renders frozen C3/C6 data to Markdown and JSON |

C8 has no database-write contract. Export does not create or change a decision.

## 12. C5 report

```json
{
  "report_id": "urn:report:<uuid>",
  "report_status": "REPORT_PARTIAL",
  "provider_status": [],
  "findings": [],
  "limitations": [],
  "recommendation": "REVIEW_LINKED_KNOWLEDGE",
  "human_release_decision": "OPEN"
}
```

Only missing/unusable C1 code for a requested change analysis produces `ANALYSIS_FAILED`. C5 never
maps knowledge approval to release approval.

## 13. Ownership registry

| Component | Required in current PoC | Owns |
|---|---:|---|
| C1 | Yes | Detailed Java code graph and impact evidence |
| C2 | Yes for document/linked demo | Confluence snapshots and compiled document candidates |
| C3 | Yes | Manual decision system of record |
| C4 | No | Future test knowledge |
| C5 | Yes | Findings/report/run ledger |
| C6 | Yes | Canonical EKG entities and cross-domain edges |
| C7 | Yes | Candidate linking computation/explanation |
| C8 | Yes | Stateless/session UI and approval-pack rendering |

## 14. Minimum conformance profiles

1. code-only inspection and partial report;
2. document-only inspection;
3. linked inspection with both evidence sides;
4. ambiguous candidate without forced resolution;
5. each of the four manual decisions;
6. stale decision after code revision;
7. stale decision after Confluence revision;
8. approval Markdown/JSON equivalence;
9. Grafel and SCIP normalized through the same C1 contract;
10. each component against fixtures with dependencies offline.
