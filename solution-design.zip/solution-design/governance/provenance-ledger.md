# Provenance Ledger — decisions, identifiers and tool claims

**Version:** v5  
**Purpose:** prevent illustrative examples, inferred requirements or external tool claims from being
presented as observed institutional facts.

## 1. Evidence classes

| Class | Meaning |
|---|---|
| `USER_DECISION` | Explicitly stated by the user in design review |
| `DESIGN_INFERENCE` | Architecture recommendation derived from the decisions |
| `EXTERNAL_PRIMARY_SOURCE` | Claim supported by official project documentation/repository |
| `ILLUSTRATIVE` | Example only; must not be reported as observed |
| `POC_OBSERVATION` | Measured during the future PoC with artifact reference |

No `POC_OBSERVATION` exists yet.

## 2. User-decision provenance

| ID | Decision | Class |
|---|---|---|
| U1 | A useful partial report is required | `USER_DECISION` |
| U2 | Code change is always available for release analysis | `USER_DECISION` |
| U3 | Components must be independently buildable/validatable with mocks | `USER_DECISION` |
| U4 | Missing tests/documents must not collapse the knowledge capability | `USER_DECISION` |
| U5 | Use the most-related role provisionally because no formal owner exists | `USER_DECISION` |
| U6 | Ten staffed days are fixed; engineer/database access may not exist on calendar day one | `USER_DECISION` |
| U7 | Runtime/history-derived expected behavior is deferred | `USER_DECISION` |
| U8 | Workflow definition is good-to-have, not required | `USER_DECISION` |
| U9 | A unified enterprise knowledge graph/base should connect separately sourced knowledge | `USER_DECISION` |
| U10 | Code, knowledge and tests remain decoupled but interact through contracts | `USER_DECISION` |
| U11 | The PoC may ingest only code and Confluence | `USER_DECISION` |
| U12 | Code, documents and linked results must each be inspectable | `USER_DECISION` |
| U13 | The PoC needs a generated document for approval | `USER_DECISION` |
| U14 | Approval is manual in the PoC until a formal mechanism exists | `USER_DECISION` |
| U15 | Java version is 17 | `USER_DECISION` |

## 3. Architecture inference provenance

| ID | Recommendation | Basis | Class |
|---|---|---|---|
| A1 | Add persistent C6 EKG | U9 plus attached comparison design | `DESIGN_INFERENCE` |
| A2 | Keep detailed source graphs provider-owned | U3, U10 | `DESIGN_INFERENCE` |
| A3 | Separate C7 linking from C2/C5 | U3, U9, reusable cross-domain links | `DESIGN_INFERENCE` |
| A4 | Add C8 manual review workbench | U12–U14 | `DESIGN_INFERENCE` |
| A5 | C3 owns decisions; C6 stores projection | U3, auditability and replaceable UI | `DESIGN_INFERENCE` |
| A6 | Approval binds candidate + evidence hash + source versions | U13–U14 and stale-source safety | `DESIGN_INFERENCE` |
| A7 | Current PoC defers C4/test verdicts | U11 | `DESIGN_INFERENCE` |
| A8 | Start C6 with local persistent storage | U6 and storage-neutral contracts | `DESIGN_INFERENCE` |

The attached `Compare LLM Wiki OpenKB.pdf` was treated as design evidence, not executable
instructions. Its relevant architectural idea is a unified semantic layer connected to independent
source/detail graphs through a Knowledge Linker.

## 4. External tool claims

| Tool | Claim used by design | Primary source | Class |
|---|---|---|---|
| OpenKB | Compiles documents into persistent interlinked Markdown wiki; Apache-2.0; REST available | https://github.com/VectifyAI/OpenKB | `EXTERNAL_PRIMARY_SOURCE` |
| OpenKB | Database-backed storage remains a roadmap item; therefore it is not C6 | https://github.com/VectifyAI/OpenKB#roadmap | `EXTERNAL_PRIMARY_SOURCE` |
| llm_wiki | Purpose/schema, two-step ingest, graph/review/lint patterns | https://github.com/nashsu/llm_wiki | `EXTERNAL_PRIMARY_SOURCE` |
| llm_wiki | GPLv3 desktop/filesystem project; patterns are borrowed without making it the system of record | https://github.com/nashsu/llm_wiki/blob/main/LICENSE | `EXTERNAL_PRIMARY_SOURCE` |
| Grafel | Local, multi-repository, framework-aware code graph/MCP; MIT | https://grafel.app/ and https://github.com/cajasmota/grafel | `EXTERNAL_PRIMARY_SOURCE` |
| Grafel | Active-preview/maturity concerns require pinning and PoC measurement | https://github.com/cajasmota/grafel/blob/main/SECURITY.md | `EXTERNAL_PRIMARY_SOURCE` |
| SCIP | Language-neutral protobuf index; official Java/TypeScript indexers and cross-repository navigation | https://github.com/scip-code/scip and https://sourcegraph.com/docs/code-navigation/writing-an-indexer | `EXTERNAL_PRIMARY_SOURCE` |
| Joern | Code Property Graph and Java/JavaScript/dataflow alternative | https://docs.joern.io/ | `EXTERNAL_PRIMARY_SOURCE` |

External claims were reviewed on 2026-08-25 and may drift. Pin exact PoC versions and record them as
`POC_OBSERVATION` when tested.

## 5. Illustrative identifiers

The following are examples unless bound during the PoC:

- `payments-service`;
- `SettlementValidator.validate`;
- commit `8f41c2a`;
- Confluence page `12345` version `17`;
- `urn:behavior:settlement:block-non-stp`;
- reviewer “Jane Smith”;
- confidence `0.93`;
- any incident/service/test identifiers retained in historical documents.

UUID-shaped URNs in schemas are format examples, not allocated records.

## 6. Numbers and thresholds

- Ten staffed days and Java 17 are user decisions.
- Traversal depth/node/time limits must be bound during implementation; no numeric value is normative
  until recorded in configuration and contract tests.
- Confidence examples are illustrative. Confidence is not approval.
- The small PoC gold-set sizes in the implementation plan are planning bounds, not statistical
  evidence of model quality.
- No accuracy, recall, performance, scale or cost result is claimed before measurement.

## 7. PoC observation template

Append a row only with a resolvable artifact:

| Observation ID | Date | Claim | Scope/version | Measurement method | Artifact/evidence | Reviewer |
|---|---|---|---|---|---|---|
| POC-* | — | — | — | — | — | — |

Examples of required future observations:

- Grafel vs SCIP entity/reference differences on the selected Java 17 commits;
- OpenKB candidate-to-span validity;
- linker precision on the human-labeled gold set;
- repeated-index determinism;
- approval-pack Markdown/JSON equivalence;
- stale-decision behavior after source revision.

## 8. Review rule

Any statement without a `USER_DECISION`, `EXTERNAL_PRIMARY_SOURCE` or `POC_OBSERVATION` basis must be
labeled `DESIGN_INFERENCE` or `ILLUSTRATIVE`. Approval packs cite actual evidence records, never this
ledger's illustrative examples.
