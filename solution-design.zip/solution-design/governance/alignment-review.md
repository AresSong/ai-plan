# Alignment Review — Final v5 Decisions

**Status:** current architectural decision record  
**Scope:** Java 17 code + Confluence PoC, persistent enterprise graph, manual knowledge approval

## 1. User decisions applied

| User decision | Design consequence |
|---|---|
| A partial result must help a human decide | Code and document partitions are independently inspectable; dependent conclusions become `UNKNOWN` |
| Code change is always available for release analysis | C1 is required for change-impact analysis |
| Components must be independently buildable and mockable | Every runtime component owns its lifecycle and publishes fixtures/contracts |
| Knowledge sources may be missing | `SOURCE_ABSENT` is distinct from `UNAVAILABLE`; no absence is converted into a negative fact |
| Unified enterprise knowledge is required | C6 persistently owns canonical cross-domain identities and edges |
| Code, knowledge and tests must remain decoupled | Detailed source graphs stay provider-owned; only selected anchors and typed links enter C6 |
| PoC may ingest only code and Confluence | C1+C2+C6+C7+C8 are the knowledge path; C4 and delivery/runtime providers are future extensions |
| Each source and linked result must be inspectable | C8 exposes code-only, document-only and linked views |
| Generated knowledge needs approval | C3 stores item-level manual decisions; C8 exports a frozen approval pack |
| Formal approval workflow does not yet exist | PoC uses `POC_MANUAL_REVIEW`, clearly labeled non-formal |
| No official accountable owner exists | Most-related role is provisional; actual reviewer and rationale are mandatory |
| Ten staffed days are fixed | Scope is one vertical slice; database/DBA access is not a day-one prerequisite |
| Java version is 17 | SCIP is contract-compatible, but a live comparison requires a separately acquired and pinned Java indexer |

## 2. Correction from v4

| v4 position | Problem | v5 resolution |
|---|---|---|
| Unified knowledge was a C5 query-time view | Cross-domain links were transient and not reusable or independently reviewable | C6 persists canonical identities, cross-domain edges and evidence bindings |
| C5 performed all provider correlation | The analyzer became the integration architecture | C7 links; C6 stores/queries; C5 consumes |
| C2 compiled and linked knowledge | Document processing and enterprise entity resolution could not evolve independently | C2 compiles documents; C7 owns cross-domain linking |
| Governance existed without a concrete PoC interface | Review was conceptually correct but not demonstrable | C8 provides a manual inbox, side-by-side evidence and item-level decisions |
| Approval document was unspecified | A human could not freeze what was reviewed | C8 exports Markdown plus JSON with hashes, versions and decision history |
| PoC centered on test-gap coverage | It exceeded the available source scope | Current PoC proves code/document inspection and linkage; C4 is future optional |

## 3. Final component boundaries

| Component | Owns | Does not own |
|---|---|---|
| C1 Code Intelligence | Detailed code graph, change surface and impact evidence | Business truth or approved links |
| C2 Confluence Knowledge Compiler | Source snapshots and document-local candidate knowledge | Canonical enterprise identity or approval |
| C3 Knowledge Governance | Review packets, decisions, history and provisional roles | Source content or graph traversal |
| C4 Test Knowledge | Future test inventory and verification evidence | Current PoC acceptance |
| C5 Analyzer | Evidence-backed findings and reports | Canonical graph, linking or approval |
| C6 Enterprise Knowledge Graph | Canonical anchors, cross-domain edges, provenance bindings and status projection | Detailed provider-native records |
| C7 Knowledge Linker | Entity resolution and candidate link generation | Approval or source-of-truth mutation |
| C8 Review Workbench | Inspection UI and approval-pack rendering | Decision authority or direct database writes |

## 4. Approval semantics

- Approval applies to one candidate entity/edge version and its frozen evidence set.
- Allowed PoC decisions are `APPROVED`, `APPROVED_WITH_QUALIFICATION`, `REJECTED`, and
  `NEEDS_CLARIFICATION`.
- Only a named human can make those decisions. The AI may propose text or links.
- Source or evidence changes create a new version and mark the previous decision `STALE`; history is
  never overwritten.
- The manual UI is not an electronic-signature or formal institutional approval system.
- Knowledge approval and human release approval remain separate.

## 5. Tool decisions for the PoC

| Concern | Decision |
|---|---|
| Java 17 code graph | Trial Grafel JSON import behind C1; compare with SCIP only when a pinned Java indexer is available, otherwise use SCIP fixtures |
| Confluence compilation | Trial OpenKB behind C2; add claim-level provenance in the adapter |
| Wiki patterns | Borrow `llm_wiki` purpose/schema, two-stage ingest, review and lint patterns without adopting it as the system of record |
| Graph persistence | Keep the C6 contract storage-neutral; begin with a local implementation if managed infrastructure is delayed |

## 6. Final verdict

The v5 design follows the clarified intent: providers are independently operable, while one persistent
logical enterprise graph makes their shared meaning reusable. The ten-day PoC is realistic only if it
stays on a narrow Java 17 + Confluence slice and treats formal workflow integration, tests, delivery
metadata and runtime behavior as later capabilities.
