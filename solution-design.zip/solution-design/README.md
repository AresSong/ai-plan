# Behavior Gap Analyzer — design package

This package defines a contract-bound knowledge system for inspecting Java 17 code, Confluence
knowledge, and the evidence-backed relationships between them. The ten-day PoC also provides a
manual review interface and generates an immutable knowledge approval pack.

The PoC has two ingest sources:

- **required for change analysis:** Java 17 repositories;
- **optional:** selected Confluence spaces/pages.

Tests, Azure DevOps delivery metadata, workflow definitions and runtime-history mining remain future
providers. Their absence does not prevent code inspection or a useful partial result.

## Read in this order

| # | File | Purpose |
|---|---|---|
| 1 | `components/00-shared-foundation.md` | Normative boundaries, ownership, evidence and approval rules |
| 2 | `contracts/v1/README.md` | Canonical v1 contracts and provider states |
| 3 | `architecture/solution-design.md` | End-to-end architecture and rationale |
| 4 | `implementation/ten-day-plan.md` | Ten staffed-day PoC plan |
| 5 | `components/c1…c8` | Independently testable component designs |
| 6 | `governance/provenance-ledger.md` | Provenance of decisions, identifiers and tool claims |
| 7 | `governance/alignment-review.md` | Review history and resolved design gaps |
| 8 | `architecture/diagrams/c4-context.md` | C4 system context |
| 9 | `architecture/diagrams/c4-containers.md` | C4 container architecture |
| 10 | `templates/knowledge-approval-pack.md` | Canonical human-readable PoC approval-pack template |
| 11 | `implementation/poc/README.md` | Detailed coding-agent handoff: adapters, contracts, configuration and verification gates |

Precedence when documents disagree:

1. `contracts/v1/README.md` for interface behavior;
2. `components/00-shared-foundation.md` for ownership and evidence semantics;
3. the top-level solution design;
4. component documents;
5. worked examples.

## Binding design decisions

- C6 is a persistent **Enterprise Knowledge Graph (EKG)**. It owns canonical enterprise identities,
  cross-domain relationships, provenance bindings, validity and governance-status projections.
- Providers retain source-native detail in their own stores. The EKG stores selected anchors and
  references, not every AST node or Confluence token.
- C7 links code and documents through a versioned contract. It proposes evidence-backed candidates;
  it does not silently create approved facts.
- C5 is a consumer of the EKG, not the only integration point.
- C1, C2, C3, C5, C6, C7 and C8 can be built and validated independently using checked-in fixtures.
- No component reads, writes, migrates or installs triggers in another component's datastore.
- Code-only and document-only inspection are supported. Linked inspection is available when both
  partitions contain resolvable evidence.
- Missing Confluence produces `SOURCE_ABSENT`/`UNKNOWN`, not evidence that documentation does not
  exist. Missing code prevents change-impact analysis but not inspection of compiled documents.
- OpenKB is evaluated behind C2. `llm_wiki` supplies design patterns, not the system of record.
- Grafel JSON import is the live C1 PoC path. SCIP remains a replaceable comparison adapter, but its
  live Java path is a time-boxed option because the checked-in reference contains the protocol rather
  than a `scip-java` indexer.
- C8 provides temporary manual approval. Approval applies to an exact candidate version and evidence
  set. It is knowledge/link approval, not formal institutional or release approval.
- Until formal ownership exists, the most-related role is recorded as provisional along with the
  actual reviewer and rationale.
- The ten-day clock begins when a core engineer and repository access are available. A managed
  database or DBA is not required on staffed day one.

## PoC inspection and approval outcomes

A reviewer must be able to:

1. inspect code entities and impact relationships without Confluence;
2. inspect Confluence source and compiled knowledge without code links;
3. inspect linked code and document evidence side by side;
4. approve, qualify, reject or request clarification for each candidate entity or edge;
5. generate a versioned Markdown approval pack plus a machine-readable JSON record;
6. see stale approvals after either the code commit or Confluence version changes; and
7. distinguish evidence completeness, knowledge approval and human release decisions.

## Non-authoritative material

Documents under `archive/` are historical/reference material. Their headers mark them superseded.
Images under `assets/source-images/` are source/reference material and are not normative
specifications.

## Provenance warning

Incident identifiers, repository/service names, scores and statistical examples are illustrative
unless the provenance ledger explicitly binds them to real evidence. They must not be presented as
observed PoC results.
