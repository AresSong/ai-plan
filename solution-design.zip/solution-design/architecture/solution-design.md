# Behavior Gap Analyzer — Solution Design

**Version:** v5  
**PoC scope:** Java 17 code + Confluence  
**Time box:** ten staffed days  
**Decision:** persistent unified enterprise graph with independently deployable providers

## 0. Executive decision

The PoC will ingest code and Confluence separately, preserve each source's detailed representation,
and project selected entities plus evidence-backed relationships into a persistent Enterprise
Knowledge Graph (EKG). A reviewer can inspect code, documents and linked results independently, make
item-level manual decisions, and export a frozen approval pack.

This is not a single shared source database. It is a logical knowledge fabric:

- C1 and C2 own source-native detail;
- C6 owns canonical enterprise identity and cross-domain relationships;
- C7 proposes relationships through contracts;
- C3 records human decisions;
- C8 presents evidence and generates approval artifacts;
- C5 consumes the same graph for behavior-gap reporting.

## 1. Problem and PoC outcome

Code, requirements and design knowledge often live in separate systems with different names,
versions and owners. Reviewers cannot reliably answer:

1. What does this code do and what may a change affect?
2. What does the Confluence design say?
3. Which code entities implement or contradict the documented behavior?
4. What evidence supports each relationship?
5. Has a human reviewed the generated knowledge?

The PoC proves one vertical slice from a real Java 17 change and selected Confluence pages. It does
not prove enterprise-wide ingestion, test coverage or runtime behavior mining.

## 2. Principles

1. **Independent providers, shared semantics.** A component can run against checked-in fixtures and
   owns its datastore, deployment and credentials.
2. **Persistent unification.** Cross-domain identities and links survive an analyzer run in C6.
3. **Evidence before inference.** Every candidate edge cites immutable code/document evidence.
4. **Candidate before approved.** AI and deterministic linkers propose; a human decides.
5. **Source absence is explicit.** Missing Confluence yields `SOURCE_ABSENT`, never “no documentation.”
6. **No cross-database coupling.** Components integrate through versioned APIs/events only.
7. **Temporal correctness.** Code commit, Confluence version and `as_of` are pinned.
8. **Tool replaceability.** OpenKB, Grafel and SCIP remain behind provider-neutral contracts.
9. **Useful partial results.** Code-only and document-only inspection remain available.
10. **Approval is scoped.** PoC manual approval is not formal institutional or release approval.

## 3. Architecture

```mermaid
flowchart LR
    Git[Java 17 repositories] --> C1[C1 Code Intelligence]
    Conf[Confluence] --> C2[C2 Knowledge Compiler]
    C1 --> C7[C7 Knowledge Linker]
    C2 --> C7
    C1 --> C6[(C6 Enterprise Knowledge Graph)]
    C2 --> C6
    C7 -->|candidate entities and edges| C6
    C6 --> C8[C8 Review Workbench]
    C8 -->|decision command| C3[C3 Governance]
    C3 -->|status projection| C6
    C8 --> Pack[Markdown + JSON approval pack]
    C6 --> C5[C5 Behavior Gap Analyzer]
    C1 -->|detail drill-down| C5
    C2 -->|source drill-down| C5
```

C4 Test Knowledge is a future optional provider. ADO delivery metadata, workflow definitions and
runtime history are also future adapters. Their schemas must use the same C6 contract when added.

## 4. Runtime components

| Component | Required for current PoC? | Responsibility | Independent fixture |
|---|---:|---|---|
| C1 Code Intelligence | Yes | Java 17 symbols, relations, change surface, impact paths and source evidence | Small Java repositories and normalized Grafel/SCIP responses |
| C2 Confluence Knowledge Compiler | Yes for linked/doc demo | Versioned page snapshots and candidate document knowledge | Exported Confluence pages and compiled fixtures |
| C3 Knowledge Governance | Yes | Review packet, item decisions, history and stale transitions | Candidate/evidence bundles |
| C4 Test Knowledge | No | Future verification/test evidence | Test inventory fixtures |
| C5 Behavior Gap Analyzer | Yes | Findings and evidence-linked partial report | C6 subgraphs and provider drill-down fixtures |
| C6 Enterprise Knowledge Graph | Yes | Canonical anchors, edges, provenance, validity and status projection | Provider-neutral subgraphs |
| C7 Knowledge Linker | Yes | Deterministic resolution and semantic candidate links | Positive, negative and ambiguous pairs |
| C8 Review Workbench | Yes | Code/doc/linked inspection, manual decisions and approval-pack export | Mock C1/C2/C3/C6 APIs |

## 5. Ownership model

| Information | System of record |
|---|---|
| Git content and commit history | Repository platform |
| Detailed code graph | C1 |
| Confluence content/version metadata | Confluence plus immutable C2 snapshot |
| Compiled document-local concepts/claims | C2 |
| Canonical `CodeEntityRef`, `DocumentRef`, `Behavior` and `Rule` | C6 |
| `IMPLEMENTS`, `DESCRIBES`, `CONTRADICTS`, `RELATED_TO` | C6 |
| Link-generation mechanism and confidence | C7 evidence stored with the C6 edge |
| Review packet and decision history | C3 |
| Approval pack rendering | C8 |
| Behavior-gap findings and recommendation | C5 |

C6 stores selected anchors and provider references. It does not duplicate full ASTs, full pages or
provider-specific indexes.

## 6. Inspection modes

### 6.1 Code-only

The reviewer can navigate changed code, callers, dependencies, endpoints and source spans. C6 returns
known enterprise links; unresolved document coverage is `UNKNOWN` if C2 is absent or partial.

### 6.2 Document-only

The reviewer can inspect a Confluence snapshot, source headings/spans, compiled claims, conflicts and
candidate entities. Code linkage is `UNKNOWN` if C1 is absent for that inspection context.

### 6.3 Linked code and document

The reviewer sees document evidence, proposed relationship and code evidence side by side. Every
edge shows mechanism, confidence, status, source versions and decision history.

## 7. End-to-end flow

1. Create an `AnalysisContext` with repository base/head, Confluence scope/version and `as_of`.
2. C1 indexes Java 17 code through pinned Grafel JSON import and emits normalized anchors/evidence;
   an independently replaceable SCIP adapter is fixture-backed unless a pinned Java indexer is acquired.
3. C2 snapshots selected Confluence pages and compiles document-local candidate knowledge through
   OpenKB or its fixture implementation.
4. C1 and C2 independently propose their anchors to C6.
5. C7 applies deterministic identifiers first, then semantic matching for unresolved candidates.
6. C7 submits candidate cross-domain edges to C6 with evidence and ambiguity state.
7. C8 presents code-only, document-only and linked views.
8. A named human approves, qualifies, rejects or requests clarification for individual items.
9. C3 stores the immutable decision and projects the status to C6.
10. C8 exports a frozen Markdown approval pack and JSON manifest.
11. C5 queries the reviewed graph and provider evidence to produce a partial behavior-gap report.

## 8. Linking policy

Resolution order:

1. explicit source identifier or URL;
2. exact package-qualified symbol or repository/path anchor;
3. stable structural identifier, such as endpoint or configuration key;
4. terminology/alias mapping;
5. semantic candidate match.

Tiers 1–3 may be high-confidence candidates but still require review for business relationships.
Tier 5 is never silently promoted. Ambiguous results remain `UNRESOLVED` with alternatives.

## 9. Manual knowledge approval

PoC decisions:

- `APPROVED`;
- `APPROVED_WITH_QUALIFICATION`;
- `REJECTED`;
- `NEEDS_CLARIFICATION`.

The UI does not edit source evidence. A correction creates a new candidate version. Rejection or
qualification requires rationale. The record includes actual reviewer, provisional most-related
role, timestamp and approval mechanism `POC_MANUAL_REVIEW`.

Approval is bound to:

```text
candidate version + code commit + Confluence page version + evidence-set hash
```

Any changed input creates a new candidate or marks the prior projection `STALE`. Previous decisions
remain queryable.

## 10. Approval pack

The pack contains:

1. scope and source versions;
2. proposed knowledge statements;
3. exact Confluence evidence;
4. exact code evidence;
5. proposed relationships and mechanisms;
6. detected gaps, ambiguity and conflicts;
7. item-level decisions, reviewer and rationale;
8. provider/contract/model versions and hashes;
9. a statement that the pack is PoC manual knowledge approval, not formal release approval.

Markdown is the canonical human-readable PoC artifact; JSON is the canonical machine record. PDF is
an optional rendering of the frozen Markdown.

## 11. Degradation behavior

| Condition | Inspection/report behavior |
|---|---|
| C1 available; C2 absent | Code inspection works; document and linked conclusions `UNKNOWN`; partial report |
| C2 available; C1 unavailable | Document inspection works; change-impact analysis fails for that context |
| C1 and C2 available; no link resolves | Both views work; linked view shows `UNRESOLVED`, not “unrelated” |
| C7 unavailable | Existing graph remains inspectable; no new links are asserted |
| C3 unavailable | Candidates remain inspectable; approval controls are disabled |
| C8 unavailable | APIs and stored knowledge remain available; no UI/export |
| C6 unavailable | Provider-native inspection may continue; linked inspection and graph-based analysis fail |
| Stale code/document index | Evidence is displayed with `STALE`; no unqualified approval |

## 12. Security and audit

- Use synthetic, public or specifically approved content for the PoC.
- Prefer institution-controlled model endpoints; cloud document processing requires separate approval.
- C8 never receives provider database credentials.
- C3 is the only writer of decisions; C7 cannot approve.
- Every mutation carries actor/service identity, timestamp, idempotency key and correlation ID.
- Evidence is immutable and content-addressed; source deletions create tombstones.
- Formal SSO, electronic signatures, segregation-of-duties enforcement, retention and legal hold are
  production requirements, not claims of the PoC.

## 13. PoC acceptance matrix

| Profile | Required outcome |
|---|---|
| Code only | Inspect changed Java entities and impact; useful partial report |
| Confluence only | Inspect source snapshot and compiled candidate knowledge |
| Code + Confluence | Inspect evidence-backed candidate links |
| Ambiguous match | No forced link; alternatives enter review |
| Manual decision | Item-level decision stored with reviewer, provisional role and rationale |
| Approval export | Frozen Markdown and JSON agree on item IDs, evidence and decisions |
| Source revision | Prior approval retained and current projection marked `STALE` |
| Backend replaceability | Grafel and SCIP fixtures satisfy the same provider contract; live SCIP differences are recorded when a Java indexer is available |
| Component isolation | Each current-PoC component passes against fixtures without another live component |

## 14. Future extensions

- C4 test inventory and `VERIFIED_BY` edges;
- ADO requirement/delivery providers;
- workflow-definition evidence;
- runtime behavior/history mining;
- formal institutional approval workflow;
- production IAM, audit retention, HA/DR and managed graph infrastructure.

These extensions add providers or consumers; they do not move canonical cross-domain ownership out of
C6 or approval authority out of C3.

## 15. Final decisions

| ID | Decision |
|---|---|
| D1 | Java 17 code and Confluence are the only current ingest sources |
| D2 | C6 is the persistent unified enterprise semantic layer |
| D3 | Detailed source graphs remain provider-owned |
| D4 | C7 owns cross-domain linking and never approves |
| D5 | C8 supports three inspection modes and manual item-level review |
| D6 | C3 stores immutable decisions; C6 carries their query projection |
| D7 | Grafel JSON import is the live code trial; SCIP is a contract-compatible, time-boxed comparison option |
| D8 | OpenKB is a C2 implementation candidate, not the enterprise system of record |
| D9 | Missing sources produce partial/unknown results rather than negative facts |
| D10 | Formal approval and test/runtime sources are deferred without changing contracts |
