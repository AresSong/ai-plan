# C4 Level 1 — System Context

This diagram shows the PoC boundary. Tests, ADO delivery metadata, runtime history and formal approval
workflow are future integrations.

```mermaid
C4Context
  title System Context - Behavior Gap Analyzer PoC

  Person(reviewer, "Knowledge Reviewer", "Inspects and manually decides candidate knowledge")
  Person(developer, "Developer or Technical Lead", "Investigates Java change impact")

  System(analyzer, "Behavior Gap Analyzer", "Connects code and Confluence knowledge with evidence and manual review")

  System_Ext(git, "Git Repositories", "Java 17 source and commit history")
  System_Ext(confluence, "Confluence", "Versioned design and requirement pages")
  System_Ext(formalApproval, "Formal Approval Workflow", "Future institutional approval mechanism")

  Rel(developer, analyzer, "Inspects code and linked impact", "HTTPS")
  Rel(reviewer, analyzer, "Reviews knowledge and exports approval pack", "HTTPS")
  Rel(analyzer, git, "Reads pinned source revisions", "Git/HTTPS")
  Rel(analyzer, confluence, "Reads selected page versions", "REST/HTTPS")
  Rel(formalApproval, analyzer, "Future decision integration", "Versioned API")
```

## Scope notes

- The PoC manual decision is knowledge/link approval, not a release decision.
- Git is required for change analysis; Confluence is optional for code-only inspection.
- The future formal workflow replaces manual decision entry without replacing the governance record
  or EKG contract.
