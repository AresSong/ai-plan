# C4 Dynamic — Manual Knowledge Approval

```mermaid
C4Dynamic
  title Dynamic Diagram - PoC Manual Knowledge Approval

  Person(reviewer, "Knowledge Reviewer", "Named human with provisional role")
  Container(c8, "C8 Review Workbench", "Web UI", "Displays evidence and captures decision")
  Container(c1, "C1 Code Intelligence", "Adapter Service", "Returns code evidence")
  Container(c2, "C2 Knowledge Compiler", "Adapter Service", "Returns Confluence evidence")
  Container(c6, "C6 Enterprise Knowledge Graph", "Graph API", "Returns candidate relationship")
  Container(c3, "C3 Governance", "Governance API", "Records immutable decision")
  Component(pack, "Approval Pack Renderer", "C8 module", "Renders Markdown and JSON")

  Rel(reviewer, c8, "1. Opens review item", "HTTPS")
  Rel(c8, c6, "2. Loads candidate edge and status", "JSON/HTTPS")
  Rel(c8, c1, "3. Resolves code evidence", "JSON/HTTPS")
  Rel(c8, c2, "4. Resolves document evidence", "JSON/HTTPS")
  Rel(reviewer, c8, "5. Selects decision and rationale", "HTTPS")
  Rel(c8, c3, "6. Submits item version and evidence hash", "JSON/HTTPS")
  Rel(c3, c6, "7. Projects decision status", "JSON/HTTPS")
  Rel(c8, pack, "8. Renders frozen approved packet", "In-process")
  Rel(pack, reviewer, "9. Delivers Markdown and JSON", "Download")
```

If the evidence hash changes between steps 2 and 6, C3 rejects the decision and C8 refreshes the
packet. Export failure never resubmits or duplicates the decision.
