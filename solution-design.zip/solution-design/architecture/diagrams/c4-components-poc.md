# C4 component diagram — local PoC application

**Status:** proposed component implementation

```mermaid
C4Component
title Behavior Gap Analyzer - local PoC components

Person(reviewer, "Reviewer", "Inspects evidence and records a non-formal item decision")

Container_Boundary(app, "BGA FastAPI application") {
  Component(ui, "Review Workbench", "FastAPI/Jinja2", "Code, document and linked views")
  Component(code, "Code Intelligence", "Python port/adapters", "Git change surface and normalized code graph")
  Component(doc, "Document Compiler", "Python port/adapters", "Pinned Confluence snapshots, spans and candidates")
  Component(linker, "Knowledge Linker", "Python", "Deterministic-first candidate links")
  Component(ekg, "EKG Service", "Python + SQLite", "Canonical identities and cross-domain edges")
  Component(gov, "Governance Service", "Python + SQLite", "Packets, immutable decisions and outbox")
  Component(report, "Reporting", "Python", "Partial report and Markdown/JSON approval pack")
}

System_Ext(git, "Git repository", "Pinned Java 17 source")
System_Ext(grafel, "Grafel", "Pinned daemon/CLI producing graph.json schema 1")
System_Ext(conf, "Confluence", "Selected page IDs and exact versions")
System_Ext(openkb, "OpenKB", "Pinned loopback REST service")
System_Ext(model, "Approved model endpoint", "Optional compiler/semantic model")

Rel(reviewer, ui, "Uses", "localhost HTTP")
Rel(ui, code, "Reads through port")
Rel(ui, doc, "Reads through port")
Rel(ui, ekg, "Reads through port")
Rel(ui, gov, "Creates decisions through port")
Rel(ui, report, "Requests export")
Rel(code, git, "Reads pinned revisions")
Rel(code, grafel, "Executes and imports versioned JSON")
Rel(doc, conf, "Reads pinned page versions")
Rel(doc, openkb, "Compiles normalized Markdown", "REST /api/v1")
Rel(openkb, model, "Calls when configured")
Rel(linker, code, "Reads anchors")
Rel(linker, doc, "Reads candidates")
Rel(linker, ekg, "Proposes evidence-bearing edges")
Rel(gov, ekg, "Projects decision status", "idempotent outbox")
Rel(report, code, "Resolves evidence")
Rel(report, doc, "Resolves evidence")
Rel(report, ekg, "Reads graph")
Rel(report, gov, "Reads frozen decisions")
```

The boxes are logical components in one process for the PoC. Relationships are port calls and remain
valid if components become deployable services later. SQLite files and artifact directories are
private implementation details and are never shared through direct reads.

