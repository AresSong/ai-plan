# C4 Level 2 — Container Architecture

Each container is independently testable through versioned contracts and fixtures. Provider databases
are private; no cross-database reads are allowed.

```mermaid
C4Container
  title Container Diagram - Behavior Gap Analyzer PoC

  Person(reviewer, "Knowledge Reviewer", "Reviews code-document knowledge")
  System_Ext(git, "Git Repositories", "Java 17 source")
  System_Ext(confluence, "Confluence", "Versioned pages")

  System_Boundary(bga, "Behavior Gap Analyzer") {
    Container(c1, "C1 Code Intelligence", "Adapter Service", "Normalizes Grafel/SCIP code evidence")
    Container(c2, "C2 Knowledge Compiler", "Adapter Service", "Snapshots and compiles Confluence knowledge")
    Container(c7, "C7 Knowledge Linker", "Linking Service", "Proposes evidence-backed cross-domain links")
    Container(c6, "C6 Enterprise Knowledge Graph", "Graph API", "Owns canonical identities and cross-domain edges")
    ContainerDb(c6db, "C6 Graph Store", "Local persistent PoC store", "Persists canonical graph and projections")
    Container(c3, "C3 Governance", "Governance API", "Owns review packets and decisions")
    ContainerDb(c3db, "C3 Governance Store", "Local persistent PoC store", "Append-only decisions and history")
    Container(c8, "C8 Review Workbench", "Web UI", "Provides inspection, manual review and approval export")
    Container(c5, "C5 Analyzer", "Analysis Service", "Produces evidence-linked findings and partial reports")
  }

  Rel(git, c1, "Supplies pinned Java source", "Git/HTTPS")
  Rel(confluence, c2, "Supplies selected page versions", "REST/HTTPS")
  Rel(c1, c7, "Supplies normalized code candidates", "JSON/HTTPS")
  Rel(c2, c7, "Supplies document candidates", "JSON/HTTPS")
  Rel(c1, c6, "Proposes selected code anchors", "JSON/HTTPS")
  Rel(c2, c6, "Proposes document anchors", "JSON/HTTPS")
  Rel(c7, c6, "Proposes candidate links", "JSON/HTTPS")
  Rel(c6, c6db, "Reads and writes graph", "Driver/API")
  Rel(c8, c6, "Queries bounded subgraphs", "JSON/HTTPS")
  Rel(c8, c1, "Reads code evidence", "JSON/HTTPS")
  Rel(c8, c2, "Reads document evidence", "JSON/HTTPS")
  Rel(reviewer, c8, "Inspects and decides", "HTTPS")
  Rel(c8, c3, "Submits manual decision", "JSON/HTTPS")
  Rel(c3, c3db, "Appends packet and decision", "SQL/API")
  Rel(c3, c6, "Projects governance status", "JSON/HTTPS")
  Rel(c5, c6, "Queries linked knowledge", "JSON/HTTPS")
  Rel(c5, c1, "Reads code drill-down evidence", "JSON/HTTPS")
  Rel(c5, c2, "Reads document drill-down evidence", "JSON/HTTPS")

  UpdateLayoutConfig($c4ShapeInRow="3", $c4BoundaryInRow="1")
```

## Deployment note

The diagram shows logical deployable boundaries, not a requirement for eight production services in
the ten-day PoC. Containers may run in one local process composition if their APIs, stores and
contract tests remain isolated.
