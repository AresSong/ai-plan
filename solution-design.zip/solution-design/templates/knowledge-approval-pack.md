---
pack_urn: "urn:review:<uuid>:v:<n>"
pack_status: "OPEN|COMPLETED"
approval_mechanism: "POC_MANUAL_REVIEW"
analysis_urn: "urn:analysis:<uuid>"
generated_at: "<ISO-8601>"
export_hash: "sha256:<hex>"
---

# Knowledge Approval Pack — <scope title>

> **PoC manual knowledge review.** This artifact records review of generated knowledge and
> code-document relationships. It is not formal institutional approval and does not approve a
> software release.

## 1. Scope and versions

| Source | Scope | Version/revision | Provider state |
|---|---|---|---|
| Java code | <repository> | <base SHA> → <head SHA> | <state> |
| Confluence | <site/page IDs> | <page versions> | <state> |
| EKG | <schema/graph version> | <as-of> | <state> |

Contract version: <v1>  
Grafel version: <version or not used>  
SCIP/indexer version: <version or not used>  
OpenKB/compiler/model/prompt versions: <versions or not used>

## 2. Executive summary

<Generated summary restricted to the reviewed evidence. State unknowns and ambiguity explicitly.>

## 3. Review-item register

| Item | Type | Proposed relationship/statement | Resolution | Decision | Reviewer |
|---|---|---|---|---|---|
| <URN/version> | <entity/edge> | <summary> | <state> | <decision> | <name, provisional role> |

## 4. Item evidence and decision

### <Item URN/version> — <short label>

**Proposed knowledge:** <statement or subject-predicate-object>  
**Mechanism/confidence:** <mechanism> / <confidence>  
**Resolution state:** <resolved/ambiguous/unresolved/conflict>

#### Confluence evidence

- Page: <title, URL, page ID, version>
- Span: <heading/paragraph/span ID>
- Evidence reference/hash: <URN/hash>
- Supported text or policy-compliant excerpt: <text>

#### Code evidence

- Repository/commit: <repository/full SHA>
- Entity: <canonical CodeEntityRef>
- File/span: <path and lines>
- Relevant path: <bounded code relationship path>
- Evidence reference/hash: <URN/hash>

#### Alternatives, conflicts and limitations

<List contrary evidence, unresolved alternatives, missing/stale providers and scope limits.>

#### Human decision

- Decision: <APPROVED | APPROVED_WITH_QUALIFICATION | REJECTED | NEEDS_CLARIFICATION>
- Reviewer: <actual person>
- Role: <most-related role>
- Role assignment: <PROVISIONAL_MOST_RELATED_ROLE>
- Rationale: <required except where policy permits unqualified approval>
- Decided at: <ISO-8601>
- Decision reference: <urn:decision:...>

## 5. Stale and superseded knowledge

| Prior item/decision | Changed source/evidence | Current state | Required action |
|---|---|---|---|
| <URN> | <revision/version/hash> | <STALE/SUPERSEDED> | <re-review action> |

## 6. Gaps and follow-up actions

| Finding | Evidence state | Suggested owner (provisional) | Action |
|---|---|---|---|
| <gap> | <supported/disputed/unknown> | <role> | <action> |

## 7. Integrity manifest

- Review-packet hash: <sha256>
- Evidence-set hash: <sha256>
- JSON manifest hash: <sha256>
- Markdown export hash: <sha256, computed after canonicalization>
- Generator/version: <C8 version>
- Correlation ID: <UUID>

## 8. Approval limitations

- Decisions apply only to the candidate versions and evidence hashes listed above.
- Changed code, Confluence content, linker rules or evidence create a new version or stale state.
- Missing or unavailable sources are not negative evidence.
- This pack is not an electronic signature, formal institutional approval or release authorization.
