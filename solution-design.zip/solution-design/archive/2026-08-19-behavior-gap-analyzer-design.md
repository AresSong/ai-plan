# Behavior Gap Analyzer — Design Spec

> **SUPERSEDED:** Historical draft retained for provenance. It is not authoritative for the v5
> Java 17 + Confluence EKG/manual-approval PoC. See `README.md` and
> `../architecture/solution-design.md`.

**Date:** 2026-08-19  
**Status:** Draft — awaiting user approval  
**Author:** AI-SDLC tooling POC

## Context

A production incident in RATAN exposed a gap in regression test coverage. The root cause: a code change was implemented and merged without corresponding BDD scenarios covering the affected behavior. The existing AI-SDLC pipeline has strong story authoring (`/writeuserstories`), BDD generation (`/writebddfeatures`), and code review (`/codereview`) steps—but no gate that cross-references all three to ask: “Does the implementation match the story, and are all affected behaviors actually tested?”

This spec defines a new reusable skill—`behavior-gap-analyzer`—and its companion command `/gap-check` that fills this gap. The POC validates against the RATAN incident and two synthetic test cases. If successful, it becomes a permanent AI-SDLC pipeline step between `/codereview` and `/codecommit`.

## Scope

**POC (this spec): Mode A — pre-commit / PR gate.** Runs on a `git diff` of the current branch versus `dev-merge`.

**Future extension (Mode B): Pre-implementation analysis.** Run after story authoring to flag conflicts between new acceptance criteria and existing system behavior before any code is written. Designed as an additive mode on the same skill.

## Three Sources of Truth

| Source | What It Represents | Where It Comes From |
|---|---|---|
| A — Intended behavior | ADO story ACs, acceptance criteria, business rules | `ado-agent FETCH_STORY` → story ID from `git log` ADO footer or explicit argument |
| B — Implementation behavior | Code diff: changed files, new/modified symbols, API routes, schema changes | `git diff origin/dev-merge...HEAD` |
| C — Existing system behavior | BDD feature files, scenario tags, TC IDs | `e2e-test/src/test/resources/features/**/*.feature` + `.ai-sdlc/workflow-state/{storyId}.json` |

## Three Analysis Dimensions

### Dimension 1 — Drift Check (A vs B)

*Did we implement something different from the requirement?*

> Comment from the source: Does this implementation require a detailed API-contract definition in the user-story acceptance criteria—for example, approve a trade via `POST /api/v1/trades/{id}/approve` and update approval status?

Algorithm:

1. Parse ACs from the story payload into `{ac_id, given, when, then}` tuples.
2. Extract symbols from added (`+`) lines in `gitDiff` only, consistent with the `codereview-agent` convention:
   - Java: `@(Get|Post|Put|Delete|Patch)Mapping` annotations → HTTP method + path;
   - Java: `public \w+ \w+\(` → method signatures;
   - TypeScript: `export (function|const|async function) \w+` → exported symbols;
   - Schema: changes in `*Entity.java`, `*DTO.java`, `*Request.java`, `*Response.java`, and `*.sql`.
3. Score each AC against each symbol: exact path match = 3 points, method name contains keyword = 2 points, file name contains keyword = 1 point. Score ≥ 2 → `COVERED`.
4. Symbols with no matching AC → `UNDECLARED`.
5. ACs with no matching symbol → `MISSING`.
6. Verdict: `DRIFT` if any `MISSING` or `UNDECLARED`; otherwise `PASS`.

### Dimension 2 — Blast Radius Check (B → C)

*Could the implementation unintentionally change other system behavior?*

Algorithm—two layers:

> Open question from the source: How should this apply across repositories when an upstream repository change impacts a downstream repository?

**Layer A (Tag Map, fast):** Map each changed file’s module path to BDD domain tags using `references/module-domain-map.md`. Filter `featureFilesIndex` by matching tags. `oreo-gateway` changes flag **all** feature files with `highImpact = true`.

**Layer B (Call Graph, precise):** Extract changed Java class names from the diff. Search the e2e glue layer (`e2e-test/src/main/java/`) for those class names. For each matching glue file, extract `@Given`/`@When`/`@Then` step patterns. Search all `.feature` files for those step keywords. Union the results with Layer A.

Each feature file is tagged with detection method: `TAG_MAP`, `CALL_GRAPH`, or `BOTH`.

### Dimension 3 — Coverage Gap Check (B + A vs C)

*Are all affected behaviors covered by regression tests?*

Algorithm:

1. For each `COVERED` AC from Dimension 1:
   - map AC keywords to expected feature-file paths through `module-domain-map.md`;
   - if an expected file exists, search for TC tags referencing the story ID;
   - fall back to fuzzy keyword matching—at least two keyword hits—in scenario text.
2. Classify each AC:
   - `COVERED`: scenario found with matching TC tag or keyword match plus `@smoke` tag;
   - `SMOKE_GAP`: scenario found but only `@regression`, no `@smoke`—warning, not blocker;
   - `GAP`: no matching scenario found;
   - `NO_TC_TAGS`: workflow-state `tcTags` is empty but ACs are implemented.
3. Verdict: `GAP` if any AC is `GAP` or `NO_TC_TAGS`; `PASS` if all are `COVERED` or `SMOKE_GAP` only.

## Overall Verdict Logic

```text
GAP   → coverage gaps exist (highest priority — blocks pipeline)
DRIFT → implementation diverges from story (process concern)
PASS  → all three dimensions clean
```

`lastCompletedStage` advances to `gap-check` only on `PASS`. `GAP` and `DRIFT` verdicts do not advance the pipeline.

## Output

### Terminal Report

A structured table report with three sections—one per dimension—an overall verdict box, and suggested next actions. It uses box drawing for the verdict and is color-coded: PASS, DRIFT, and GAP.

### ADO Comment

A Markdown table is posted through `ado-agent ADD_COMMENT` whenever a story ID is resolved. This creates a permanent audit trail regardless of verdict; GAP and DRIFT verdicts are especially important to record.

### Auto-Fix

If the verdict is `GAP`, the skill offers: “Type `autofix` to invoke `/writebddfeatures #{storyId}` now.” This requires explicit user confirmation—no silent BDD generation.

## Story ID Resolution

1. `git log --oneline -20 | grep -oP 'ADO: #\K[0-9]+' | head -1` — auto-infer from branch commits.
2. If not found, prompt the user for an explicit story ID.
3. If still not found, run analysis without Source A—Dimensions 2 and 3 only; no drift check.

## Skill Structure

```text
.claude/skills/behavior-gap-analyzer/
├── SKILL.md                       # Core skill: inputs, 5-step workflow, output contract
└── references/
    ├── module-domain-map.md       # Module path → BDD domain tags → feature file globs
    ├── analysis-algorithms.md     # Step-by-step algorithms for all 3 dimensions
    └── gap-report-format.md       # Terminal + ADO comment output templates

.claude/commands/gap-check.md      # 10-step orchestrator command
```

## Workflow State Schema Extension

Add to `.ai-sdlc/workflow-state/{storyId}.json`:

```json
{
  "gapCheckVerdict": null,
  "lastGapCheck": null,
  "gapCheckResult": {
    "driftIssueCount": 0,
    "blastRadiusFileCount": 0,
    "coverageGapCount": 0,
    "smokeGapCount": 0,
    "affectedDomains": [],
    "gaps": []
  }
}
```

## Pipeline Integration

Insert `/gap-check` between `/codereview` and `/codecommit`:

| # | Command | Purpose |
|---:|---|---|
| 9 | `/codereview` | Code quality gate |
| 9.5 | `/gap-check` | Behavior gap gate—drift, blast radius, coverage |
| 10 | `/codeoptimize` | Performance / maintainability |
| 11 | `/codecommit` | Pre-commit security gate + commit |

## Module → BDD Domain Map

| Module | BDD Domain Tags | Feature File Globs |
|---|---|---|
| `oreo-workers-backend` | `@trade_lifecycle`, `@trade_creation`, `@trade_amendment`, `@trade_cancellation`, `@trade_checker_approval`, `@trade_audit`, `@trade_allocation`, `@trade_early_termination`, `@trade_partial_termination`, `@trade_partial_novation_remaining`, `@trade_portfolio_reassignment`, `@trade_step_out_full`, `@trade_step_out_partial`, `@workers` | `features/api/trading/**`, `features/ui/trading/**`, `features/api/workers/**` |
| `oreo-gateway` | **ALL (cross-cutting)** | `features/**` — `highImpact: true` |
| `oreo-risk-engine` | `@risk`, `@risk_metric_retrieval`, `@risk_metric_display`, `@risk-metrics` | `features/api/risk/**`, `features/api/risk_management/**`, `features/ui/risk_management/**` |
| `oreo-user-center` | `@login`, `@user_preference_config` | `features/ui/authentication/**`, `features/ui/user_management/**` |
| `oreo-notification` | `@notification`, `@websocket` | `features/ui/notification/**` |
| `oreo-refdata-service` | `@counterparty_management`, `@marketer_management`, `@portfolio_management`, `@reason_management`, `@refdata_sync_management` | `features/api/reference_data/**` |
| `oreo-ops-service` | No feature files—flag as uncovered domain | None |

> Additional module-map rows are below the photographed viewport and are therefore not reproduced here.

## POC Acceptance Criteria

### TC-GAP-001: Known Gap Flags Correctly

- Story has three ACs; only AC1 is implemented in the diff; AC2 and AC3 have no BDD scenarios.
- Expected: `verdict: "GAP"`, `coverageGapCount: 2`, with both gaps listed with expected feature-file paths.
- Source: RATAN incident details (Liam to provide).

### TC-GAP-002: Full Coverage Passes Cleanly (No False Positives)

- Story has two ACs, both implemented in the diff, and both have `@smoke` BDD scenarios.
- Expected: `verdict: "PASS"`, all dimensions clean, ADO comment posted with PASS.
- Source: Existing OREO story with complete BDD coverage, for example `trade_amendment`.

### TC-GAP-003: Implementation Drift Detected

- Story AC specifies `POST /api/v1/trades/{id}/approve`; the diff shows `rejectTrade()` changed instead.
- Expected: `verdict: "DRIFT"`, AC1 `MISSING`, `rejectTrade` `UNDECLARED`, and `lastCompletedStage` not advanced.
- Source: Synthetic test case constructed from the OREO trade approval flow.

## Existing Infrastructure Reused

| Asset | Location | How Reused |
|---|---|---|
| `ado-agent` | `.claude/agents/ado-agent.md` | `LOAD`, `FETCH_STORY`, `ADD_COMMENT`, `SAVE` operations |
| `qa-layer-test-design` skill | `.claude/skills/qa-layer-test-design/` | AC parsing patterns; test point mapping logic |
| Workflow state JSON schema | `.ai-sdlc/workflow-state/{storyId}.json` | Extended with gap-check fields |
| Skill format conventions | All existing skills | Frontmatter, on-load acknowledgement, output contract |
| `codereview-agent` convention | `.claude/agents/codereview-agent.md` | Added (`+`) lines only for new issues |

## Key Design Decisions

| Decision | Rationale |
|---|---|
| Skill receives pre-built `featureFilesIndex` from command | Skill owns analysis only; command owns I/O. Keeps the skill testable in isolation. |
| `TAG_MAP` first, `CALL_GRAPH` second for blast radius | `TAG_MAP` is an instant O(1) lookup; `CALL_GRAPH` adds precision for cross-module calls. |
| `oreo-gateway` → all feature files | The gateway is the single entry point; any gateway change is cross-cutting by definition. |
| Drift check uses added (`+`) lines only | Consistent with `codereview-agent`; only newly introduced lines are in scope. |
| `lastCompletedStage` only advances on `PASS` | GAP/DRIFT must not silently advance the pipeline. |
| Auto-fix requires explicit `autofix` input | Prevents silent BDD generation. The user must consciously invoke `/writebddfeatures`. |
| ADO comment always posted when story is resolved | Creates an audit trail regardless of verdict. |
| `smokeGapCount` tracked separately from `coverageGapCount` | Smoke gaps are warnings—coverage exists but is not smoke-tagged—not blockers. |
| Verdict priority: `GAP > DRIFT > PASS` | Coverage gaps are the most actionable blocker. |

## Out of Scope (POC)

- Mode B (pre-implementation analysis)—future extension.
- Integration with CI/CD pipeline as an automated PR gate—future.
- Cross-story blast radius—changes that affect stories other than the one being implemented—future.
- Non-OREO project support—future; the skill is parameterized through `CLAUDE.md` variables.
