# Behavior Gap Analyzer — Implementation Plan

> **SUPERSEDED REFERENCE:** Retained as a style/history reference only. The executable ten staffed-day
> plan is `../implementation/ten-day-plan.md`.

**Date:** 2026-08-21  
**Status:** Draft — reference-style version  
**Author:** AI-SDLC tooling POC

## Objective

This implementation plan defines a practical delivery path for the Behavior Gap Analyzer, starting with a tightly scoped proof of concept and then establishing a first-month operating baseline.

The solution is intended to answer three review questions before code is approved:

1. Did the implementation diverge from the intended behavior?
2. Could the code change unintentionally alter other system behavior?
3. Are the affected behaviors actually covered by regression tests?

The delivery is organized into two concrete slices:

1. **PoC:** prove the end-to-end change-analysis flow on one incident-inspired scenario and one tightly bounded brownfield workflow.
2. **First month after PoC approval:** turn the same design into a repeatable operating baseline with versioned stores, update runbooks, and two-run repeatability inside the same scoped domain.

This archived example was aligned to the historical `solution-design-draft.md` and to external
behavior-mining/visual references that are not part of the current design package.

## Scope

### PoC scope

The PoC is a change-centered validation slice, not a general platform rollout.

It will use:

1. one incident-inspired workflow;
2. one selected brownfield business path;
3. one change package or PR-equivalent analysis input;
4. a minimal but real implementation of the five solution components:
   - Knowledge graph,
   - LLM wiki,
   - Central system behavior store,
   - Central behavior test case store,
   - AI Agent.

The PoC is successful only if the reviewer can see a justified impact path, the expected behavior baseline, the matching or missing test coverage, and a decision-ready report.

### First-month scope

The first month is not a second demo. It is the minimum operating baseline for the same solution.

It adds:

1. repeatable refresh flows for wiki, graph, and behavior stores;
2. a bronze/silver/gold behavior lifecycle with human review on the selected scope;
3. stable contracts between the AI Agent and the four supporting stores;
4. two-run repeatability on different change samples in the same domain;
5. KPI capture for usefulness, confidence, coverage-gap detection, and review effort.

### Out of scope for these two slices

1. enterprise-wide rollout across all repositories and domains;
2. full CI/CD automation as a mandatory release gate;
3. autonomous PR approval or autonomous test-waiver decisions;
4. fine-grained lineage for every legacy asset in the brownfield estate;
5. full cross-story conflict management beyond the selected scope.

## Design Anchor

The design stays anchored to the same five component groups from the draft solution.

| Component | Purpose in this plan | PoC expectation | First-month expectation |
|---|---|---|---|
| Knowledge graph | Explain technical impact and lineage | Prove one queryable impact path for the scoped change | Stabilize graph schema and repeatable update path |
| LLM wiki | Consolidate business and technical context | Build one scoped, source-linked knowledge pack | Introduce incremental refresh and freshness controls |
| Central system behavior store | Hold expected behavior baselines | Store scoped bronze/silver behaviors and a reviewed gold subset | Version, audit, and retrieve behavior baselines reliably |
| Central behavior test case store | Hold BDD and coverage assets | Register expected and existing scenarios for the scoped flow | Track coverage status and action queue |
| AI Agent | Orchestrate review and analysis | Produce one end-to-end behavior-gap report | Run repeatably through stable skills and MCP contracts |

## Supporting Visuals

This implementation plan uses the existing visuals as design references rather than repeating them in prose.

1. `architecture/c4/visuals/03-component-knowledge-graph-visual.html`
2. `architecture/c4/visuals/04-component-behavior-mining-visual.html`
3. `architecture/c4/visuals/05-component-ai-agent-visual.html`
4. `architecture/c4/visuals/05a-new-feature-change-journey-visual.html`
5. `architecture/c4/visuals/05b-brownfield-setup-visual.html`
6. `architecture/c4/visuals/05c-backend-refresh-visual.html`
7. `architecture/c4/visuals/06-distill-user-behaviors-visual.html`
8. `architecture/c4/visuals/07-code-dependency-visual.html`

## PoC Design

### PoC objective

Prove that a single AI-assisted review flow can combine intended behavior, implemented change evidence, historical system behavior, and existing regression assets into one decision-ready output.

### PoC analysis target

The PoC should be run against one selected incident-shaped change package with the following inputs:

1. feature or user story plus acceptance criteria;
2. available design context and business rules;
3. code diff or change package;
4. scoped code dependency and lineage evidence;
5. selected historical logs or audit data for the relevant workflow;
6. existing BDD or regression assets for the same behavior area.

### PoC sources of truth

The rows of the source-of-truth table are outside the photographed viewport. The visible document establishes that the PoC combines intended behavior, implementation evidence, historical workflow evidence, and existing test assets.

### PoC output

The fixed PoC artifact is a **Behavior Gap Report**. It must answer the three review questions and provide enough evidence for a manager, QA reviewer, or developer to act.

Minimum report sections:

1. change summary;
2. intended behavior summary;
3. implemented behavior summary;
4. impacted downstream behavior and confidence;
5. existing coverage status;
6. missing or conflicting BDD actions;
7. decision recommendation with caveats.

### PoC operating flow

1. Ingest the scoped story, acceptance criteria, and supporting design context.
2. Build a scoped LLM wiki with business, architecture, and implementation sections.
3. Derive expected behavior statements from the wiki.
4. Ingest selected brownfield workflow and dataflow evidence.
5. Distill candidate historical behaviors and classify them into bronze and silver.
6. Promote a selected reviewed subset to gold for the PoC scenario.
7. Derive or register BDD scenarios for the gold behavior set.
8. Build a scoped code dependency and lineage graph for the change package.
9. Run the behavior-gap analysis across intended, implemented, and existing behavior.
10. Produce the Behavior Gap Report and review it with QA and the manager.

## PoC Component Design

### 1. Knowledge graph

The PoC knowledge graph is not a general enterprise graph. It is a scoped lineage model that must explain why a change is considered risky and which tests or behaviors are linked to it.

#### PoC graph slices

1. code dependency;
2. code-feature lineage;
3. code-behavior test case lineage;
4. feature-behavior test case lineage;
5. feature-LLM wiki lineage.

#### PoC minimum nodes

1. repository;
2. component or service;
3. source file or symbol;
4. feature or story;
5. behavior identifier;
6. BDD scenario or regression asset;
7. wiki document section;
8. change package or PR identifier.

#### PoC minimum edges

1. `DEPENDS_ON`;
2. `IMPLEMENTS_FEATURE`;
3. `IMPLEMENTS_BEHAVIOR`;
4. `TESTS_BEHAVIOR`;
5. `DOCUMENTED_IN`;
6. `CHANGED_BY`;
7. `IMPACTS`.

#### PoC graph behavior

For the PoC, the graph only needs one repeatable query path:

```text
change package -> changed code -> impacted component -> linked behavior -> linked test case -> linked wiki context
```

This is enough to support the behavior-gap question set. Fine-grained full-estate lineage can wait.

### 2. LLM wiki

The PoC LLM wiki is a scoped AI-friendly knowledge pack, not a complete brownfield documentation program.

#### Required PoC sections

1. business context;
2. intended workflow;
3. architecture context;
4. implementation context;
5. key exceptions and business rules.

#### Content rules

1. every section must carry source references;
2. generated summary text is allowed, but only with explicit source linkage;
3. missing information must be recorded as a gap, not silently inferred;
4. the wiki must expose the exact statements later used to derive expected behavior.

### 3. Central system behavior store and behavior mining

This is the most complicated PoC component, so the PoC must constrain it sharply.

The behavior-mining report already makes the key point: observed behavior is not automatically expected behavior. Historical data provides evidence, not truth. The PoC must therefore separate mined evidence from approved behavior.

#### PoC mining target

Distill one selected business workflow from historical workflow and dataflow evidence and classify the results into confidence tiers.

#### PoC data model

The standardized event model should include at least:

1. `event_id`;
2. `activity` or standardized activity;
3. `timestamp`;
4. `case_id` or equivalent scoped process identity;
5. `business_object_id` when needed;
6. `actor_role`;
7. `outcome` or state signal;
8. `release` or source version when available;
9. `change_linkage` where the incident path can be correlated.

#### PoC mining flow

1. Extract scoped workflow and dataflow records.
2. Map raw events into the standardized model.
3. Identify normal path, incident path, and corrected path candidates.
4. Generate candidate behavior patterns with evidence references.
5. Classify patterns into bronze or silver based on confidence and completeness.
6. Submit the selected patterns to SME review for gold promotion.
7. Persist approved gold behaviors for BDD derivation and gap analysis.

#### PoC tier semantics

| Tier | Meaning | PoC usage |
|---|---|---|
| Bronze | Low-confidence mined pattern | Stored for traceability, not used as authoritative expectation |
| Silver | Higher-confidence mined pattern with stronger evidence | Eligible for SME review and comparison |
| Gold | Human-validated expected behavior | Used for BDD derivation and gap analysis |

#### PoC behavioral output

The PoC does not need a full statistical benchmark product. It needs a reviewed list of expected behavior statements for one workflow, such as:

1. expected sequence or state transition;
2. valid exception path;
3. prohibited or suspicious path;
4. required downstream outcome;
5. exact condition that a BDD scenario must verify.

### 4. Central behavior test case store

The PoC behavior test case store must answer one practical question: what expected behavior already has a regression scenario, and what does not?

#### PoC contents

1. generated BDD scenario ID;
2. linked behavior ID;
3. linked feature or story ID;
4. impacted component tags;
5. coverage status;
6. review status;
7. evidence or source links.

#### PoC coverage states

1. `COVERED`;
2. `PARTIALLY_COVERED`;
3. `NOT_COVERED`;
4. `CONFLICT_REVIEW_REQUIRED`.

> The photographed sequence does not show the remainder of the PoC comparison-logic subsection.

### 5. AI Agent

The AI Agent is the orchestration layer. In the PoC it should remain skill-driven and transparent.

#### PoC skills in scope

1. review and grill user story;
2. build scoped LLM wiki;
3. distill expected workflow and dataflow from history;
4. build scoped knowledge graph;
5. derive expected behavior from the wiki and approved mined patterns;
6. derive BDD scenarios;
7. analyze behavior gap.

#### PoC MCP contracts

The PoC agent should consume the following stores through explicit tool or service boundaries rather than hidden coupling:

1. knowledge graph access;
2. LLM wiki access;
3. central system behavior store access;
4. central behavior test case store access;
5. ADO access.

#### PoC orchestration result

The AI Agent is successful only if it can produce one end-to-end report with traceable evidence, explicit confidence, and explicit human review points.

## PoC Acceptance Criteria

### Functional acceptance

1. the selected change package can be analyzed end to end;
2. the graph returns the impacted behavior and linked downstream test context;
3. the behavior store contains a reviewed gold subset for the selected workflow;
4. the test case store can classify at least one behavior as covered or not covered;
5. the AI Agent can produce a fixed-format Behavior Gap Report.

### Review acceptance

1. QA can verify how expected behavior was derived.

> The remainder of the review-acceptance list is outside the photographed viewport.

### PoC stop/go decision

The PoC should only proceed to month one if reviewers conclude that the solution surfaced information they could not reliably obtain from the current toolchain with the same effort.

## First-Month Design

### First-month objective

Convert the PoC flow into a repeatable operating baseline for one scoped domain.

The first month should prove that the solution can be refreshed, rerun, reviewed, and improved without manual reinvention each time.

### First-month operating model

The month-one design adds three repeatable back-end refresh loops:

1. **LLM wiki refresh:** incrementally gather ADO items and documents, rebuild the scoped wiki pack, and mark freshness.
2. **Behavior-store refresh:** incrementally ingest selected logs or audit data, rerun mining, and submit candidate changes for review.
3. **Test-case refresh:** update generated BDD assets, compare with existing scenarios, and update coverage state.

This matches the backend-refresh direction already shown in `architecture/c4/visuals/05c-backend-refresh-visual.html`.

## First-Month Component Design

### 1. Knowledge graph in month one

Month one should stabilize the graph as a repeatable service for one domain.

#### Month-one goals

1. freeze the node and edge taxonomy for the scoped domain;
2. support incremental update per change package;
3. persist provenance and confidence on all material edges;
4. support two repeatable query paths:
   - change-to-behavior-to-test;
   - feature-to-wiki-to-behavior.

#### Month-one additions beyond PoC

1. explicit change artifact nodes;
2. explicit component and service boundaries;
3. stable behavior identifiers shared with the behavior store and test case store;
4. run metadata for graph refresh and query reproducibility.

### 2. LLM wiki in month one

Month one should turn the wiki into a maintained knowledge product.

#### Month-one requirements

1. source-linked narration workflow;
2. fixed semantic sections for analyzer consumption;
3. version or freshness indicator per section;
4. human approval on business-critical summaries;
5. explicit unresolved-question section.

#### Minimum month-one wiki template

1. business intent;
2. workflow and exception rules;
3. architecture and service interaction;
4. implementation notes and constraints;
5. linked feature, behavior, and test assets;
6. brownfield uncertainty notes.

### 3. Behavior store and behavior mining in month one

Month one should convert the PoC mining exercise into a managed benchmark flow for one domain.

#### Month-one behavior-mining requirements

1. adapter-based ingestion for the selected system sources;
2. stable standardized event and object mapping;
3. repeatable confidence classification;
4. explicit exception registry;
5. reviewed promotion workflow from silver to gold;
6. audit trail for who approved what and when.

#### Month-one mining outputs

1. approved gold behavior statements;
2. reviewed valid exception patterns;
3. suspicious or unknown patterns for follow-up.

> The photographed sequence does not show the remainder of the behavior-store output list or the month-one test-case-store subsection.

### 5. AI Agent in month one

Month one should make the AI Agent operationally repeatable.

#### Month-one requirements

1. command-and-skill-driven execution;
2. fixed orchestration order;
3. reduced-confidence mode when inputs are incomplete;
4. standard report schema;
5. run metrics and traceability for each execution;
6. explicit human checkpoints for wiki approval, gold behavior promotion, and QA review.

#### Month-one orchestration flow

1. validate input package;
2. refresh or read scoped wiki;
3. refresh or read impacted behaviors;
4. refresh or read graph lineage;
5. retrieve current test-case coverage;
6. run the three behavior-gap questions;
7. produce report plus action queue.

## Month-One Deliverables

| Deliverable | Description | Success condition |
|---|---|---|
| Repeatable wiki refresh | Incremental generation and curation of scoped AI wiki | Two consecutive refreshes produce stable, source-linked sections |
| Repeatable mining refresh | Re-runnable behavior distillation on the scoped workflow | Same input data yields stable candidate behavior set within agreed variance |
| Versioned behavior store | Bronze/silver/gold storage with audit trail | Reviewer can retrieve current and previous approved behavior state |
| Queryable lineage graph | Change-to-behavior-to-test path available on demand | Same query path works on two change samples |
| Coverage-aware test store | Scenario registry and coverage status engine | Each impacted behavior is classified into a visible status |
| Agent runbook | Repeatable orchestration steps and output schema | Team can execute the same flow without ad hoc interpretation |

## Month-One Acceptance Criteria

1. the full flow is rerun successfully on two change samples in the same domain.

> The remainder of the month-one acceptance criteria is outside the photographed viewport.

## Implementation Order

### PoC implementation order

1. select the incident-shaped workflow and confirm truth inputs;
2. build the scoped wiki pack;
3. define the standardized event model for the selected workflow;
4. ingest and classify the first mined behavior candidates;
5. create the scoped graph and link behavior/test/wiki identifiers;
6. populate the initial test case registry;
7. run the AI Agent and produce the first report;
8. review results and tighten the weakest component.

### Month-one implementation order

1. formalize shared identifiers across graph, behavior store, wiki, and test case store;
2. add refresh runbooks for wiki, mining, and test-case update;
3. introduce approval and audit trail for gold promotion and QA review;
4. stabilize the report schema and action queue;
5. run two repeatability trials and capture KPI baseline.

## Roles and Review Points

| Role | Responsibility in PoC | Responsibility in month one |
|---|---|---|
| Delivery owners | Build the end-to-end slice | Stabilize refresh flows and contracts |
| BA or PO | Review intended behavior and wiki quality | Approve critical business summaries |
| SME | Review mined behavior candidates | Promote silver to gold and maintain exception registry |
| QA | Review generated BDD and coverage status | Operate the coverage action queue |
| Manager | Decide PoC continuation | Review month-one KPI and readiness |

Mandatory review points:

1. wiki review before expected behavior derivation;
2. SME review before gold promotion;
3. QA review before scenario acceptance;
4. manager review before expansion.

## Key Design Decisions

| Decision | Rationale |
|---|---|
| Start from one incident-shaped workflow | The first proof must be concrete enough to verify and replay |
| Use historical data as evidence, not as automatic truth | Brownfield data contains valid behavior, invalid behavior, and obsolete behavior |
| Introduce bronze/silver/gold tiers from the start | Confidence and approval status must be explicit in a brownfield environment |
| Keep graph scope narrow in the PoC | The first value is explainable impact, not maximum graph coverage |
| Derive BDD from approved behavior, not raw traces | Expected behavior must remain reviewable and business-meaningful |
| Use fixed report schema early | The solution must support decisions, not just analysis output |
| Expand only after repeatability | One successful demo is not yet an operating baseline |

## Immediate Next Steps

1. identify the exact PoC scenario and truth data package;
2. decide the first standardized event model for the selected workflow;
3. define the shared identifiers between behavior store, graph, wiki, and test store;
4. draft the fixed Behavior Gap Report template;
5. run the first PoC assembly and review the weakest evidence link.

## Open Decisions

1. which exact workflow and incident-shaped scenario will be the authoritative PoC target;
2. which historical sources are allowed for the first mining slice;
3. whether the first gold behavior promotion is done by SME alone or SME plus BA/PO;
4. what the minimum acceptance threshold is for calling a behavior `COVERED`;
5. whether month one should stay in one domain or include a second workflow in shadow mode.
