# Behavior Gap Analyzer — Solution Design Draft

> **SUPERSEDED:** Historical draft retained for provenance. Current component ownership and PoC scope
> are defined in `../architecture/solution-design.md`.

The problem statement from the high-level manager is in `problem statement.txt`.

## Components

### Knowledge graph

- Code dependency
- Code-feature lineage
- Code-behavior test case lineage
- Feature-behavior test case lineage
- Feature-LLM wiki lineage

### LLM wiki

An AI-friendly document consolidating both business and technical knowledge:

- Business context
- Architecture context
- Implementation context

### Central system behavior store

This could be physically in the same place as the knowledge graph.

- Bronze — low confidence
- Silver — high confidence
- Gold — human validated

### Central behavior test case store

This could be physically in the same place as the knowledge graph.

### AI Agent

#### Skills

- Review and grill user story
- Distill expected workflow/dataflow from historical data
- Build knowledge graph
- Build LLM wiki
- Derive expected behavior from LLM wiki
- Derive behavior-driven test case
- Analyze behavior gap

#### MCP integrations

- Knowledge graph
- LLM wiki
- Central system behavior store
- Central behavior test case store
- ADO

## Initial setup process

### Brownfield

#### Central system behavior store and central behavior test case store

- A brownfield project was initiated years before AI SDLC and BDD. Its practices may therefore not be up to current AI SDLC and BDD standards; for example, expected business behavior may not be documented.
- Despite incomplete knowledge, a brownfield project has the most valuable asset in the AI era: data. The data comes from real-world user behavior accumulated over years and consists of workflow and dataflow evidence.
- An AI skill distills user behaviors from the historical data.
- Distilled user behaviors are categorized as low and high confidence and stored in bronze and silver respectively.
- An SME audits distilled user behaviors and promotes approved behavior to the gold store.
- The AI Agent converts gold distilled user behavior into BDD features and stores them in the central behavior test case store.
- QA reviews the test cases.
- The AI Agent compares distilled behavior test cases against existing test cases.
- If a conflict exists, raise it for review.
- If there is no conflict, merge with the existing behavior test cases and answer: are all behaviors actually covered by existing regression tests?

#### LLM wiki

- All documents
- All code repositories

#### Knowledge graph

The brownfield estate may not support fine-grained feature-code-behavior-test-case lineage because of legacy issues. Code-service-behavior-level lineage is the expected minimum.

- The AI Agent uses a skill to build the code-dependency knowledge graph.
- The AI Agent uses a skill to build code-behavior test-case lineage, if it does not already exist.
- The AI Agent uses a skill to build code-to-LLM-wiki lineage.

New features and changes follow the same process as greenfield work after practice transformation.

## Backend schedule

### Incrementally update the LLM wiki

1. Incrementally gather ADO items: features, user stories, and subtasks.
2. Incrementally gather documents, for example Confluence pages.
3. Generate LLM-wiki content for features and system services.

### Incrementally update the central system behavior store

1. Load system data, logs, and audit records.
2. Distill user behavior.
3. Have an SME validate it.

### Update the central behavior-driven test case store

Update the central store and answer: are all behaviors actually covered by existing regression tests?

## New feature/change journey

1. A new feature/change is raised with a feature item, user story, acceptance criteria, architecture design record, and related context.
2. An AI skill grills and reviews the human input and helps raise it to the AI SDLC standard.
3. An AI skill generates the LLM wiki from both business and technical context.
4. The AI Agent updates the LLM wiki through MCP.
5. An AI skill derives expected behavior from the LLM wiki.
6. Expected behavior is stored in the central system behavior store and reviewed by BA/PO.
7. The AI Agent searches the LLM wiki for impacted features and system services through MCP.
8. The AI Agent searches the central system behavior store for impacted behaviors through MCP.
9. The AI Agent identifies conflicting behavior.
10. If a conflict exists, return to grilling and reviewing the requirement and design.
11. If there is no conflict, the AI Agent uses a skill to derive behavior-driven test cases, which QA reviews.
12. The AI Agent saves the behavior-driven test cases to the central behavior test case store through MCP.
13. A developer or AI develops code based on the user story, acceptance criteria, architecture design record, and related context.
14. The developer raises a PR associated with the feature/user story.
15. The AI Agent retrieves behavior-driven test cases from the central behavior test case store through MCP.
16. The AI Agent executes the behavior-driven test cases through MCP and asks: did we implement something different from the requirement?
17. The AI Agent retrieves the code diff through ADO MCP.
18. The AI Agent retrieves impacted code and features from the knowledge graph. The feature may be null for a brownfield project.
19. The AI Agent retrieves behavior-driven test cases for the impacted code and features.
20. The AI Agent executes the behavior-driven test cases to determine whether the implementation unintentionally changed other system behavior.
21. After tests pass and code is published, the AI Agent updates the LLM wiki and knowledge graph.

## Architecture views

### System context

```mermaid
flowchart TB
    Team["Product Team<br/>Developer · BA/PO · QA · SME"] --> Analyzer["Behavior Gap Analyzer<br/>Compares intended, implementation, and existing behavior<br/>Produces PR findings, impact paths, and coverage checks"]
    Analyzer -->|ADO/MCP| ADO["Azure DevOps<br/>stories · PRs · tests"]
    Analyzer -->|REST| Confluence["Confluence<br/>business context"]
    Analyzer --> Copilot["GitHub Copilot<br/>developer interface"]
    Analyzer --> SSI["SSI Stamping<br/>workflow evidence"]
    Analyzer --> NSTP["NSTP Check<br/>downstream checks"]
    Analyzer --> PostgreSQL["PostgreSQL<br/>graph + behavior store"]
```

### Containers

```mermaid
flowchart TB
    Developer[Developer]
    QA[QA Engineer]
    BA[BA or PO]
    SME[SME]

    subgraph Analyzer[Behavior Gap Analyzer]
        KG["Knowledge graph<br/>code dependency · lineage"]
        Wiki["LLM wiki<br/>business · architecture · implementation"]
        BehaviorStore["Central system behavior store<br/>bronze · silver · gold"]
        TestStore["Central behavior test case store<br/>BDD scenarios · regression mapping"]
        Agent["AI Agent<br/>skills · MCP orchestration"]
    end

    Developer --> KG
    QA --> Wiki
    BA --> Wiki
    SME --> Agent
    BehaviorStore --> ADO[Azure DevOps]
    Wiki --> Confluence[Confluence]
    TestStore --> Checks[SSI + NSTP]
    Agent --> Runtime["GitHub Copilot + PostgreSQL"]
```

### Knowledge graph internals

```mermaid
flowchart LR
    Agent[AI Agent] --> Dependency[Code dependency]
    Agent --> CodeFeature[Code-feature lineage]
    Agent --> CodeBehavior[Code-behavior test case lineage]
    Agent --> FeatureBehavior[Feature-behavior test case lineage]
    Agent --> FeatureWiki[Feature-LLM wiki lineage]

    Dependency --> PG1[(PostgreSQL)]
    CodeFeature --> PG2[(PostgreSQL)]
    CodeBehavior --> PG3[(PostgreSQL)]
    FeatureBehavior --> TestStore[(Test case store)]
    FeatureWiki --> Wiki[(LLM wiki)]
    CodeBehavior --> CentralTestStore[(Central behavior test case store)]
```

### Central behavior store and behavior mining

```mermaid
flowchart LR
    SSI[SSI Stamping] --> Distill[Distill expected workflow/dataflow from historical data]
    NSTP[NSTP Check] --> Distill
    Agent[AI Agent] --> Classify[Bronze/Silver confidence classification]
    Distill --> Classify
    Classify --> Audit[SME audit and gold promotion]
    SME[SME] --> Audit
    Audit --> BehaviorStore[(Central system behavior store)]
    Audit --> Derive[Derive behavior-driven test case]
    Derive --> TestStore[(Central behavior test case store)]
    TestStore --> Compare[Compare against existing test case]
    Compare --> QA[QA]
```

### New feature/change journey

```mermaid
flowchart LR
    A["1. Feature/change raised"] --> B["2. Review and grill input"]
    B --> C["3. Generate LLM wiki"]
    C --> D["4. Update wiki via MCP"]
    D --> E["5. Derive expected behavior"]
    E --> F["6. Save behavior states"]
    F --> F2["6b. BA/PO review"]
    F2 --> G["7. Search impacted feature/service"]
    G --> H["8. Search impacted behaviors"]
    H --> I["9. Identify behavior conflict"]
    I -->|conflict| B
    I -->|no conflict| J["11. Derive BDD test case"]
    J --> K["12. Save BDD to test store"]
    K --> L["13–14. Develop and raise PR"]
    L --> M["15–16. Execute mapped BDD tests"]
    M --> N["17–20. Diff and impact regression"]
    N --> O["21. Update LLM wiki and knowledge graph"]
```
