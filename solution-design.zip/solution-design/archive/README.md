# Archived design material

These files are retained for historical context and writing references. They are superseded and must
not be used as the current implementation contract.

Current entry points:

- [Solution design](../architecture/solution-design.md)
- [Ten-day plan](../implementation/ten-day-plan.md)
- [Detailed PoC handoff](../implementation/poc/README.md)

