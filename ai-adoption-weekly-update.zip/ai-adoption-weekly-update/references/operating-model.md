# Operating model, rationale, and examples

## Why this format works

A manager with many direct reports needs a two-minute view of progress and a clear way to intervene. Lead with status and the one-sentence story; use evidence and a tracker to make the update defensible. The email is not a project log.

When delivery relies on peer teams, next-week capacity is a leading indicator. Show the responsible lead/team, required contribution, and commitment status early. Escalate before capacity shortfalls slip a milestone.

## Evidence standard

Report three signals for the primary use case:

- **Adoption:** Who used it and how often.
- **Outcome:** Time, quality, revenue, cost, or risk result.
- **Readiness:** The people, data, access, approvals, and capacity needed for the next milestone.

Evidence strength, from lowest to highest:

| Label | Meaning | Good wording |
|---|---|---|
| Hypothesis | Expected value, not confirmed. | "Could reduce drafting time by 30%; test not yet run." |
| Validated proxy | PO or peer lead supports a limited test or estimate. | "PO validated the workflow estimate; direct-user measurement pending." |
| Observed | Measured usage, outcome, quality review, or user feedback. | "Observed: 8 users / 1 week; median time fell from 45 to 18 minutes." |

An observed result can still be preliminary; include the sample or period. A PO or peer lead may be the evidence owner when direct business-user access is unavailable. State that direct-user feedback is pending rather than implying it exists.

## Status convention

- **Green:** The next milestone is achievable and dependencies are committed.
- **Amber:** A dependency or evidence gap could threaten the next milestone.
- **Red:** The milestone is missed or cannot be met without intervention.

## Manager-facing tracker

Use one row per use case. Link outward to demos, dashboards, feedback, or a decision log rather than duplicating details.

| Field | Example |
|---|---|
| Use case | Sales-call summary and CRM draft |
| Business proxy / evidence owner | Sales Ops PO |
| Target users | 25 account executives |
| Baseline and value hypothesis | 45 minutes manual follow-up per call; save 50% |
| Status and next milestone | Amber; validate quality on 50 calls by Aug 21 |
| Adoption | 8/12 pilot users active, 24 tasks this week |
| Outcome and evidence label | Observed: median follow-up 18 minutes; 8 users / 1 week |
| Readiness / dependencies | Sales Ops lead Mei: 0.5 engineer-week, unconfirmed |
| Blocker and manager ask | Confirm capacity by Aug 10 or milestone slips one week |
| Prospective validation | Test 30 historical tickets; go/no-go Sep 4 |
| Links | Demo, dashboard, feedback, decision log |

## Examples

- **Customer-support knowledge assistant:** "Observed: first-draft response time fell from 12 to 5 minutes across 40 test tickets; 85% passed reviewer checks with minor edits."
- **Engineering incident triage:** "Observed: correctly identified the owning service in 17/20 historical incidents. It is not approved for production alert routing."
- **Document review:** "Validated proxy: Legal reviewed 15 contracts; the assistant found 28/34 known non-standard clauses. Human review remains mandatory."

## Initial baseline email

Subject: AI adoption — baseline, first milestones, and support needed

Hi [Manager],

I am establishing a Thursday AI-adoption update cadence. The primary focus is **[primary use case]**; the goal is **[business outcome]** by **[milestone/date]**. Current status: **[Green/Amber/Red]**.

**Primary use case**

- Outcome thesis: [baseline] → [target]; evidence: [Hypothesis / Validated proxy / Observed and caveat].
- Adoption/readiness: [pilot users or plan]; [next milestone].
- Dependencies: [peer lead/team] — [contribution and commitment status].

**Support needed**

- **[Reply requested / Discuss in 1:1] by [date]:** [specific action]. Owner: [manager/peer lead]. Without it: [milestone impact].

**Prospective use cases**

- [Use case]: [opportunity thesis]. Next validation: [step]. Go/no-go: [date].
- [Use case]: [opportunity thesis]. Next validation: [step]. Go/no-go: [date].

Tracker: [link]

Thanks,
[Name]

## Weekly email template

Subject: AI adoption weekly — [Green/Amber/Red] — [primary use case] — [date]

Hi [Manager],

**Headline:** [One sentence: current status, the most important evidence/change, and the immediate concern or next milestone.]

**Primary use case — [name] ([Green/Amber/Red])**

- Adoption: [users / frequency / change].
- Outcome: [result] — **[Observed / Validated proxy / Hypothesis]**; [sample/period or short caveat].
- Readiness for [next milestone, date]: [what is ready and what is not].
- Next week: [one or two planned actions].

**Early risks and support needed**

- **[Reply requested / Discuss in 1:1] by [date]:** [specific action]. Accountable lead: [name/team]. Needed capacity/approval: [detail]. If unresolved: [impact].

**Prospective use cases**

- [Use case]: [validation completed or next step]; go/no-go [date].
- [Use case]: [validation completed or next step]; go/no-go [date].

Portfolio tracker: [link]

Thanks,
[Name]
