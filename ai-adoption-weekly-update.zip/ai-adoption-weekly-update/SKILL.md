---
name: ai-adoption-weekly-update
description: Interview an AI adoption lead and create concise manager-facing weekly email updates and portfolio trackers. Use when a user needs a weekly AI adoption status update, leadership progress report, adoption-use-case portfolio, blocker/resource escalation, or a reusable communication template.
---

# AI Adoption Weekly Update

Create a decision-ready weekly update for a manager overseeing AI adoption work delivered through peer teams.

Read [references/operating-model.md](references/operating-model.md) before drafting. It contains the rationale, evidence standards, examples, and templates.

## Interview

Gather information through an interview. Ask exactly one question at a time and wait for the user's response. Do not draft the final template or email until the user confirms the shared understanding.

Resolve these decisions in order, skipping only facts already supplied:

1. Manager audience and desired reading depth.
2. Cadence and existing leadership rhythm.
3. Primary active use case and the maximum number of prospective use cases.
4. Next milestone, status, and Green/Amber/Red definition.
5. Adoption, outcome, and readiness evidence; baseline, sample, and evidence owner.
6. Named peer-team dependencies, next-week capacity, and commitment status.
7. Blocker escalation threshold and each specific manager ask.
8. Prospective use-case hypothesis, validation step, and go/no-go date.
9. Tracker depth and links to supporting material.

For every decision, offer a recommended answer and explain a material trade-off briefly. Prefer concrete, manager-actionable questions over generic project questions. Treat capacity in a peer team as a leading risk when the user has no direct reports.

Before drafting, summarize the agreed operating model in bullets and ask for confirmation.

## Drafting rules

After confirmation, produce:

1. A manager-facing portfolio tracker structure.
2. An initial baseline email when starting the cadence.
3. A recurring weekly email template.

Put the elevator-pitch summary first. Keep routine updates scannable in two minutes, but provide one concrete example or a tracker link for claims likely to be questioned.

For the primary use case, always cover adoption, outcome, and readiness. Label every material outcome claim as **Observed**, **Validated proxy**, or **Hypothesis**. State the sample or time period for observed evidence when available, and add a short caveat to lower-maturity evidence.

For every blocker or resource request, include: requested action, accountable manager or peer lead, deadline, impact if unresolved, and whether a reply or a 1:1 discussion is required. Never present an unowned resource gap as a blocker.

Limit prospective use cases to two unless the user deliberately chooses a broader portfolio. Present them as qualification work, not active delivery.

Use the templates in the reference as a starting point, then tailor the wording and metrics to the user's context.
